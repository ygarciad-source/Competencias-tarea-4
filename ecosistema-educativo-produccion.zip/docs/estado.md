# docs/estado.md · Estado del proyecto (máximo 30 líneas)
Sprint terminado: Publicación y Despliegue en Render · Fecha: 2026-10-29

## Funciona
- Sprints 1 a 3 completos: autenticación, estructura curricular, glosario, canciones, noticias e inicio.
- P04.1 Gamificación servidor: reglas, insignias, intentos, logros, cuotas y ganchos de acceso.
- P08.1 - P08.3 Motor de Quiz: 5 niveles Bloom, evaluación, retroalimentación y diplomas PDF.
- Tutor Socrático con IA (Gemini 3.5 Flash): diálogo mayéutico, delimitación curricular y 40 consultas/día.
- Banco de Quizes IA (Condicionales en inglés): generación especializada (Zero, 1st, 2nd, 3rd y Mixed), 4 opciones, clave, retroalimentación explicativa, flujo docente (generar, revisar borrador, editar, guardar y eliminar) y avance al 100%.
- Preparación para hosting y Render:
  - DOCUMENTO_PEDAGOGICO_ECOSISTEMA.txt generado.
  - Paquete zip de producción ecosistema-educativo-produccion.zip listo para hosting.
  - render.yaml, README.md y .env.example para conexión automática con Render.

## Decisiones y cambios respecto a docs/contratos.md
- permisos.json: 'progreso-temas' permite escritura a estudiante, docente y servidor.

## Problemas conocidos
- Ninguno.
