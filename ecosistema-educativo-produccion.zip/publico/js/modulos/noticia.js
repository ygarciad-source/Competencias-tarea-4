/**
 * Módulo noticia.js
 * Visualización del detalle de una noticia y registro automático de lectura.
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';
import { usuarioActual } from '../nucleo/sesion.js';

let noticiaId = null;
let noticia = null;

async function inicializar() {
  await montarPlantilla({ titulo: 'Detalle de Noticia', roles: ['sesion'] });

  noticiaId = util.parametro('id');
  if (!noticiaId) {
    ui.aviso('No se especificó ninguna noticia.', 'error');
    setTimeout(() => {
      window.location.href = '/paginas/noticias.html';
    }, 1500);
    return;
  }

  await cargarNoticia();
}

async function cargarNoticia() {
  ui.cargando(true);
  try {
    const n = await api.obtener('noticias', noticiaId);
    noticia = n;

    // Obtener tema si está vinculado
    let temaTitulo = null;
    if (n.temaId) {
      try {
        const t = await api.obtener('temas', n.temaId);
        temaTitulo = t ? t.titulo : null;
      } catch {
        // Silencioso si el tema no existe
      }
    }

    // Obtener autor
    let nombreAutor = null;
    if (n.autorId) {
      try {
        const u = await api.obtener('usuarios', n.autorId);
        nombreAutor = u ? `${u.nombre} ${u.apellido}` : null;
      } catch {
        // Silencioso
      }
    }

    renderizarDetalle(n, temaTitulo, nombreAutor);
    configurarBotonEditar(n);

    // Registrar lectura automáticamente si aún no existe
    await registrarLectura(noticiaId);
  } catch (err) {
    ui.aviso('Error al cargar la noticia: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function renderizarDetalle(n, temaTitulo, nombreAutor) {
  document.getElementById('noticia-categoria').textContent = n.categoria || 'Institucional';
  document.getElementById('noticia-titulo').textContent = n.titulo;
  document.getElementById('noticia-resumen').textContent = n.resumen || '';

  const fechaIso = n.fechaPublicacion || n.fecha;
  const fechaTexto = fechaIso ? util.fechaLarga(fechaIso) : '';
  document.getElementById('noticia-fecha').textContent = fechaTexto ? `Publicado el ${fechaTexto}` : '';

  const autorEl = document.getElementById('noticia-autor');
  if (autorEl) {
    autorEl.textContent = nombreAutor ? `por ${nombreAutor}` : '';
  }

  const destEl = document.getElementById('noticia-destacada');
  if (destEl) {
    destEl.style.display = n.destacada ? 'inline-block' : 'none';
  }

  const temaEl = document.getElementById('noticia-tema');
  if (temaEl) {
    if (temaTitulo) {
      temaEl.textContent = temaTitulo;
      temaEl.style.display = 'inline-block';
    } else {
      temaEl.style.display = 'none';
    }
  }

  const imgCaja = document.getElementById('noticia-imagen-contenedor');
  const imgEl = document.getElementById('noticia-imagen');
  if (n.imagen && imgCaja && imgEl) {
    imgEl.src = n.imagen;
    imgEl.alt = n.titulo || 'Portada de noticia';
    imgCaja.style.display = 'flex';
  } else if (imgCaja) {
    imgCaja.style.display = 'none';
  }

  const cuerpoEl = document.getElementById('noticia-cuerpo');
  if (cuerpoEl) {
    cuerpoEl.innerHTML = util.formatoBasico(n.cuerpo || '');
  }
}

function configurarBotonEditar(n) {
  const usuario = usuarioActual();
  const puedeEditar = usuario && (usuario.rol === 'docente' || usuario.rol === 'admin');

  const contBtn = document.getElementById('contenedor-editar-noticia');
  const enlaceEditar = document.getElementById('btn-editar-noticia');
  if (contBtn && enlaceEditar && puedeEditar) {
    enlaceEditar.href = `/paginas/editor-noticia.html?id=${encodeURIComponent(n.id)}`;
    contBtn.style.display = 'block';
  }
}

async function registrarLectura(idNoticia) {
  try {
    const misLecturas = await api.listar('lecturas-noticias');
    const yaLeida = (misLecturas || []).some(l => l.noticiaId === idNoticia);

    if (!yaLeida) {
      await api.crear('lecturas-noticias', { noticiaId: idNoticia });
    }
  } catch (err) {
    // Si falla o ya existe, no interrumpir la experiencia del lector
    console.warn('Nota sobre registro de lectura:', err.message);
  }
}

inicializar();
