/**
 * Módulo privacidad.js - Controlador de la página de aviso de privacidad
 */

import { montarPlantilla } from '/js/nucleo/plantilla.js';

await montarPlantilla({ titulo: 'Aviso de Privacidad', roles: ['publico'] });

const contenido = document.getElementById('contenido');
if (contenido) {
  contenido.innerHTML = `
    <div class="privacidad-contenedor">
      <div class="fila" style="justify-content: space-between; align-items: center;">
        <span class="insignia insignia--primario">LOPDP Ecuador</span>
        <a href="/paginas/registro.html" class="btn btn--texto">← Volver al registro</a>
      </div>

      <article class="privacidad-tarjeta">
        <header>
          <h1 style="color: var(--color-primario); margin-bottom: var(--espacio-xs);">Aviso de Privacidad</h1>
          <p style="color: var(--color-texto-claro); font-size: var(--tamano-s);">
            Tratamiento de datos personales en el Ecosistema Educativo de Competencias Digitales
          </p>
        </header>

        <section class="privacidad-seccion">
          <h2>1. Finalidad del tratamiento</h2>
          <p>
            Los datos personales recabados en esta plataforma tienen como finalidad exclusiva la creación y administración de cuentas de usuario, el registro del avance académico en módulos de competencias digitales, la adaptación personalizada de actividades formativas y la emisión de insignias y certificaciones.
          </p>
        </section>

        <section class="privacidad-seccion">
          <h2>2. Datos personales tratados</h2>
          <p>La plataforma recopila y procesa únicamente la información indispensable para su funcionamiento formativo:</p>
          <ul class="privacidad-lista">
            <li><strong>Datos de identificación:</strong> Nombre y apellido.</li>
            <li><strong>Datos de contacto:</strong> Dirección de correo electrónico.</li>
            <li><strong>Actividad en la plataforma:</strong> Páginas visitadas, registro de accesos, intentos en actividades interactivas, puntajes y logros alcanzados.</li>
          </ul>
        </section>

        <section class="privacidad-seccion">
          <h2>3. Derechos de los titulares (LOPDP Ecuador)</h2>
          <p>
            De conformidad con la Ley Orgánica de Protección de Datos Personales (LOPDP) de la República del Ecuador, usted como titular goza de los siguientes derechos fundamentales respecto a su información:
          </p>
          <ul class="privacidad-lista">
            <li><strong>Derecho de acceso:</strong> Conocer los datos personales almacenados y la naturaleza de su tratamiento.</li>
            <li><strong>Derecho de rectificación:</strong> Solicitar la corrección de datos inexactos o incompletos.</li>
            <li><strong>Derecho de eliminación:</strong> Solicitar la supresión de sus datos cuando no exista obligación legal de conservarlos.</li>
          </ul>
        </section>

        <section class="privacidad-seccion">
          <h2>4. Contacto y atención de solicitudes</h2>
          <div class="privacidad-contacto">
            <p style="margin: 0;">
              Para consultas, dudas o para ejercer sus derechos de acceso, rectificación o eliminación, comuníquese con el responsable de privacidad al correo:
              <br>
              <strong>contacto@ecosistemaeducativo.edu.ec</strong>
            </p>
          </div>
        </section>
      </article>
    </div>
  `;
}
