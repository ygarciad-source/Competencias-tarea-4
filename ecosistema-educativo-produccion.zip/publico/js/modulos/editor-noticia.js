/**
 * Módulo editor-noticia.js
 * Creación y edición de noticias institucionales y académicas (docente, admin).
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';

let noticiaId = null;
let noticia = null;
let temasDisponibles = [];
let vistaPreviaActiva = false;

async function inicializar() {
  await montarPlantilla({ titulo: 'Editor de Noticia', roles: ['docente', 'admin'] });

  noticiaId = util.parametro('id');
  if (noticiaId) {
    document.getElementById('titulo-pagina-editor').textContent = 'Editar Noticia';
  }

  configurarEventos();
  await cargarTemas();

  if (noticiaId) {
    await cargarNoticia(noticiaId);
  } else {
    actualizarVistaPrevia();
  }
}

async function cargarTemas() {
  try {
    const lista = await api.listar('temas');
    temasDisponibles = lista || [];
    const select = document.getElementById('noticia-tema');
    if (select) {
      select.innerHTML = '<option value="">Ninguno (Noticia general)</option>' +
        temasDisponibles.map(t => `<option value="${ui.escapar(t.id)}">${ui.escapar(t.titulo)}</option>`).join('');
    }
  } catch (err) {
    console.warn('Error al cargar temas para el selector:', err);
  }
}

async function cargarNoticia(id) {
  ui.cargando(true);
  try {
    noticia = await api.obtener('noticias', id);
    document.getElementById('noticia-titulo').value = noticia.titulo || '';
    document.getElementById('noticia-categoria').value = noticia.categoria || 'Institucional';
    document.getElementById('noticia-tema').value = noticia.temaId || '';
    document.getElementById('noticia-estado').value = noticia.estado || 'borrador';
    document.getElementById('noticia-destacada').checked = Boolean(noticia.destacada);
    document.getElementById('noticia-imagen').value = noticia.imagen || '';
    document.getElementById('noticia-resumen').value = noticia.resumen || '';
    document.getElementById('noticia-cuerpo').value = noticia.cuerpo || '';

    actualizarContadorResumen();
    actualizarVistaPrevia();
  } catch (err) {
    ui.aviso('Error al cargar la noticia: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function configurarEventos() {
  const form = document.getElementById('form-noticia');
  form?.addEventListener('input', () => {
    actualizarContadorResumen();
    if (vistaPreviaActiva) actualizarVistaPrevia();
  });
  form?.addEventListener('change', () => {
    if (vistaPreviaActiva) actualizarVistaPrevia();
  });

  // Contador resumen
  document.getElementById('noticia-resumen')?.addEventListener('input', actualizarContadorResumen);

  // Subir imagen
  const btnSubir = document.getElementById('btn-subir-imagen');
  const fileInput = document.getElementById('archivo-imagen');
  const inputUrl = document.getElementById('noticia-imagen');

  btnSubir?.addEventListener('click', () => {
    fileInput?.click();
  });

  fileInput?.addEventListener('change', async () => {
    const archivo = fileInput.files?.[0];
    if (!archivo) return;

    ui.cargando(true);
    try {
      const resp = await api.subir(archivo);
      if (resp && resp.url) {
        inputUrl.value = resp.url;
        ui.aviso('Imagen subida correctamente.', 'exito');
        actualizarVistaPrevia();
      }
    } catch (err) {
      ui.aviso('Error al subir imagen: ' + err.message, 'error');
    } finally {
      ui.cargando(false);
      fileInput.value = '';
    }
  });

  // Toggle vista previa
  const btnToggle = document.getElementById('btn-toggle-vista-previa');
  const panelPrev = document.getElementById('panel-vista-previa');
  const layout = document.querySelector('.editor-noticia-layout');

  btnToggle?.addEventListener('click', () => {
    vistaPreviaActiva = !vistaPreviaActiva;
    if (vistaPreviaActiva) {
      actualizarVistaPrevia();
      panelPrev.style.display = 'block';
      layout.classList.add('con-vista-previa');
      btnToggle.textContent = '✕ Ocultar previa';
    } else {
      panelPrev.style.display = 'none';
      layout.classList.remove('con-vista-previa');
      btnToggle.textContent = '👁 Vista previa';
    }
  });

  // Guardar noticia
  document.getElementById('btn-guardar-noticia')?.addEventListener('click', () => {
    guardarNoticia();
  });
}

function actualizarContadorResumen() {
  const txt = document.getElementById('noticia-resumen')?.value || '';
  const span = document.getElementById('contador-resumen');
  if (span) {
    span.textContent = `${txt.length}/200 caracteres`;
    if (txt.length > 200) {
      span.style.color = 'var(--color-peligro)';
    } else {
      span.style.color = 'var(--color-texto-secundario)';
    }
  }
}

function actualizarVistaPrevia() {
  const titulo = document.getElementById('noticia-titulo')?.value || 'Título de la noticia';
  const categoria = document.getElementById('noticia-categoria')?.value || 'Institucional';
  const temaId = document.getElementById('noticia-tema')?.value;
  const destacada = document.getElementById('noticia-destacada')?.checked;
  const imagen = document.getElementById('noticia-imagen')?.value.trim();
  const resumen = document.getElementById('noticia-resumen')?.value || 'Resumen de la noticia...';
  const cuerpo = document.getElementById('noticia-cuerpo')?.value || 'Cuerpo completo de la noticia...';

  document.getElementById('prev-titulo').textContent = titulo;
  document.getElementById('prev-categoria').textContent = categoria;
  document.getElementById('prev-resumen').textContent = resumen;
  document.getElementById('prev-cuerpo').innerHTML = util.formatoBasico(cuerpo);

  const prevDest = document.getElementById('prev-destacada');
  if (prevDest) prevDest.style.display = destacada ? 'inline-block' : 'none';

  const prevTema = document.getElementById('prev-tema');
  if (prevTema) {
    if (temaId) {
      const temaObj = temasDisponibles.find(t => t.id === temaId);
      prevTema.textContent = temaObj ? temaObj.titulo : 'Tema';
      prevTema.style.display = 'inline-block';
    } else {
      prevTema.style.display = 'none';
    }
  }

  const prevImgCaja = document.getElementById('prev-imagen-contenedor');
  const prevImg = document.getElementById('prev-imagen');
  if (imagen && prevImg && prevImgCaja) {
    prevImg.src = imagen;
    prevImgCaja.style.display = 'block';
  } else if (prevImgCaja) {
    prevImgCaja.style.display = 'none';
  }
}

async function guardarNoticia() {
  const titulo = document.getElementById('noticia-titulo')?.value.trim();
  const categoria = document.getElementById('noticia-categoria')?.value;
  const temaId = document.getElementById('noticia-tema')?.value || null;
  const estado = document.getElementById('noticia-estado')?.value || 'borrador';
  const destacada = Boolean(document.getElementById('noticia-destacada')?.checked);
  const imagen = document.getElementById('noticia-imagen')?.value.trim() || null;
  const resumen = document.getElementById('noticia-resumen')?.value.trim();
  const cuerpo = document.getElementById('noticia-cuerpo')?.value.trim();

  if (!titulo || !resumen || !cuerpo) {
    ui.aviso('Título, resumen y cuerpo son campos obligatorios.', 'error');
    return;
  }

  if (resumen.length > 200) {
    ui.aviso('El resumen no puede exceder los 200 caracteres.', 'error');
    return;
  }

  const payload = {
    titulo,
    categoria,
    temaId,
    estado,
    destacada,
    imagen,
    resumen,
    cuerpo
  };

  ui.cargando(true);
  try {
    if (noticiaId) {
      await api.actualizar('noticias', noticiaId, payload);
      ui.aviso('Noticia actualizada exitosamente.', 'exito');
    } else {
      const creada = await api.crear('noticias', payload);
      ui.aviso('Noticia creada exitosamente.', 'exito');
      noticiaId = creada.id;
    }
    setTimeout(() => {
      window.location.href = '/paginas/noticias.html';
    }, 1200);
  } catch (err) {
    ui.aviso('Error al guardar noticia: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

inicializar();
