/**
 * Módulo admin-usuarios.js - Panel de administración de usuarios
 * Visualización, búsqueda, filtrado, actualización de roles/estado y restablecimiento de contraseñas.
 */

import { montarPlantilla } from '/js/nucleo/plantilla.js';
import { listar, actualizar, llamar } from '/js/nucleo/api.js';
import { aviso, confirmar, modal, cargando, escapar } from '/js/nucleo/ui.js';

await montarPlantilla({ titulo: 'Administración de Usuarios', roles: ['admin'] });

const contenido = document.getElementById('contenido');

if (contenido) {
  contenido.innerHTML = `
    <div class="admin-contenedor">
      <header class="admin-cabecera">
        <div>
          <span class="insignia insignia--primario">Administración</span>
          <h1 style="margin-top: var(--espacio-xs);">Gestión de Usuarios</h1>
        </div>
      </header>

      <section class="admin-filtros">
        <div class="campo">
          <label for="buscador-usuarios">Buscar por nombre, apellido o correo</label>
          <input
            type="search"
            id="buscador-usuarios"
            placeholder="Escribe para buscar..."
            autocomplete="off"
          >
        </div>

        <div class="campo" style="max-width: 200px;">
          <label for="filtro-rol">Filtrar por rol</label>
          <select id="filtro-rol">
            <option value="todos" selected>Todos los roles</option>
            <option value="estudiante">Estudiantes</option>
            <option value="docente">Docentes</option>
            <option value="admin">Administradores</option>
          </select>
        </div>
      </section>

      <div class="tabla-contenedor">
        <table class="tabla" id="tabla-usuarios">
          <thead>
            <tr>
              <th scope="col">Usuario</th>
              <th scope="col">Correo</th>
              <th scope="col">Rol</th>
              <th scope="col" style="text-align: center;">Activo</th>
              <th scope="col" style="text-align: right;">Acciones</th>
            </tr>
          </thead>
          <tbody id="cuerpo-tabla-usuarios">
            <tr>
              <td colspan="5" style="text-align: center; padding: var(--espacio-xl);">
                Cargando usuarios...
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `;

  const inputBuscador = document.getElementById('buscador-usuarios');
  const selectFiltroRol = document.getElementById('filtro-rol');
  const cuerpoTabla = document.getElementById('cuerpo-tabla-usuarios');

  let listaUsuarios = [];

  async function cargarUsuarios() {
    cargando(true);
    try {
      listaUsuarios = await listar('usuarios');
      renderizarTabla();
    } catch (err) {
      aviso(err.message || 'Error al cargar usuarios', 'error');
      cuerpoTabla.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; color: var(--color-error); padding: var(--espacio-l);">
            No se pudo cargar la lista de usuarios.
          </td>
        </tr>
      `;
    } finally {
      cargando(false);
    }
  }

  function renderizarTabla() {
    const texto = inputBuscador.value.trim().toLowerCase();
    const rolFiltro = selectFiltroRol.value;

    const filtrados = listaUsuarios.filter(u => {
      const coincideRol = (rolFiltro === 'todos') || (u.rol === rolFiltro);
      if (!coincideRol) return false;

      if (!texto) return true;
      const nombre = (u.nombre || '').toLowerCase();
      const apellido = (u.apellido || '').toLowerCase();
      const correo = (u.correo || '').toLowerCase();
      return nombre.includes(texto) || apellido.includes(texto) || correo.includes(texto);
    });

    if (filtrados.length === 0) {
      cuerpoTabla.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; padding: var(--espacio-xl); color: var(--color-texto-claro);">
            No se encontraron usuarios que coincidan con los filtros aplicados.
          </td>
        </tr>
      `;
      return;
    }

    cuerpoTabla.innerHTML = filtrados.map(u => {
      const inicial = (u.nombre ? u.nombre[0] : 'U').toUpperCase();
      const avatarHTML = u.foto
        ? `<img src="${escapar(u.foto)}" alt="Foto de ${escapar(u.nombre)}">`
        : escapar(inicial);

      const roles = ['estudiante', 'docente', 'admin'];
      const opcionesRol = roles.map(r => `
        <option value="${r}" ${u.rol === r ? 'selected' : ''}>${r.charAt(0).toUpperCase() + r.slice(1)}</option>
      `).join('');

      return `
        <tr data-id="${escapar(u.id)}">
          <td>
            <div style="display: flex; align-items: center; gap: var(--espacio-s);">
              <div class="admin-avatar">${avatarHTML}</div>
              <div>
                <strong>${escapar(u.nombre)} ${escapar(u.apellido || '')}</strong>
              </div>
            </div>
          </td>
          <td>
            <span style="color: var(--color-texto-claro);">${escapar(u.correo)}</span>
          </td>
          <td>
            <select class="selector-rol" data-id="${escapar(u.id)}" aria-label="Cambiar rol de ${escapar(u.nombre)}" style="min-height: auto; padding: var(--espacio-xs) var(--espacio-s); font-size: var(--tamano-s);">
              ${opcionesRol}
            </select>
          </td>
          <td style="text-align: center;">
            <input
              type="checkbox"
              class="casilla-activo"
              data-id="${escapar(u.id)}"
              aria-label="Estado activo de ${escapar(u.nombre)}"
              ${u.activo !== false ? 'checked' : ''}
              style="width: 18px; height: 18px; cursor: pointer; accent-color: var(--color-primario);"
            >
          </td>
          <td style="text-align: right;">
            <button
              type="button"
              class="btn btn--pequeno btn--secundario btn-restablecer"
              data-id="${escapar(u.id)}"
              data-nombre="${escapar(u.nombre)} ${escapar(u.apellido || '')}"
            >
              Restablecer clave
            </button>
          </td>
        </tr>
      `;
    }).join('');

    conectarEventosTabla();
  }

  function conectarEventosTabla() {
    // Cambio de rol
    cuerpoTabla.querySelectorAll('.selector-rol').forEach(sel => {
      sel.addEventListener('change', async (e) => {
        const id = e.target.dataset.id;
        const nuevoRol = e.target.value;
        const usuarioModificado = listaUsuarios.find(u => u.id === id);

        e.target.disabled = true;
        try {
          await actualizar('usuarios', id, { rol: nuevoRol });
          if (usuarioModificado) usuarioModificado.rol = nuevoRol;
          aviso(`Rol actualizado a "${nuevoRol}" con éxito`, 'exito');
        } catch (err) {
          aviso(err.message || 'Error al cambiar rol', 'error');
          if (usuarioModificado) e.target.value = usuarioModificado.rol;
        } finally {
          e.target.disabled = false;
        }
      });
    });

    // Cambio de estado activo
    cuerpoTabla.querySelectorAll('.casilla-activo').forEach(chk => {
      chk.addEventListener('change', async (e) => {
        const id = e.target.dataset.id;
        const activo = e.target.checked;
        const usuarioModificado = listaUsuarios.find(u => u.id === id);

        chk.disabled = true;
        try {
          await actualizar('usuarios', id, { activo });
          if (usuarioModificado) usuarioModificado.activo = activo;
          aviso(`Estado de cuenta ${activo ? 'activado' : 'desactivado'}`, 'exito');
        } catch (err) {
          aviso(err.message || 'Error al cambiar estado', 'error');
          chk.checked = !activo;
        } finally {
          chk.disabled = false;
        }
      });
    });

    // Botón restablecer clave
    cuerpoTabla.querySelectorAll('.btn-restablecer').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.currentTarget.dataset.id;
        const nombre = e.currentTarget.dataset.nombre;

        const confirmado = await confirmar(`¿Deseas restablecer la contraseña para "${nombre}"?`);
        if (!confirmado) return;

        cargando(true);
        try {
          const resp = await llamar('POST', `/api/admin/usuarios/${encodeURIComponent(id)}/restablecer`);
          cargando(false);

          const contenedorModal = document.createElement('div');
          contenedorModal.className = 'modal-clave-temporal';
          contenedorModal.innerHTML = `
            <p>Se ha generado una nueva contraseña temporal para <strong>${escapar(nombre)}</strong>:</p>
            <div class="clave-caja">
              <span class="clave-codigo" id="clave-temporal-texto">${escapar(resp.claveTemporal)}</span>
              <button type="button" id="btn-copiar-clave" class="btn btn--pequeno btn--acento">
                Copiar
              </button>
            </div>
            <p style="font-size: var(--tamano-xs); color: var(--color-texto-claro);">
              El usuario deberá utilizar esta clave temporal en su próximo ingreso y actualizarla en su perfil.
            </p>
          `;

          const btnCopiar = contenedorModal.querySelector('#btn-copiar-clave');
          btnCopiar.addEventListener('click', async () => {
            try {
              await navigator.clipboard.writeText(resp.claveTemporal);
              btnCopiar.textContent = '¡Copiado!';
              aviso('Clave temporal copiada al portapapeles', 'exito');
              setTimeout(() => {
                btnCopiar.textContent = 'Copiar';
              }, 2000);
            } catch {
              aviso('Error al copiar al portapapeles', 'error');
            }
          });

          await modal({
            titulo: 'Contraseña Restablecida',
            contenido: contenedorModal,
            acciones: [{ texto: 'Cerrar', valor: 'cerrar', clase: 'btn--primario' }]
          });
        } catch (err) {
          cargando(false);
          aviso(err.message || 'Error al restablecer la contraseña', 'error');
        }
      });
    });
  }

  inputBuscador.addEventListener('input', renderizarTabla);
  selectFiltroRol.addEventListener('change', renderizarTabla);

  await cargarUsuarios();
}
