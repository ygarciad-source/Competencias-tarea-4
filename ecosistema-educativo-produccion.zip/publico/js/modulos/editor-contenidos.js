/**
 * Módulo editor-contenidos.js
 * Editor de estructura curricular: Unidades y Temas (roles docente y admin).
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';

let asignaturas = [];
let asignaturaSeleccionadaId = null;
let unidades = [];
let unidadSeleccionadaId = null;
let temas = [];

async function inicializar() {
  await montarPlantilla({ titulo: 'Editor de Contenidos', roles: ['docente', 'admin'] });

  const selectorAsignatura = document.getElementById('selector-asignatura');
  selectorAsignatura?.addEventListener('change', e => {
    asignaturaSeleccionadaId = e.target.value;
    unidadSeleccionadaId = null;
    cargarUnidades();
  });

  document.getElementById('btn-nueva-unidad')?.addEventListener('click', () => {
    abrirModalNuevaUnidad();
  });

  document.getElementById('btn-nuevo-tema')?.addEventListener('click', () => {
    abrirModalNuevoTema();
  });

  await cargarAsignaturas();
}

async function cargarAsignaturas() {
  ui.cargando(true);
  try {
    const lista = await api.listar('asignaturas');
    asignaturas = lista || [];

    const selector = document.getElementById('selector-asignatura');
    const panelVacio = document.getElementById('panel-vacio');
    const contenedorEditorial = document.getElementById('contenedor-editorial');

    if (asignaturas.length === 0) {
      if (selector) selector.innerHTML = '<option value="">Sin asignaturas disponibles</option>';
      if (panelVacio) panelVacio.style.display = 'block';
      if (contenedorEditorial) contenedorEditorial.style.display = 'none';
      return;
    }

    if (panelVacio) panelVacio.style.display = 'none';
    if (contenedorEditorial) contenedorEditorial.style.display = 'grid';

    if (selector) {
      selector.innerHTML = asignaturas.map(a => `
        <option value="${ui.escapar(a.id)}">${ui.escapar(a.nombre)} (${ui.escapar(a.nivel || 'General')})</option>
      `).join('');

      asignaturaSeleccionadaId = asignaturas[0].id;
      selector.value = asignaturaSeleccionadaId;
    }

    await cargarUnidades();
  } catch (err) {
    ui.aviso('Error al cargar asignaturas: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function cargarUnidades() {
  if (!asignaturaSeleccionadaId) return;

  ui.cargando(true);
  try {
    const lista = await api.listar('unidades', { asignaturaId: asignaturaSeleccionadaId });
    unidades = (lista || []).sort((a, b) => (a.orden || 0) - (b.orden || 0));

    // Si la unidad seleccionada ya no existe, limpiar o seleccionar la primera
    if (unidadSeleccionadaId && !unidades.some(u => u.id === unidadSeleccionadaId)) {
      unidadSeleccionadaId = null;
    }

    if (!unidadSeleccionadaId && unidades.length > 0) {
      unidadSeleccionadaId = unidades[0].id;
    }

    renderizarUnidades();
    await cargarTemas();
  } catch (err) {
    ui.aviso('Error al cargar unidades: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function renderizarUnidades() {
  const listaEl = document.getElementById('lista-unidades');
  if (!listaEl) return;

  if (unidades.length === 0) {
    listaEl.innerHTML = `
      <li class="mensaje-vacio-panel">
        No hay unidades en esta asignatura. Pulsa "+ Nueva unidad" para comenzar.
      </li>
    `;
    return;
  }

  listaEl.innerHTML = unidades.map((u, idx) => {
    const esActiva = u.id === unidadSeleccionadaId;
    const esPrimera = idx === 0;
    const esUltima = idx === unidades.length - 1;

    return `
      <li class="item-editorial item-editorial--seleccionable ${esActiva ? 'item-editorial--activo' : ''}" data-id="${ui.escapar(u.id)}">
        <div class="item-editorial__cuerpo">
          <div class="item-editorial__info">
            <span class="item-editorial__orden">U${ui.escapar(String(u.orden || idx + 1))}</span>
            <div>
              <h3 class="item-editorial__titulo">${ui.escapar(u.titulo)}</h3>
            </div>
          </div>
          <span class="insignia ${u.visible !== false ? 'insignia--exito' : 'insignia--advertencia'}">
            ${u.visible !== false ? 'Visible' : 'Oculto'}
          </span>
        </div>
        <div class="item-editorial__acciones">
          <button type="button" class="btn-icono btn-subir-u" data-id="${ui.escapar(u.id)}" title="Subir orden" ${esPrimera ? 'disabled' : ''}>
            ▲
          </button>
          <button type="button" class="btn-icono btn-bajar-u" data-id="${ui.escapar(u.id)}" title="Bajar orden" ${esUltima ? 'disabled' : ''}>
            ▼
          </button>
          <button type="button" class="btn-icono btn-renombrar-u" data-id="${ui.escapar(u.id)}" title="Renombrar unidad">
            Renombrar
          </button>
          <button type="button" class="btn-icono btn-visibilidad-u" data-id="${ui.escapar(u.id)}" title="Cambiar visibilidad">
            ${u.visible !== false ? 'Ocultar' : 'Mostrar'}
          </button>
        </div>
      </li>
    `;
  }).join('');

  // Eventos de selección de unidad
  listaEl.querySelectorAll('.item-editorial').forEach(item => {
    item.addEventListener('click', e => {
      // Ignorar si clic proviene de un botón de acción
      if (e.target.closest('button')) return;
      const id = item.getAttribute('data-id');
      if (id && id !== unidadSeleccionadaId) {
        unidadSeleccionadaId = id;
        renderizarUnidades();
        cargarTemas();
      }
    });
  });

  // Acciones de unidad
  listaEl.querySelectorAll('.btn-renombrar-u').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      const unidad = unidades.find(u => u.id === id);
      if (unidad) abrirModalRenombrarUnidad(unidad);
    });
  });

  listaEl.querySelectorAll('.btn-visibilidad-u').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      const unidad = unidades.find(u => u.id === id);
      if (unidad) alternarVisibilidadUnidad(unidad);
    });
  });

  listaEl.querySelectorAll('.btn-subir-u').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      const idx = unidades.findIndex(u => u.id === id);
      if (idx > 0) reordenarUnidades(idx, idx - 1);
    });
  });

  listaEl.querySelectorAll('.btn-bajar-u').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      const idx = unidades.findIndex(u => u.id === id);
      if (idx < unidades.length - 1) reordenarUnidades(idx, idx + 1);
    });
  });
}

async function cargarTemas() {
  const btnNuevoTema = document.getElementById('btn-nuevo-tema');
  const subtituloTemas = document.getElementById('subtitulo-temas');

  if (!unidadSeleccionadaId) {
    temas = [];
    if (btnNuevoTema) btnNuevoTema.disabled = true;
    if (subtituloTemas) subtituloTemas.textContent = 'Selecciona una unidad para gestionar sus temas';
    renderizarTemas();
    return;
  }

  const unidadActiva = unidades.find(u => u.id === unidadSeleccionadaId);
  if (btnNuevoTema) btnNuevoTema.disabled = false;
  if (subtituloTemas) subtituloTemas.textContent = `Temas de: ${unidadActiva?.titulo || 'Unidad seleccionada'}`;

  ui.cargando(true);
  try {
    const lista = await api.listar('temas', { unidadId: unidadSeleccionadaId });
    temas = (lista || []).sort((a, b) => (a.orden || 0) - (b.orden || 0));
    renderizarTemas();
  } catch (err) {
    ui.aviso('Error al cargar temas: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function renderizarTemas() {
  const listaEl = document.getElementById('lista-temas');
  if (!listaEl) return;

  if (!unidadSeleccionadaId) {
    listaEl.innerHTML = `
      <li class="mensaje-vacio-panel">
        Selecciona una unidad de la lista izquierda para visualizar y gestionar sus temas.
      </li>
    `;
    return;
  }

  if (temas.length === 0) {
    listaEl.innerHTML = `
      <li class="mensaje-vacio-panel">
        Esta unidad aún no tiene temas. Pulsa "+ Nuevo tema" para agregar uno.
      </li>
    `;
    return;
  }

  listaEl.innerHTML = temas.map((t, idx) => {
    const esPrimero = idx === 0;
    const esUltimo = idx === temas.length - 1;
    const esPublicado = t.estado === 'publicado';

    return `
      <li class="item-editorial" data-id="${ui.escapar(t.id)}">
        <div class="item-editorial__cuerpo">
          <div class="item-editorial__info">
            <span class="item-editorial__orden">T${ui.escapar(String(t.orden || idx + 1))}</span>
            <div>
              <h3 class="item-editorial__titulo">${ui.escapar(t.titulo)}</h3>
            </div>
          </div>
          <div>
            <select class="selector-estado-tema" data-id="${ui.escapar(t.id)}" aria-label="Cambiar estado del tema">
              <option value="borrador" ${!esPublicado ? 'selected' : ''}>Borrador</option>
              <option value="publicado" ${esPublicado ? 'selected' : ''}>Publicado</option>
            </select>
          </div>
        </div>
        <div class="item-editorial__acciones">
          <button type="button" class="btn-icono btn-subir-t" data-id="${ui.escapar(t.id)}" title="Subir orden" ${esPrimero ? 'disabled' : ''}>
            ▲
          </button>
          <button type="button" class="btn-icono btn-bajar-t" data-id="${ui.escapar(t.id)}" title="Bajar orden" ${esUltimo ? 'disabled' : ''}>
            ▼
          </button>
          <a href="/paginas/editor-tema.html?id=${encodeURIComponent(t.id)}" class="btn btn--secundario btn--pequeno" style="text-decoration: none;">
            Editar ficha
          </a>
        </div>
      </li>
    `;
  }).join('');

  // Eventos de temas
  listaEl.querySelectorAll('.selector-estado-tema').forEach(sel => {
    sel.addEventListener('change', async e => {
      const id = sel.getAttribute('data-id');
      const nuevoEstado = e.target.value;
      await cambiarEstadoTema(id, nuevoEstado);
    });
  });

  listaEl.querySelectorAll('.btn-subir-t').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const idx = temas.findIndex(t => t.id === id);
      if (idx > 0) reordenarTemas(idx, idx - 1);
    });
  });

  listaEl.querySelectorAll('.btn-bajar-t').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const idx = temas.findIndex(t => t.id === id);
      if (idx < temas.length - 1) reordenarTemas(idx, idx + 1);
    });
  });
}

/* Modales y Operaciones de Unidades */

async function abrirModalNuevaUnidad() {
  if (!asignaturaSeleccionadaId) {
    ui.aviso('Selecciona una asignatura primero.', 'error');
    return;
  }

  const form = document.createElement('form');
  form.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: var(--espacio-xs);">
      <label for="nueva-unidad-titulo"><strong>Título de la unidad *</strong></label>
      <input type="text" id="nueva-unidad-titulo" required placeholder="Ej. Unidad 1: Fundamentos de la Competencia Digital" style="padding: var(--espacio-s); border-radius: var(--radio-s); border: 1px solid var(--color-borde); font-family: inherit; font-size: var(--tamano-m);" />
    </div>
  `;
  form.addEventListener('submit', e => e.preventDefault());

  const accion = await ui.modal({
    titulo: 'Nueva unidad',
    contenido: form,
    acciones: [
      { texto: 'Cancelar', valor: null, clase: 'btn--secundario' },
      { texto: 'Crear unidad', valor: 'crear', clase: 'btn--primario' }
    ]
  });

  if (accion !== 'crear') return;

  const titulo = form.querySelector('#nueva-unidad-titulo')?.value.trim();
  if (!titulo) {
    ui.aviso('El título de la unidad es requerido.', 'error');
    return;
  }

  ui.cargando(true);
  try {
    const nuevoOrden = unidades.length + 1;
    const creada = await api.crear('unidades', {
      asignaturaId: asignaturaSeleccionadaId,
      titulo,
      orden: nuevoOrden,
      visible: true
    });
    ui.aviso('Unidad creada exitosamente.', 'exito');
    unidadSeleccionadaId = creada.id;
    await cargarUnidades();
  } catch (err) {
    ui.aviso('Error al crear unidad: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function abrirModalRenombrarUnidad(unidad) {
  const form = document.createElement('form');
  form.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: var(--espacio-xs);">
      <label for="renombrar-unidad-titulo"><strong>Título de la unidad *</strong></label>
      <input type="text" id="renombrar-unidad-titulo" required value="${ui.escapar(unidad.titulo)}" style="padding: var(--espacio-s); border-radius: var(--radio-s); border: 1px solid var(--color-borde); font-family: inherit; font-size: var(--tamano-m);" />
    </div>
  `;
  form.addEventListener('submit', e => e.preventDefault());

  const accion = await ui.modal({
    titulo: 'Renombrar unidad',
    contenido: form,
    acciones: [
      { texto: 'Cancelar', valor: null, clase: 'btn--secundario' },
      { texto: 'Guardar', valor: 'guardar', clase: 'btn--primario' }
    ]
  });

  if (accion !== 'guardar') return;

  const titulo = form.querySelector('#renombrar-unidad-titulo')?.value.trim();
  if (!titulo) {
    ui.aviso('El título no puede estar vacío.', 'error');
    return;
  }

  ui.cargando(true);
  try {
    await api.actualizar('unidades', unidad.id, { titulo });
    ui.aviso('Unidad renombrada.', 'exito');
    await cargarUnidades();
  } catch (err) {
    ui.aviso('Error al renombrar unidad: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function alternarVisibilidadUnidad(unidad) {
  const nuevoEstado = unidad.visible === false;
  ui.cargando(true);
  try {
    await api.actualizar('unidades', unidad.id, { visible: nuevoEstado });
    ui.aviso(`Unidad ahora ${nuevoEstado ? 'visible' : 'oculta'}.`, 'exito');
    await cargarUnidades();
  } catch (err) {
    ui.aviso('Error al cambiar visibilidad: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function reordenarUnidades(idxOrigen, idxDestino) {
  const uOrigen = unidades[idxOrigen];
  const uDestino = unidades[idxDestino];
  if (!uOrigen || !uDestino) return;

  ui.cargando(true);
  try {
    const ordenOrigen = uOrigen.orden || idxOrigen + 1;
    const ordenDestino = uDestino.orden || idxDestino + 1;

    // Actualizamos ambos
    await api.actualizar('unidades', uOrigen.id, { orden: ordenDestino });
    await api.actualizar('unidades', uDestino.id, { orden: ordenOrigen });
    await cargarUnidades();
  } catch (err) {
    ui.aviso('Error al reordenar unidades: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

/* Modales y Operaciones de Temas */

async function abrirModalNuevoTema() {
  if (!unidadSeleccionadaId) return;

  const form = document.createElement('form');
  form.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: var(--espacio-xs);">
      <label for="nuevo-tema-titulo"><strong>Título del tema *</strong></label>
      <input type="text" id="nuevo-tema-titulo" required placeholder="Ej. Estrategias y Recursos Digitales en Educación Superior" style="padding: var(--espacio-s); border-radius: var(--radio-s); border: 1px solid var(--color-borde); font-family: inherit; font-size: var(--tamano-m);" />
      <small style="color: var(--color-texto-secundario);">El tema se creará inicialmente en estado "borrador".</small>
    </div>
  `;
  form.addEventListener('submit', e => e.preventDefault());

  const accion = await ui.modal({
    titulo: 'Nuevo tema',
    contenido: form,
    acciones: [
      { texto: 'Cancelar', valor: null, clase: 'btn--secundario' },
      { texto: 'Crear tema', valor: 'crear', clase: 'btn--primario' }
    ]
  });

  if (accion !== 'crear') return;

  const titulo = form.querySelector('#nuevo-tema-titulo')?.value.trim();
  if (!titulo) {
    ui.aviso('El título del tema es requerido.', 'error');
    return;
  }

  ui.cargando(true);
  try {
    const nuevoOrden = temas.length + 1;
    await api.crear('temas', {
      unidadId: unidadSeleccionadaId,
      titulo,
      orden: nuevoOrden,
      estado: 'borrador',
      objetivos: [],
      resumen: '',
      ejemplos: [],
      erroresFrecuentes: [],
      preguntasGuia: [],
      recursos: [],
      palabrasClave: [],
      dificultad: 'media',
      fuentes: ''
    });
    ui.aviso('Tema creado en borrador exitosamente.', 'exito');
    await cargarTemas();
  } catch (err) {
    ui.aviso('Error al crear tema: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function cambiarEstadoTema(temaId, nuevoEstado) {
  ui.cargando(true);
  try {
    await api.actualizar('temas', temaId, { estado: nuevoEstado });
    ui.aviso(`Estado del tema actualizado a "${nuevoEstado}".`, 'exito');
    await cargarTemas();
  } catch (err) {
    ui.aviso('Error al cambiar estado del tema: ' + err.message, 'error');
    await cargarTemas();
  } finally {
    ui.cargando(false);
  }
}

async function reordenarTemas(idxOrigen, idxDestino) {
  const tOrigen = temas[idxOrigen];
  const tDestino = temas[idxDestino];
  if (!tOrigen || !tDestino) return;

  ui.cargando(true);
  try {
    const ordenOrigen = tOrigen.orden || idxOrigen + 1;
    const ordenDestino = tDestino.orden || idxDestino + 1;

    await api.actualizar('temas', tOrigen.id, { orden: ordenDestino });
    await api.actualizar('temas', tDestino.id, { orden: ordenOrigen });
    await cargarTemas();
  } catch (err) {
    ui.aviso('Error al reordenar temas: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

inicializar();
