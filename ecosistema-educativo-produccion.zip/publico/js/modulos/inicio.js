/**
 * Módulo inicio.js
 * Controlador de la página principal (Home)
 * Soporta modo sin sesión (público) y con sesión (estudiante, docente, admin).
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import { usuarioActual } from '../nucleo/sesion.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';
import { calcularAvance } from './asignaturas.js';

await montarPlantilla({ titulo: 'Inicio', roles: ['publico'] });

const contenedor = document.getElementById('contenido');

async function inicializar() {
  const usuario = usuarioActual();

  if (!usuario) {
    renderizarSinSesion();
  } else {
    await renderizarConSesion(usuario);
  }
}

/**
 * Vista para usuarios anónimos (sin sesión iniciada)
 */
function renderizarSinSesion() {
  contenedor.innerHTML = `
    <section class="inicio-hero">
      <span class="insignia insignia--acento" style="font-weight: 700;">UNEMI · Plataforma Digital</span>
      <h1>Ecosistema Educativo de Competencias Digitales</h1>
      <p>
        Plataforma integral para el diagnóstico, fortalecimiento y acreditación de competencias pedagógicas y tecnológicas según los marcos de referencia DigCompEdu y UNESCO.
      </p>
      <div class="inicio-hero__acciones">
        <a href="/paginas/ingreso.html" class="btn btn--acento">
          Ingresar al aula virtual →
        </a>
        <a href="/paginas/registro.html" class="btn btn--secundario" style="background: rgba(255,255,255,0.15); color: #fff; border-color: rgba(255,255,255,0.4);">
          Crear cuenta nueva
        </a>
      </div>
    </section>

    <section class="inicio-pilares">
      <h2 class="inicio-pilares__titulo">Aprende y practica a tu ritmo</h2>
      <div class="grid-auto">
        <article class="tarjeta-pilar">
          <span class="tarjeta-pilar__icono">📘</span>
          <h3 class="tarjeta-pilar__titulo">Contenidos Curriculares</h3>
          <p class="tarjeta-pilar__desc">
            Lecciones organizadas en unidades didácticas y temas con objetivos claros, resúmenes, ejemplos reales y recursos multimedia.
          </p>
        </article>

        <article class="tarjeta-pilar">
          <span class="tarjeta-pilar__icono">🎵</span>
          <h3 class="tarjeta-pilar__titulo">Canciones Pedagógicas</h3>
          <p class="tarjeta-pilar__desc">
            Aprende conceptos clave con música educativa y letras sincronizadas (LRC) que facilitan la retención y el repaso.
          </p>
        </article>

        <article class="tarjeta-pilar">
          <span class="tarjeta-pilar__icono">🎮</span>
          <h3 class="tarjeta-pilar__titulo">Actividades y Juegos</h3>
          <p class="tarjeta-pilar__desc">
            Ejercita tus habilidades con quizes progresivos, glosarios interactivos, simulaciones de casos y foros de debate.
          </p>
        </article>
      </div>
    </section>
  `;
}

/**
 * Vista para usuarios autenticados
 * @param {object} usuario
 */
async function renderizarConSesion(usuario) {
  const nombreUsuario = ui.escapar(usuario.nombre || 'Usuario');
  const rolTexto = usuario.rol ? usuario.rol.charAt(0).toUpperCase() + usuario.rol.slice(1) : '';

  // 1. Cabecera con saludo
  let html = `
    <section class="inicio-hero" style="margin-bottom: var(--espacio-l);">
      <div class="fila" style="justify-content: space-between; align-items: flex-start; gap: var(--espacio-s);">
        <div>
          <span class="insignia insignia--acento" style="font-weight: 700; text-transform: capitalize;">${rolTexto}</span>
          <h1 style="margin-top: var(--espacio-xs);">¡Hola, ${nombreUsuario}!</h1>
          <p style="margin-bottom: 0;">
            ${usuario.rol === 'estudiante'
              ? 'Continúa desarrollando tus competencias digitales e interactúa con tus temas de estudio.'
              : 'Bienvenido al panel docente y administrativo. Gestiona materias, publicaciones y contenidos.'}
          </p>
        </div>
      </div>
    </section>
  `;

  // 2. Para docentes y admin: accesos rápidos a Contenidos y Noticias
  if (usuario.rol === 'docente' || usuario.rol === 'admin') {
    html += `
      <section class="seccion-accesos" aria-label="Accesos rápidos de gestión">
        <div class="grid-accesos">
          <a href="/paginas/editor-contenidos.html" class="tarjeta-acceso">
            <span class="tarjeta-acceso__icono">📚</span>
            <div class="tarjeta-acceso__info">
              <h3>Gestión de Contenidos</h3>
              <p>Edita asignaturas, unidades, temas, fichas pedagógicas y glosarios.</p>
            </div>
          </a>

          <a href="/paginas/noticias.html" class="tarjeta-acceso">
            <span class="tarjeta-acceso__icono">📰</span>
            <div class="tarjeta-acceso__info">
              <h3>Gestión de Noticias</h3>
              <p>Redacta, publica y difunde comunicados y novedades a la comunidad.</p>
            </div>
          </a>
        </div>
      </section>
    `;
  }

  // 3. Continuar donde te quedaste (localStorage "ultimoTema")
  const bannerTemaHtml = obtenerHtmlUltimoTema();
  if (bannerTemaHtml) {
    html += bannerTemaHtml;
  }

  // 4. Mis asignaturas con su avance (importa calcularAvance)
  html += `
    <section class="seccion-bloque" id="seccion-mis-asignaturas">
      <div class="seccion-bloque__cabecera">
        <h2>Mis Asignaturas</h2>
        <a href="/paginas/asignaturas.html" class="btn btn--texto">Ver asignaturas completas →</a>
      </div>
      <div id="contenedor-asignaturas-inicio" class="grid-asignaturas-inicio">
        <p class="texto-cargando">Cargando tus asignaturas y progreso...</p>
      </div>
    </section>
  `;

  // 5. Las 3 noticias publicadas más recientes (destacadas primero)
  html += `
    <section class="seccion-bloque" id="seccion-noticias-recientes">
      <div class="seccion-bloque__cabecera">
        <h2>Noticias y Novedades</h2>
        <a href="/paginas/noticias.html" class="btn btn--texto">Ver todas las noticias →</a>
      </div>
      <div id="contenedor-noticias-inicio" class="grid-noticias-inicio">
        <p class="texto-cargando">Cargando novedades...</p>
      </div>
    </section>
  `;

  contenedor.innerHTML = html;

  // Cargar datos asíncronos en paralelo
  await Promise.all([
    cargarAsignaturasInicio(),
    cargarNoticiasInicio()
  ]);
}

/**
 * Obtiene el HTML del banner "Continuar donde te quedaste" si existe en localStorage
 * @returns {string}
 */
function obtenerHtmlUltimoTema() {
  try {
    const raw = localStorage.getItem('ultimoTema');
    if (!raw) return '';
    const ultimo = JSON.parse(raw);
    if (!ultimo || !ultimo.id || !ultimo.titulo) return '';

    return `
      <div class="banner-continuar-estudio" role="region" aria-label="Continuar donde te quedaste">
        <div class="banner-continuar-estudio__info">
          <span class="banner-continuar-estudio__icono">🎯</span>
          <div>
            <span class="banner-continuar-estudio__etiqueta">Continuar donde te quedaste</span>
            <h2 class="banner-continuar-estudio__titulo">${ui.escapar(ultimo.titulo)}</h2>
          </div>
        </div>
        <a href="/paginas/tema.html?id=${encodeURIComponent(ultimo.id)}" class="btn btn--primario">
          Reanudar tema →
        </a>
      </div>
    `;
  } catch {
    return '';
  }
}

/**
 * Carga y renderiza las asignaturas con su porcentaje de avance
 */
async function cargarAsignaturasInicio() {
  const el = document.getElementById('contenedor-asignaturas-inicio');
  if (!el) return;

  try {
    const asignaturas = await api.listar('asignaturas');

    if (!asignaturas || asignaturas.length === 0) {
      el.innerHTML = `
        <div class="aviso aviso--info" style="grid-column: 1 / -1;">
          No tienes asignaturas registradas actualmente.
        </div>
      `;
      return;
    }

    // Calcular avance para cada asignatura en paralelo
    const asignaturasConAvance = await Promise.all(
      asignaturas.map(async (asig) => {
        const avance = await calcularAvance(asig.id);
        return { asig, avance };
      })
    );

    el.innerHTML = asignaturasConAvance.map(({ asig, avance }) => {
      const porcentaje = avance.porcentaje || 0;
      const revisados = avance.revisados || 0;
      const total = avance.total || 0;

      return `
        <article class="tarjeta-asignatura-inicio">
          <div>
            <div class="tarjeta-asignatura-inicio__cabecera">
              <span class="insignia insignia--secundario">${ui.escapar(asig.nivel || 'General')}</span>
            </div>
            <h3 class="tarjeta-asignatura-inicio__titulo">${ui.escapar(asig.nombre)}</h3>
            <p class="tarjeta-asignatura-inicio__desc">${ui.escapar(asig.descripcion || 'Sin descripción disponible.')}</p>
          </div>

          <div>
            <div class="seccion-avance-asignatura__meta">
              <span>Avance de contenidos</span>
              <span><strong>${porcentaje}%</strong> (${revisados}/${total})</span>
            </div>
            <div class="progreso progreso--primario" role="progressbar" aria-valuenow="${porcentaje}" aria-valuemin="0" aria-valuemax="100" aria-label="Avance de ${ui.escapar(asig.nombre)}">
              <span class="progreso__barra" style="width: ${porcentaje}%;"></span>
            </div>

            <div style="margin-top: var(--espacio-m);">
              <a href="/paginas/asignatura.html?id=${encodeURIComponent(asig.id)}" class="btn btn--primario btn--pequeno btn--bloque" style="text-decoration: none; text-align: center;">
                Ver contenidos →
              </a>
            </div>
          </div>
        </article>
      `;
    }).join('');
  } catch (err) {
    console.error('Error cargando asignaturas en inicio:', err);
    el.innerHTML = `
      <div class="aviso aviso--error" style="grid-column: 1 / -1;">
        No fue posible cargar tus asignaturas.
      </div>
    `;
  }
}

/**
 * Carga las 3 noticias publicadas más recientes (destacadas primero)
 */
async function cargarNoticiasInicio() {
  const el = document.getElementById('contenedor-noticias-inicio');
  if (!el) return;

  try {
    const [todasNoticias, lecturas] = await Promise.all([
      api.listar('noticias'),
      api.listar('lecturas-noticias').catch(() => [])
    ]);

    // Filtrar solo las publicadas
    const publicadas = (todasNoticias || []).filter(n => n.estado === 'publicado');

    if (publicadas.length === 0) {
      el.innerHTML = `
        <div class="aviso aviso--info" style="grid-column: 1 / -1;">
          No hay noticias o novedades publicadas en este momento.
        </div>
      `;
      return;
    }

    // Ordenar: destacadas primero, y luego las más recientes por fecha
    publicadas.sort((a, b) => {
      const destA = a.destacada ? 1 : 0;
      const destB = b.destacada ? 1 : 0;
      if (destA !== destB) return destB - destA;

      const fA = new Date(a.fechaPublicacion || a.fecha || 0).getTime();
      const fB = new Date(b.fechaPublicacion || b.fecha || 0).getTime();
      return fB - fA;
    });

    // Tomar las 3 primeras
    const top3 = publicadas.slice(0, 3);
    const idsLeidas = new Set((lecturas || []).map(l => l.noticiaId));

    el.innerHTML = top3.map(n => {
      const leida = idsLeidas.has(n.id);
      const fechaStr = n.fechaPublicacion || n.fecha;
      const fechaFormateada = fechaStr ? util.fechaRelativa(fechaStr) : '';

      return `
        <article class="tarjeta-noticia-inicio">
          <div class="tarjeta-noticia-inicio__media">
            ${n.imagen
              ? `<img src="${ui.escapar(n.imagen)}" alt="${ui.escapar(n.titulo)}" loading="lazy">`
              : `<div class="tarjeta-noticia-inicio__media-vacia" aria-hidden="true">📰</div>`
            }
            <div class="tarjeta-noticia-inicio__insignias">
              ${n.categoria ? `<span class="insignia insignia--primario">${ui.escapar(n.categoria)}</span>` : ''}
              ${n.destacada ? `<span class="insignia insignia--acento">★ Destacada</span>` : ''}
              ${!leida ? `<span class="insignia insignia--alerta">Nuevo</span>` : ''}
            </div>
          </div>

          <div class="tarjeta-noticia-inicio__cuerpo">
            ${fechaFormateada ? `<span class="tarjeta-noticia-inicio__fecha">${ui.escapar(fechaFormateada)}</span>` : ''}
            <h3 class="tarjeta-noticia-inicio__titulo">
              <a href="/paginas/noticia.html?id=${encodeURIComponent(n.id)}" style="color: inherit; text-decoration: none;">
                ${ui.escapar(n.titulo)}
              </a>
            </h3>
            <p class="tarjeta-noticia-inicio__resumen">
              ${ui.escapar(n.resumen || '')}
            </p>
          </div>

          <div class="tarjeta-noticia-inicio__pie">
            <a href="/paginas/noticia.html?id=${encodeURIComponent(n.id)}" class="btn btn--texto btn--pequeno" style="padding-left: 0;">
              Leer noticia completa →
            </a>
          </div>
        </article>
      `;
    }).join('');
  } catch (err) {
    console.error('Error cargando noticias en inicio:', err);
    el.innerHTML = `
      <div class="aviso aviso--error" style="grid-column: 1 / -1;">
        No fue posible cargar las noticias recientes.
      </div>
    `;
  }
}

inicializar();
