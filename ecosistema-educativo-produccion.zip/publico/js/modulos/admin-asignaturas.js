/**
 * Módulo admin-asignaturas.js
 * Gestión de asignaturas académicas (solo rol admin).
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';

let asignaturas = [];
let distributivo = [];

async function inicializar() {
  await montarPlantilla({ titulo: 'Asignaturas', roles: ['admin'] });

  document.getElementById('btn-nueva-asignatura')?.addEventListener('click', () => {
    abrirModalAsignatura();
  });

  await cargarDatos();
}

async function cargarDatos() {
  ui.cargando(true);
  try {
    const [listaAsignaturas, listaDistributivo] = await Promise.all([
      api.listar('asignaturas'),
      api.listar('distributivo')
    ]);
    asignaturas = listaAsignaturas || [];
    distributivo = listaDistributivo || [];
    renderizarAsignaturas();
  } catch (err) {
    ui.aviso('Error al cargar asignaturas: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function renderizarAsignaturas() {
  const contenedor = document.getElementById('listado-asignaturas');
  if (!contenedor) return;

  if (asignaturas.length === 0) {
    contenedor.innerHTML = `
      <div class="tarjeta" style="grid-column: 1 / -1; text-align: center; padding: var(--espacio-xxl);">
        <p style="color: var(--color-texto-secundario); margin: 0;">No hay asignaturas registradas. Haz clic en "+ Nueva asignatura" para crear la primera.</p>
      </div>
    `;
    return;
  }

  // Contar grupos por asignatura
  const conteoGrupos = {};
  distributivo.forEach(g => {
    conteoGrupos[g.asignaturaId] = (conteoGrupos[g.asignaturaId] || 0) + 1;
  });

  contenedor.innerHTML = asignaturas.map(asig => {
    const grupos = conteoGrupos[asig.id] || 0;
    const etiquetaGrupos = grupos === 1 ? '1 grupo asignado' : `${grupos} grupos asignados`;

    return `
      <article class="tarjeta tarjeta-asignatura" data-id="${ui.escapar(asig.id)}">
        <header class="tarjeta__cabecera">
          <span class="tarjeta-asignatura__nivel">${ui.escapar(asig.nivel || 'General')}</span>
          <span class="tarjeta-asignatura__id">${ui.escapar(asig.id)}</span>
        </header>
        <div class="tarjeta__cuerpo">
          <h2 class="tarjeta-asignatura__titulo">${ui.escapar(asig.nombre)}</h2>
          <p class="tarjeta-asignatura__desc">${ui.escapar(asig.descripcion || 'Sin descripción.')}</p>
          <div class="tarjeta-asignatura__meta">
            <span class="insignia ${grupos > 0 ? 'insignia--exito' : ''}">${etiquetaGrupos}</span>
          </div>
        </div>
        <footer class="tarjeta-asignatura__acciones">
          <button type="button" class="btn btn--secundario btn--pequeno btn-editar" data-id="${ui.escapar(asig.id)}">
            Editar
          </button>
          <button type="button" class="btn btn--peligro btn--pequeno btn-eliminar" data-id="${ui.escapar(asig.id)}">
            Eliminar
          </button>
        </footer>
      </article>
    `;
  }).join('');

  // Vincular eventos
  contenedor.querySelectorAll('.btn-editar').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const asig = asignaturas.find(a => a.id === id);
      if (asig) abrirModalAsignatura(asig);
    });
  });

  contenedor.querySelectorAll('.btn-eliminar').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const asig = asignaturas.find(a => a.id === id);
      if (asig) eliminarAsignatura(asig);
    });
  });
}

async function abrirModalAsignatura(asignatura = null) {
  const esEdicion = Boolean(asignatura);
  const tituloModal = esEdicion ? 'Editar asignatura' : 'Nueva asignatura';

  const form = document.createElement('form');
  form.className = 'formulario-modal';
  form.innerHTML = `
    <div class="campo-modal">
      <label for="asig-nombre">Nombre de la asignatura *</label>
      <input type="text" id="asig-nombre" required value="${ui.escapar(asignatura?.nombre || '')}" placeholder="Ej. Competencias Digitales" />
    </div>
    <div class="campo-modal">
      <label for="asig-nivel">Nivel académico *</label>
      <input type="text" id="asig-nivel" required value="${ui.escapar(asignatura?.nivel || 'MAESTRIA')}" placeholder="Ej. MAESTRIA, GRADO, DIPLOMADO" />
    </div>
    <div class="campo-modal">
      <label for="asig-descripcion">Descripción</label>
      <textarea id="asig-descripcion" rows="3" placeholder="Objetivos y alcance formativo">${ui.escapar(asignatura?.descripcion || '')}</textarea>
    </div>
  `;

  // Prevenir envío por defecto
  form.addEventListener('submit', e => e.preventDefault());

  const accion = await ui.modal({
    titulo: tituloModal,
    contenido: form,
    acciones: [
      { texto: 'Cancelar', valor: null, clase: 'btn--secundario' },
      { texto: esEdicion ? 'Guardar cambios' : 'Crear asignatura', valor: 'guardar', clase: 'btn--primario' }
    ]
  });

  if (accion !== 'guardar') return;

  const nombre = form.querySelector('#asig-nombre')?.value.trim();
  const nivel = form.querySelector('#asig-nivel')?.value.trim();
  const descripcion = form.querySelector('#asig-descripcion')?.value.trim();

  if (!nombre || !nivel) {
    ui.aviso('El nombre y el nivel son obligatorios.', 'error');
    return;
  }

  ui.cargando(true);
  try {
    if (esEdicion) {
      await api.actualizar('asignaturas', asignatura.id, { nombre, nivel, descripcion });
      ui.aviso('Asignatura actualizada exitosamente.', 'exito');
    } else {
      await api.crear('asignaturas', { nombre, nivel, descripcion });
      ui.aviso('Asignatura creada exitosamente.', 'exito');
    }
    await cargarDatos();
  } catch (err) {
    ui.aviso('Error al guardar asignatura: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function eliminarAsignatura(asig) {
  // Verificar si tiene grupos en distributivo
  const tieneGrupos = distributivo.some(g => g.asignaturaId === asig.id);
  if (tieneGrupos) {
    ui.aviso(`No se puede eliminar "${asig.nombre}" porque tiene grupos asignados en el distributivo.`, 'error');
    return;
  }

  const confirmado = await ui.confirmar(`¿Estás seguro de que deseas eliminar la asignatura "${asig.nombre}"? Esta acción no se puede deshacer.`);
  if (!confirmado) return;

  ui.cargando(true);
  try {
    await api.eliminar('asignaturas', asig.id);
    ui.aviso('Asignatura eliminada.', 'exito');
    await cargarDatos();
  } catch (err) {
    ui.aviso('Error al eliminar asignatura: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

inicializar();
