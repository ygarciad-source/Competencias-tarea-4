/**
 * Módulo quiz.js
 * Controlador de la experiencia interactiva de evaluación formativa por niveles de Bloom.
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import { obtenerTemaActividad } from '../nucleo/selector-tema.js';
import { mostrarRetro, mostrarResumen } from '../nucleo/retroalimentacion.js';
import { mostrarLogros } from '../nucleo/gamificacion.js';
import { generarDiploma } from '../nucleo/pdf.js';

await montarPlantilla({ titulo: 'Quiz por Niveles', roles: ['estudiante'] });

// Referencias del DOM
const vistaNiveles = document.getElementById('vista-niveles');
const vistaPregunta = document.getElementById('vista-pregunta');
const vistaCelebracion = document.getElementById('vista-celebracion');
const contenedorNiveles = document.getElementById('contenedor-tarjetas-niveles');
const subtituloTema = document.getElementById('quiz-subtitulo-tema');
const enlaceVolverTema = document.getElementById('enlace-tema-volver');
const btnCambiarTema = document.getElementById('btn-cambiar-tema');

// Elementos de la pregunta activa
const indicadorNivelActivo = document.getElementById('indicador-nivel-activo');
const contadorPregunta = document.getElementById('contador-pregunta-activa');
const barraProgresoQuiz = document.getElementById('barra-progreso-quiz');
const enunciadoReactivo = document.getElementById('enunciado-pregunta');
const tipoPreguntaBadge = document.getElementById('tipo-pregunta-badge');
const formRespuesta = document.getElementById('form-respuesta-quiz');
const btnResponder = document.getElementById('btn-responder');
const btnAbandonarQuiz = document.getElementById('btn-abandonar-quiz');

const contenedorRadio = document.getElementById('opciones-radio-contenedor');
const contenedorVF = document.getElementById('opciones-vf-contenedor');
const contenedorCompletar = document.getElementById('opciones-completar-contenedor');
const inputCompletar = document.getElementById('input-completar');

// Celebración
const celebracionTitulo = document.getElementById('celebracion-titulo');
const celebracionDescripcion = document.getElementById('celebracion-descripcion');
const btnDescargarDiploma = document.getElementById('btn-descargar-diploma');
const btnVolverNiveles = document.getElementById('btn-volver-niveles');

// Estado en memoria
let temaActual = null;
let nivelesEstado = [];
let sesionActiva = null; // { id, preguntas, indiceActual }
let nivelActivo = 1;
let respuestaSeleccionada = null;

const DESCRIPCIONES_BLOOM = {
  1: 'Recupera y reconoce hechos, marcos, terminología y conceptos clave del tema.',
  2: 'Explica ideas o principios, traduce significado e interpreta relaciones.',
  3: 'Aplica conceptos y directrices en situaciones y escenarios didácticos concretos.',
  4: 'Distingue entre componentes, detecta inconsistencias y evalúa alternativas.',
  5: 'Emite juicios críticos fundamentados y toma decisiones pedagógicas justificadas.'
};

async function inicializar() {
  try {
    temaActual = await obtenerTemaActividad();
    actualizarCabeceraTema();
    configurarEventosGenerales();
    await cargarEstadoNiveles();
  } catch (err) {
    console.error('Error al iniciar el módulo de quiz:', err);
  }
}

function actualizarCabeceraTema() {
  if (!temaActual) return;
  subtituloTema.innerHTML = `Tema curricular: <strong>${ui.escapar(temaActual.titulo)}</strong>`;
  if (enlaceVolverTema) {
    enlaceVolverTema.href = `/paginas/tema.html?id=${encodeURIComponent(temaActual.id)}`;
    enlaceVolverTema.textContent = temaActual.titulo;
  }
}

function configurarEventosGenerales() {
  btnCambiarTema?.addEventListener('click', async () => {
    try {
      // Eliminar el parámetro para forzar el selector
      const url = new URL(window.location.href);
      url.searchParams.delete('temaId');
      window.history.replaceState({}, '', url.toString());

      temaActual = await obtenerTemaActividad();
      actualizarCabeceraTema();
      await cargarEstadoNiveles();
    } catch (err) {
      console.warn('Cambio de tema cancelado:', err);
    }
  });

  btnAbandonarQuiz?.addEventListener('click', async () => {
    const confirmarSalir = await ui.confirmar('¿Estás seguro de salir del quiz en curso? Tu progreso en esta sesión no se guardará.');
    if (confirmarSalir) {
      sesionActiva = null;
      mostrarVista('niveles');
      await cargarEstadoNiveles();
    }
  });

  btnVolverNiveles?.addEventListener('click', async () => {
    mostrarVista('niveles');
    await cargarEstadoNiveles();
  });

  btnDescargarDiploma?.addEventListener('click', async () => {
    try {
      ui.cargando(true);
      await generarDiploma({
        tipo: 'nivel-quiz',
        temaId: temaActual.id,
        nivel: nivelActivo
      });
    } catch (err) {
      ui.aviso('Error al generar diploma: ' + err.message, 'error');
    } finally {
      ui.cargando(false);
    }
  });

  formRespuesta?.addEventListener('submit', async (e) => {
    e.preventDefault();
    await enviarRespuestaActual();
  });
}

function mostrarVista(vista) {
  vistaNiveles.style.display = vista === 'niveles' ? 'block' : 'none';
  vistaPregunta.style.display = vista === 'pregunta' ? 'block' : 'none';
  vistaCelebracion.style.display = vista === 'celebracion' ? 'block' : 'none';
}

/**
 * Carga el estado de los 5 niveles cognitivos desde el servidor
 */
async function cargarEstadoNiveles() {
  if (!temaActual) return;
  ui.cargando(true);
  try {
    const res = await api.llamar('GET', `/api/quiz/estado?temaId=${encodeURIComponent(temaActual.id)}`);
    nivelesEstado = res?.niveles || [];
    renderizarTarjetasNiveles();
  } catch (err) {
    ui.aviso('Error al cargar niveles: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

/**
 * Renderiza las 5 tarjetas de nivel Bloom
 */
function renderizarTarjetasNiveles() {
  if (!contenedorNiveles) return;

  contenedorNiveles.innerHTML = nivelesEstado.map(n => {
    const desc = DESCRIPCIONES_BLOOM[n.nivel] || '';
    const estado = n.estado || 'bloqueado';
    const pct = n.mejorPorcentaje || 0;

    let insigniaEstado = '';
    let botonHtml = '';
    let claseTarjeta = `tarjeta-nivel-bloom tarjeta-nivel-bloom--${estado}`;

    if (estado === 'bloqueado') {
      insigniaEstado = '<span class="insignia">🔒 Bloqueado</span>';
      botonHtml = `
        <button type="button" class="btn btn--secundario btn--bloque" disabled>
          Nivel Bloqueado
        </button>
      `;
    } else if (estado === 'disponible') {
      insigniaEstado = '<span class="insignia insignia--acento">⚡ Disponible</span>';
      botonHtml = `
        <button type="button" class="btn btn--acento btn--bloque btn-iniciar-nivel" data-nivel="${n.nivel}">
          Comenzar Nivel ${n.nivel} →
        </button>
      `;
    } else if (estado === 'aprobado') {
      insigniaEstado = '<span class="insignia insignia--exito">🏅 Aprobado ✓</span>';
      botonHtml = `
        <div class="fila" style="gap: var(--espacio-xs); flex-direction: column;">
          <button type="button" class="btn btn--secundario btn--bloque btn-iniciar-nivel" data-nivel="${n.nivel}">
            🔄 Reintentar nivel
          </button>
          <button type="button" class="btn btn--texto btn--bloque btn-descargar-diploma-tarjeta" data-nivel="${n.nivel}" style="color: var(--color-primario); font-size: var(--tamano-xs);">
            📜 Descargar diploma
          </button>
        </div>
      `;
    }

    return `
      <article class="${claseTarjeta}">
        <div>
          <header class="tarjeta-nivel-bloom__cabecera">
            <span class="tarjeta-nivel-bloom__numero">Nivel ${n.nivel} · Bloom</span>
            ${insigniaEstado}
          </header>

          <h3 class="tarjeta-nivel-bloom__titulo">${ui.escapar(n.nombre)}</h3>
          <p class="tarjeta-nivel-bloom__desc">${ui.escapar(desc)}</p>
        </div>

        <div>
          <div class="tarjeta-nivel-bloom__meta">
            <span>Mejor rendimiento:</span>
            <strong>${pct}%</strong>
          </div>

          <footer class="tarjeta-nivel-bloom__pie">
            ${botonHtml}
          </footer>
        </div>
      </article>
    `;
  }).join('');

  // Vincular eventos a los botones de nivel
  contenedorNiveles.querySelectorAll('.btn-iniciar-nivel').forEach(btn => {
    btn.addEventListener('click', () => {
      const nivel = Number(btn.getAttribute('data-nivel'));
      iniciarQuizNivel(nivel);
    });
  });

  contenedorNiveles.querySelectorAll('.btn-descargar-diploma-tarjeta').forEach(btn => {
    btn.addEventListener('click', async () => {
      const nivel = Number(btn.getAttribute('data-nivel'));
      ui.cargando(true);
      try {
        await generarDiploma({
          tipo: 'nivel-quiz',
          temaId: temaActual.id,
          nivel
        });
      } catch (err) {
        ui.aviso('Error al generar diploma: ' + err.message, 'error');
      } finally {
        ui.cargando(false);
      }
    });
  });
}

/**
 * 2. Inicia un nivel de quiz en el backend
 */
async function iniciarQuizNivel(nivel) {
  nivelActivo = nivel;
  ui.cargando(true);

  try {
    const res = await api.llamar('POST', '/api/quiz/iniciar', {
      temaId: temaActual.id,
      nivel
    });

    if (!res || !res.sesionId || !Array.isArray(res.preguntas) || res.preguntas.length === 0) {
      throw new Error('No se recibieron preguntas para este nivel');
    }

    sesionActiva = {
      id: res.sesionId,
      preguntas: res.preguntas,
      indiceActual: 0,
      total: res.preguntas.length
    };

    mostrarVista('pregunta');
    renderizarPreguntaActual();
  } catch (err) {
    ui.aviso('Error al iniciar el quiz: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

/**
 * Renderiza la pregunta activa de la sesión
 */
function renderizarPreguntaActual() {
  if (!sesionActiva) return;

  const { preguntas, indiceActual, total } = sesionActiva;
  const pregunta = preguntas[indiceActual];
  const numeroPregunta = indiceActual + 1;

  // Actualizar indicadores de avance
  indicadorNivelActivo.textContent = `Nivel ${nivelActivo} · ${DESCRIPCIONES_BLOOM[nivelActivo] ? nivelesEstado.find(n => n.nivel === nivelActivo)?.nombre || '' : ''}`;
  contadorPregunta.textContent = `Pregunta ${numeroPregunta} de ${total}`;
  const porcentajeAvance = Math.round(((indiceActual) / total) * 100);
  barraProgresoQuiz.style.width = `${porcentajeAvance}%`;
  barraProgresoQuiz.parentElement.setAttribute('aria-valuenow', porcentajeAvance);

  // Enunciado
  enunciadoReactivo.textContent = pregunta.enunciado;
  tipoPreguntaBadge.textContent = pregunta.tipo === 'opcion'
    ? 'Opción múltiple'
    : pregunta.tipo === 'vf'
      ? 'Verdadero o Falso'
      : 'Completar enunciado';

  // Reiniciar estado de respuesta
  respuestaSeleccionada = null;
  btnResponder.disabled = true;

  // Ocultar todos los contenedores de opciones
  contenedorRadio.style.display = 'none';
  contenedorVF.style.display = 'none';
  contenedorCompletar.style.display = 'none';

  // Renderizar según el tipo
  if (pregunta.tipo === 'opcion') {
    contenedorRadio.style.display = 'flex';
    contenedorRadio.innerHTML = (pregunta.opciones || []).map((opc, idx) => `
      <label class="opcion-radio-card" data-idx="${idx}">
        <input type="radio" name="opcion-quiz" value="${idx}">
        <span class="opcion-radio-card__texto">${ui.escapar(String(opc))}</span>
      </label>
    `).join('');

    contenedorRadio.querySelectorAll('.opcion-radio-card').forEach(card => {
      card.addEventListener('click', () => {
        contenedorRadio.querySelectorAll('.opcion-radio-card').forEach(c => c.classList.remove('seleccionada'));
        card.classList.add('seleccionada');
        const radio = card.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;
        respuestaSeleccionada = Number(card.getAttribute('data-idx'));
        btnResponder.disabled = false;
      });
    });
  } else if (pregunta.tipo === 'vf') {
    contenedorVF.style.display = 'grid';
    contenedorVF.innerHTML = `
      <button type="button" class="btn-opcion-vf" data-val="true">
        <span>👍</span>
        <span>Verdadero</span>
      </button>
      <button type="button" class="btn-opcion-vf" data-val="false">
        <span>👎</span>
        <span>Falso</span>
      </button>
    `;

    contenedorVF.querySelectorAll('.btn-opcion-vf').forEach(btn => {
      btn.addEventListener('click', () => {
        contenedorVF.querySelectorAll('.btn-opcion-vf').forEach(b => b.classList.remove('seleccionado'));
        btn.classList.add('seleccionado');
        respuestaSeleccionada = btn.getAttribute('data-val') === 'true';
        btnResponder.disabled = false;
      });
    });
  } else if (pregunta.tipo === 'completar') {
    contenedorCompletar.style.display = 'block';
    inputCompletar.value = '';
    inputCompletar.focus();

    inputCompletar.oninput = () => {
      const val = inputCompletar.value.trim();
      respuestaSeleccionada = val;
      btnResponder.disabled = !val;
    };
  }
}

/**
 * Envía la respuesta de la pregunta actual y muestra retroalimentación
 */
async function enviarRespuestaActual() {
  if (!sesionActiva || respuestaSeleccionada === null || respuestaSeleccionada === undefined) {
    return;
  }

  const { preguntas, indiceActual } = sesionActiva;
  const pregunta = preguntas[indiceActual];

  ui.cargando(true);
  try {
    const res = await api.llamar('POST', '/api/quiz/responder', {
      sesionId: sesionActiva.id,
      preguntaId: pregunta.id,
      respuesta: respuestaSeleccionada
    });

    ui.cargando(false);

    // Desplegar retroalimentación pedagógica
    await mostrarRetro({
      correcto: res.correcto,
      explicacion: res.retroalimentacion,
      sugerencia: `Respuesta correcta: ${res.correcta}`,
      enlaceTema: `/paginas/tema.html?id=${encodeURIComponent(temaActual.id)}`
    });

    // Avanzar a la siguiente pregunta o finalizar
    sesionActiva.indiceActual++;

    if (sesionActiva.indiceActual < sesionActiva.total) {
      renderizarPreguntaActual();
    } else {
      await finalizarQuizSesion();
    }
  } catch (err) {
    ui.cargando(false);
    ui.aviso('Error al responder: ' + err.message, 'error');
  }
}

/**
 * 3. Finaliza el quiz en el servidor y procesa resultados
 */
async function finalizarQuizSesion() {
  ui.cargando(true);

  try {
    const res = await api.llamar('POST', '/api/quiz/finalizar', {
      sesionId: sesionActiva.id
    });

    ui.cargando(false);

    // 1. Mostrar resumen con porcentaje y temas a repasar
    const accion = await mostrarResumen({
      titulo: `Evaluación Finalizada · Nivel ${nivelActivo}`,
      aciertos: res.aciertos,
      errores: res.total - res.aciertos,
      recomendaciones: res.repasar,
      enlaceTema: `/paginas/tema.html?id=${encodeURIComponent(temaActual.id)}`
    });

    // 2. Si aprobó, mostrar logros y opción de descargar diploma
    if (res.aprobado) {
      await mostrarLogros({
        puntosGanados: res.puntosGanados,
        insigniasNuevas: res.insigniasNuevas
      });

      mostrarVista('celebracion');
      celebracionTitulo.textContent = `¡Has superado el Nivel ${nivelActivo}!`;
      celebracionDescripcion.innerHTML = `
        Obtuviste <strong>${res.porcentaje}%</strong> de aciertos (${res.aciertos} de ${res.total}).
        ${nivelActivo < 5 ? `<br>El Nivel ${nivelActivo + 1} ha sido desbloqueado.` : '<br>¡Completaste todos los niveles cognitivos!'}
      `;
    } else {
      if (accion === 'repetir') {
        // Reintentar inmediatamente con preguntas nuevas
        await iniciarQuizNivel(nivelActivo);
      } else {
        mostrarVista('niveles');
        await cargarEstadoNiveles();
      }
    }
  } catch (err) {
    ui.cargando(false);
    ui.aviso('Error al finalizar el quiz: ' + err.message, 'error');
    mostrarVista('niveles');
    await cargarEstadoNiveles();
  }
}

inicializar();
