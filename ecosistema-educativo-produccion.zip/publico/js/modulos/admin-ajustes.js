/**
 * Módulo admin-ajustes.js
 * Panel de administración para configurar la clave de API y el modelo de IA.
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';

await montarPlantilla({ titulo: 'Configuración de IA', roles: ['admin'] });

const formAjustes = document.getElementById('form-ajustes-ia');
const inputClave = document.getElementById('ia-clave');
const inputModelo = document.getElementById('ia-modelo');
const inputProveedor = document.getElementById('ia-proveedor');
const inputLimite = document.getElementById('ia-limite-diario');
const btnToggleClave = document.getElementById('btn-toggle-clave');
const btnProbarIA = document.getElementById('btn-probar-ia');
const contenedorResultado = document.getElementById('contenedor-resultado-prueba');

async function inicializar() {
  await cargarAjustes();
  configurarEventos();
}

/**
 * Carga los ajustes actuales desde el backend
 */
async function cargarAjustes() {
  ui.cargando(true);
  try {
    const ajustes = await api.llamar('GET', '/api/admin/ajustes');
    if (ajustes) {
      inputModelo.value = ajustes.iaModelo || 'gemini-3.5-flash';
      inputClave.value = ajustes.iaClave || '';
      inputProveedor.value = ajustes.iaProveedor || 'gemini';
      inputLimite.value = ajustes.limiteIADiario || 30;
    }
  } catch (err) {
    ui.aviso('Error al cargar configuración: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function configurarEventos() {
  // Alternar visualización de la clave
  btnToggleClave.addEventListener('click', () => {
    if (inputClave.type === 'password') {
      inputClave.type = 'text';
      btnToggleClave.textContent = '🔒 Ocultar';
    } else {
      inputClave.type = 'password';
      btnToggleClave.textContent = '👁 Mostrar';
    }
  });

  // Guardar configuración
  formAjustes.addEventListener('submit', async (e) => {
    e.preventDefault();
    const nuevos = {
      iaProveedor: inputProveedor.value.trim() || 'gemini',
      iaModelo: inputModelo.value.trim() || 'gemini-3.5-flash',
      iaClave: inputClave.value.trim(),
      limiteIADiario: Number(inputLimite.value) || 30
    };

    if (!nuevos.iaClave) {
      ui.aviso('Debes proporcionar una clave de API válida para Gemini', 'error');
      inputClave.focus();
      return;
    }

    ui.cargando(true);
    try {
      const res = await api.llamar('PUT', '/api/admin/ajustes', nuevos);
      ui.aviso(res.mensaje || 'Configuración guardada exitosamente.', 'exito');
    } catch (err) {
      ui.aviso('Error al guardar ajustes: ' + err.message, 'error');
    } finally {
      ui.cargando(false);
    }
  });

  // Probar conexión con IA
  btnProbarIA.addEventListener('click', async () => {
    contenedorResultado.style.display = 'block';
    contenedorResultado.innerHTML = `
      <div class="resultado-prueba" style="background: var(--color-fondo);">
        <span>⏳ Conectando con Google Gemini (${ui.escapar(inputModelo.value.trim() || 'gemini-3.5-flash')})...</span>
      </div>
    `;

    try {
      const res = await api.llamar('GET', '/api/ia/prueba');
      if (res && res.ok) {
        contenedorResultado.innerHTML = `
          <div class="resultado-prueba resultado-prueba--exito">
            <span style="font-size: 1.5rem;">✔</span>
            <div>
              <strong>Conexión exitosa con ${ui.escapar(res.modelo)}</strong>
              <p style="margin: 0; font-size: var(--tamano-xs);">Respuesta: "${ui.escapar(res.respuesta)}" (${res.latenciaMs} ms)</p>
            </div>
          </div>
        `;
        ui.aviso('Conexión con Gemini verificada con éxito', 'exito');
      } else {
        throw new Error(res.error || 'Respuesta inválida');
      }
    } catch (err) {
      contenedorResultado.innerHTML = `
        <div class="resultado-prueba resultado-prueba--error">
          <span style="font-size: 1.5rem;">✕</span>
          <div>
            <strong>Error de conexión</strong>
            <p style="margin: 0; font-size: var(--tamano-xs);">${ui.escapar(err.message)}</p>
          </div>
        </div>
      `;
      ui.aviso('Error de conexión con la IA: ' + err.message, 'error');
    }
  });
}

inicializar();
