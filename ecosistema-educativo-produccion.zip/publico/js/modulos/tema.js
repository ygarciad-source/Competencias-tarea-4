/**
 * Módulo tema.js
 * Visualización pedagógica del tema para estudiantes y docentes.
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';
import { ACTIVIDADES } from '../nucleo/catalogo-actividades.js';

let temaId = null;
let tema = null;
let unidad = null;
let asignatura = null;
let yaRevisado = false;

async function inicializar() {
  await montarPlantilla({ titulo: 'Estudio de Tema', roles: ['estudiante', 'docente'] });

  temaId = util.parametro('id');
  if (!temaId) {
    ui.aviso('No se especificó ningún tema para estudiar.', 'error');
    setTimeout(() => {
      window.location.href = '/paginas/asignaturas.html';
    }, 1500);
    return;
  }

  await cargarDatos();
}

async function cargarDatos() {
  ui.cargando(true);
  try {
    const [t, listaProgreso] = await Promise.all([
      api.obtener('temas', temaId),
      api.listar('progreso-temas', { temaId })
    ]);

    tema = t;
    yaRevisado = Array.isArray(listaProgreso) && listaProgreso.length > 0;

    // Obtener unidad y asignatura vinculadas
    if (t.unidadId) {
      try {
        unidad = await api.obtener('unidades', t.unidadId);
        if (unidad && unidad.asignaturaId) {
          asignatura = await api.obtener('asignaturas', unidad.asignaturaId);
        }
      } catch (e) {
        console.warn('No se pudo cargar la jerarquía de unidad/asignatura:', e);
      }
    }

    // Guardar último tema en localStorage
    try {
      localStorage.setItem('ultimoTema', JSON.stringify({
        id: tema.id,
        titulo: tema.titulo
      }));
    } catch {
      // Ignorar si storage no está disponible
    }

    renderizarMigas();
    renderizarContenido();
    configurarBotonRevisado();
    renderizarPractica();
  } catch (err) {
    ui.aviso('Error al cargar el tema: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function renderizarMigas() {
  const migaAsig = document.getElementById('miga-asignatura');
  const migaUni = document.getElementById('miga-unidad');
  const migaTema = document.getElementById('miga-tema');

  if (migaAsig) {
    if (asignatura) {
      migaAsig.innerHTML = `<a href="/paginas/asignatura.html?id=${encodeURIComponent(asignatura.id)}">${ui.escapar(asignatura.nombre)}</a>`;
    } else {
      migaAsig.innerHTML = `<span>Asignatura</span>`;
    }
  }

  if (migaUni) {
    migaUni.innerHTML = `<span>${ui.escapar(unidad?.titulo || 'Unidad')}</span>`;
  }

  if (migaTema) {
    migaTema.innerHTML = `<strong>${ui.escapar(tema.titulo)}</strong>`;
  }
}

function renderizarContenido() {
  // Metadatos de cabecera
  const ordenBadge = document.getElementById('tema-orden-badge');
  const difBadge = document.getElementById('tema-dificultad-badge');
  const tituloEl = document.getElementById('tema-titulo');

  if (ordenBadge) ordenBadge.textContent = `Tema ${tema.orden || 1}`;
  if (difBadge) difBadge.textContent = `Dificultad: ${tema.dificultad || 'media'}`;
  if (tituloEl) tituloEl.textContent = tema.titulo;

  // Objetivos
  const secObjetivos = document.getElementById('seccion-objetivos');
  const listaObj = document.getElementById('lista-objetivos');
  if (Array.isArray(tema.objetivos) && tema.objetivos.length > 0) {
    listaObj.innerHTML = tema.objetivos.map(obj => `<li>${ui.escapar(obj)}</li>`).join('');
  } else if (secObjetivos) {
    secObjetivos.style.display = 'none';
  }

  // Resumen formativo con util.formatoBasico
  const resumenEl = document.getElementById('tema-resumen');
  if (resumenEl) {
    if (tema.resumen) {
      resumenEl.innerHTML = util.formatoBasico(tema.resumen);
    } else {
      resumenEl.innerHTML = `<p style="color: var(--color-texto-secundario); font-style: italic;">Sin contenido formativo registrado.</p>`;
    }
  }

  // Ejemplos
  const secEjemplos = document.getElementById('seccion-ejemplos');
  const listaEjem = document.getElementById('lista-ejemplos');
  if (Array.isArray(tema.ejemplos) && tema.ejemplos.length > 0) {
    listaEjem.innerHTML = tema.ejemplos.map(ejem => `<li>${ui.escapar(ejem)}</li>`).join('');
  } else if (secEjemplos) {
    secEjemplos.style.display = 'none';
  }

  // Recursos multimedia
  renderizarRecursos();
}

function renderizarRecursos() {
  const secRecursos = document.getElementById('seccion-recursos');
  const contenedor = document.getElementById('contenedor-recursos');
  if (!contenedor) return;

  const recursos = Array.isArray(tema.recursos) ? tema.recursos : [];
  if (recursos.length === 0) {
    if (secRecursos) secRecursos.style.display = 'none';
    return;
  }

  contenedor.innerHTML = recursos.map(rec => {
    const url = rec.url || '';
    const titulo = rec.titulo || 'Recurso didáctico';
    const tipo = (rec.tipo || '').toLowerCase();

    // YouTube embed
    const ytMatch = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i);
    if (ytMatch) {
      const videoId = ytMatch[1];
      return `
        <div class="recurso-tarjeta recurso-tarjeta--video">
          <h4 class="recurso-tarjeta__titulo">${ui.escapar(titulo)}</h4>
          <div class="video-contenedor">
            <iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(videoId)}" title="${ui.escapar(titulo)}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
      `;
    }

    // Vimeo embed
    const vimeoMatch = url.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
    if (vimeoMatch) {
      const videoId = vimeoMatch[1];
      return `
        <div class="recurso-tarjeta recurso-tarjeta--video">
          <h4 class="recurso-tarjeta__titulo">${ui.escapar(titulo)}</h4>
          <div class="video-contenedor">
            <iframe src="https://player.vimeo.com/video/${encodeURIComponent(videoId)}" title="${ui.escapar(titulo)}" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
      `;
    }

    // Imagen
    const esImagen = tipo === 'imagen' || /\.(jpe?g|png|webp|gif|svg)(\?.*)?$/i.test(url);
    if (esImagen) {
      return `
        <div class="recurso-tarjeta recurso-tarjeta--imagen">
          <h4 class="recurso-tarjeta__titulo">${ui.escapar(titulo)}</h4>
          <img src="${ui.escapar(url)}" alt="${ui.escapar(titulo)}" class="recurso-imagen" loading="lazy" />
        </div>
      `;
    }

    // PDF
    const esPdf = tipo === 'pdf' || /\.pdf(\?.*)?$/i.test(url);
    if (esPdf) {
      return `
        <div class="recurso-tarjeta recurso-tarjeta--enlace">
          <div class="recurso-tarjeta__info">
            <span class="insignia insignia--primario">PDF</span>
            <strong class="recurso-tarjeta__titulo">${ui.escapar(titulo)}</strong>
          </div>
          <a href="${ui.escapar(url)}" target="_blank" rel="noopener noreferrer" class="btn btn--secundario btn--pequeno">
            📄 Descargar / Ver PDF ↗
          </a>
        </div>
      `;
    }

    // Enlace genérico
    return `
      <div class="recurso-tarjeta recurso-tarjeta--enlace">
        <div class="recurso-tarjeta__info">
          <span class="insignia">Enlace</span>
          <strong class="recurso-tarjeta__titulo">${ui.escapar(titulo)}</strong>
        </div>
        <a href="${ui.escapar(url)}" target="_blank" rel="noopener noreferrer" class="btn btn--secundario btn--pequeno">
          Abrir enlace ↗
        </a>
      </div>
    `;
  }).join('');
}

function configurarBotonRevisado() {
  const btn = document.getElementById('btn-marcar-revisado');
  if (!btn) return;

  if (yaRevisado) {
    btn.textContent = 'Revisado ✓';
    btn.className = 'btn btn--exito';
    btn.disabled = true;
    return;
  }

  btn.textContent = 'Marcar como revisado';
  btn.className = 'btn btn--primario';
  btn.disabled = false;

  btn.onclick = async () => {
    ui.cargando(true);
    try {
      await api.crear('progreso-temas', { temaId: tema.id });
      yaRevisado = true;
      btn.textContent = 'Revisado ✓';
      btn.className = 'btn btn--exito';
      btn.disabled = true;
      ui.aviso('¡Tema completado! Tu progreso ha sido registrado.', 'exito');
    } catch (err) {
      ui.aviso('No se pudo registrar el progreso: ' + err.message, 'error');
    } finally {
      ui.cargando(false);
    }
  };
}

function renderizarPractica() {
  const contenedor = document.getElementById('contenedor-actividades');
  if (!contenedor) return;

  if (!Array.isArray(ACTIVIDADES) || ACTIVIDADES.length === 0) {
    contenedor.innerHTML = `
      <p style="color: var(--color-texto-secundario); font-size: var(--tamano-s); margin: 0; line-height: var(--linea-normal);">
        Próximamente habrá actividades interactivas disponibles para este tema.
      </p>
    `;
    return;
  }

  contenedor.innerHTML = ACTIVIDADES.map(act => `
    <a href="${ui.escapar(act.href)}?temaId=${encodeURIComponent(tema.id)}" class="tarjeta-actividad-item">
      <h3 class="tarjeta-actividad-item__titulo">${ui.escapar(act.texto)}</h3>
      <p class="tarjeta-actividad-item__desc">${ui.escapar(act.descripcion || '')}</p>
    </a>
  `).join('');
}

inicializar();
