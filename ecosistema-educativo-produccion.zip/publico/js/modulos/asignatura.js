/**
 * Módulo asignatura.js
 * Detalle de asignatura con unidades visibles y temas con estado Revisado o Pendiente.
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';
import { calcularAvance } from './asignaturas.js';

let asignaturaId = null;
let asignatura = null;

async function inicializar() {
  await montarPlantilla({ titulo: 'Detalle de Asignatura', roles: ['estudiante', 'docente'] });

  asignaturaId = util.parametro('id');
  if (!asignaturaId) {
    ui.aviso('No se especificó ninguna asignatura.', 'error');
    setTimeout(() => {
      window.location.href = '/paginas/asignaturas.html';
    }, 1500);
    return;
  }

  await cargarDatos();
}

async function cargarDatos() {
  ui.cargando(true);
  try {
    const [asig, avance, unidades, todosTemas] = await Promise.all([
      api.obtener('asignaturas', asignaturaId),
      calcularAvance(asignaturaId),
      api.listar('unidades', { asignaturaId }),
      api.listar('temas')
    ]);

    asignatura = asig;
    actualizarCabecera(asig, avance);
    renderizarContenido(unidades, todosTemas, avance.revisadosIds);
    configurarTutorSocratico(asig, unidades, todosTemas);
  } catch (err) {
    ui.aviso('Error al cargar la asignatura: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function actualizarCabecera(asig, avance) {
  document.getElementById('asig-nivel').textContent = asig.nivel || 'General';
  document.getElementById('asig-titulo').textContent = asig.nombre;
  document.getElementById('asig-desc').textContent = asig.descripcion || 'Sin descripción disponible.';

  const { porcentaje, revisados, total } = avance;
  const txtProgreso = document.getElementById('progreso-texto');
  const barraProgreso = document.getElementById('progreso-barra');
  const detalleProgreso = document.getElementById('progreso-detalle');

  if (txtProgreso) txtProgreso.textContent = `${porcentaje}%`;
  if (barraProgreso) barraProgreso.style.width = `${porcentaje}%`;
  if (detalleProgreso) {
    detalleProgreso.textContent = `${revisados} de ${total} tema${total === 1 ? '' : 's'} revisado${total === 1 ? '' : 's'}`;
  }
}

function renderizarContenido(unidades, todosTemas, revisadosIds) {
  const contenedor = document.getElementById('contenedor-unidades');
  if (!contenedor) return;

  const unidadesVisibles = (unidades || [])
    .filter(u => u.visible !== false)
    .sort((a, b) => (a.orden || 0) - (b.orden || 0));

  if (unidadesVisibles.length === 0) {
    contenedor.innerHTML = `
      <div class="tarjeta" style="text-align: center; padding: var(--espacio-xxl);">
        <p style="color: var(--color-texto-secundario); margin: 0;">
          Esta asignatura aún no tiene unidades formativas visibles.
        </p>
      </div>
    `;
    return;
  }

  // Agrupar temas publicados por unidad
  const temasPorUnidad = new Map();
  (todosTemas || [])
    .filter(t => t.estado === 'publicado')
    .forEach(t => {
      if (!temasPorUnidad.has(t.unidadId)) {
        temasPorUnidad.set(t.unidadId, []);
      }
      temasPorUnidad.get(t.unidadId).push(t);
    });

  contenedor.innerHTML = unidadesVisibles.map(unidad => {
    const temas = (temasPorUnidad.get(unidad.id) || [])
      .sort((a, b) => (a.orden || 0) - (b.orden || 0));

    return `
      <article class="tarjeta-unidad" data-id="${ui.escapar(unidad.id)}">
        <header class="tarjeta-unidad__cabecera">
          <div>
            <span style="font-size: var(--tamano-xs); color: var(--color-texto-secundario); font-weight: var(--peso-seminegrita);">
              UNIDAD ${ui.escapar(String(unidad.orden || 1))}
            </span>
            <h3 class="tarjeta-unidad__titulo">${ui.escapar(unidad.titulo)}</h3>
          </div>
          <span class="tarjeta-unidad__conteo">${temas.length} tema${temas.length === 1 ? '' : 's'}</span>
        </header>

        <ul class="lista-temas-unidad" aria-label="Temas de la unidad ${ui.escapar(unidad.titulo)}">
          ${temas.length === 0 ? `
            <li style="font-size: var(--tamano-s); color: var(--color-texto-secundario); padding: var(--espacio-s);">
              No hay temas publicados en esta unidad.
            </li>
          ` : temas.map(tema => {
            const estaRevisado = revisadosIds.has(tema.id);
            return `
              <li class="item-tema-estudiante">
                <div class="item-tema-estudiante__info">
                  <span class="item-tema-estudiante__orden">T${ui.escapar(String(tema.orden || 1))}</span>
                  <h4 class="item-tema-estudiante__titulo">${ui.escapar(tema.titulo)}</h4>
                </div>
                <div class="item-tema-estudiante__acciones">
                  <span class="insignia ${estaRevisado ? 'insignia--exito' : ''}">
                    ${estaRevisado ? 'Revisado ✓' : 'Pendiente'}
                  </span>
                  <a href="/paginas/tema.html?id=${encodeURIComponent(tema.id)}" class="btn btn--primario btn--pequeno" style="text-decoration: none;">
                    Estudiar tema →
                  </a>
                </div>
              </li>
            `;
          }).join('')}
        </ul>
      </article>
    `;
  }).join('');
}

/* ==========================================================================
   Tutor Socrático con Inteligencia Artificial
   ========================================================================== */

let tutorHistorial = [];
let tutorConfigurado = false;
let tutorEnviando = false;

/**
 * Configura la interacción con el tutor socrático para la asignatura activa.
 * @param {object} asig - Objeto de asignatura
 * @param {Array} unidades - Lista de unidades
 * @param {Array} todosTemas - Lista de todos los temas
 */
function configurarTutorSocratico(asig, unidades, todosTemas) {
  if (tutorConfigurado) return;
  tutorConfigurado = true;

  const modal = document.getElementById('modal-tutor');
  const btnAbrirBanner = document.getElementById('btn-abrir-tutor-banner');
  const btnFlotante = document.getElementById('btn-flotante-tutor');
  const btnCerrar = document.getElementById('btn-cerrar-tutor');
  const overlay = document.getElementById('tutor-overlay');
  const form = document.getElementById('tutor-formulario');
  const input = document.getElementById('tutor-input');
  const contMensajes = document.getElementById('tutor-mensajes');
  const subtituloAsig = document.getElementById('tutor-asig-subtitulo');
  const chipsRapidos = document.getElementById('tutor-chips-rapidos');
  const chipsBanner = document.getElementById('tutor-sugerencias-banner');

  if (subtituloAsig && asig) {
    subtituloAsig.textContent = `${asig.nombre} (${asig.nivel || 'Nivel Superior'})`;
  }

  // Filtrar temas publicados de esta asignatura
  const unidadesIds = new Set((unidades || []).map(u => u.id));
  const temasAsig = (todosTemas || [])
    .filter(t => unidadesIds.has(t.unidadId) && t.estado === 'publicado')
    .sort((a, b) => (a.orden || 0) - (b.orden || 0));

  // Renderizar chips de temas en el pie del chat
  if (chipsRapidos && temasAsig.length > 0) {
    chipsRapidos.innerHTML = temasAsig.slice(0, 5).map(t => `
      <button type="button" class="chip-rapido" data-pregunta="¿Podrías orientarme sobre el tema: '${ui.escapar(t.titulo)}'?">
        📖 ${ui.escapar(t.titulo)}
      </button>
    `).join('');

    chipsRapidos.addEventListener('click', (e) => {
      const btn = e.target.closest('.chip-rapido');
      if (btn && btn.dataset.pregunta) {
        enviarPregunta(btn.dataset.pregunta);
      }
    });
  }

  // Manejador para chips en el banner principal
  if (chipsBanner) {
    chipsBanner.addEventListener('click', (e) => {
      const btn = e.target.closest('.chip-sugerencia');
      if (btn && btn.dataset.pregunta) {
        abrirChat();
        enviarPregunta(btn.dataset.pregunta);
      }
    });
  }

  function abrirChat() {
    if (!modal) return;
    modal.classList.add('activo');
    modal.setAttribute('aria-hidden', 'false');

    // Mensaje de bienvenida inicial si está vacío
    if (contMensajes && contMensajes.children.length === 0) {
      const nombreAsignatura = asig ? asig.nombre : 'esta asignatura';
      const saludoInicial = `¡Hola! 👋 Soy tu **Tutor Socrático** para la asignatura **${nombreAsignatura}**.

Mi propósito es ayudarte a reflexionar, analizar y construir tu propio aprendizaje. En lugar de darte respuestas hechas de inmediato, te acompañaré con preguntas orientadoras y contraejemplos para que razones cada concepto.

Recuerda que responderé exclusivamente a consultas relacionadas con los contenidos y temas de esta materia. ¿Sobre qué tema o duda te gustaría reflexionar hoy?`;
      agregarMensajeUI('tutor', saludoInicial);
    }

    if (input) {
      setTimeout(() => input.focus(), 150);
    }
  }

  function cerrarChat() {
    if (!modal) return;
    modal.classList.remove('activo');
    modal.setAttribute('aria-hidden', 'true');
  }

  // Eventos de apertura y cierre
  if (btnAbrirBanner) btnAbrirBanner.addEventListener('click', abrirChat);
  if (btnFlotante) btnFlotante.addEventListener('click', abrirChat);
  if (btnCerrar) btnCerrar.addEventListener('click', cerrarChat);
  if (overlay) overlay.addEventListener('click', cerrarChat);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal && modal.classList.contains('activo')) {
      cerrarChat();
    }
  });

  // Ajuste automático de altura de textarea
  if (input) {
    input.addEventListener('input', () => {
      input.style.height = 'auto';
      input.style.height = `${Math.min(input.scrollHeight, 120)}px`;
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        enviarPregunta();
      }
    });
  }

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      enviarPregunta();
    });
  }

  /**
   * Envía una pregunta al tutor socrático
   * @param {string} [textoDirecto]
   */
  async function enviarPregunta(textoDirecto) {
    if (tutorEnviando) return;

    const texto = (textoDirecto || (input ? input.value : '')).trim();
    if (!texto) return;

    if (input) {
      input.value = '';
      input.style.height = 'auto';
    }

    // Agregar mensaje del estudiante
    agregarMensajeUI('estudiante', texto);
    tutorHistorial.push({ rol: 'estudiante', texto });

    // Mostrar estado de reflexión
    tutorEnviando = true;
    bloquearControles(true);
    const indicador = mostrarIndicadorReflexion();

    try {
      const res = await api.ia('tutor', {
        asignaturaId: asig.id,
        mensaje: texto,
        historial: tutorHistorial
      });

      indicador.remove();

      const respuestaTutor = (res && res.respuesta)
        ? res.respuesta
        : 'Interesante planteamiento. ¿Cómo definirías tú este concepto a partir de lo visto en la clase?';

      agregarMensajeUI('tutor', respuestaTutor);
      tutorHistorial.push({ rol: 'tutor', texto: respuestaTutor });
    } catch (err) {
      indicador.remove();
      const errorMsg = err.message || 'Ocurrió un error al consultar al tutor socrático.';
      agregarMensajeUI('tutor', `⚠️ ${errorMsg}`);
    } finally {
      tutorEnviando = false;
      bloquearControles(false);
      if (input) input.focus();
    }
  }

  function bloquearControles(bloquear) {
    const btnEnviar = document.getElementById('tutor-btn-enviar');
    if (btnEnviar) btnEnviar.disabled = bloquear;
    if (input) input.disabled = bloquear;
  }

  function mostrarIndicadorReflexion() {
    const contenedor = document.createElement('div');
    contenedor.className = 'tutor-reflexionando';
    contenedor.innerHTML = `
      <span>🏛️ El tutor socrático está reflexionando</span>
      <div class="puntos-pulsantes" aria-hidden="true">
        <span></span><span></span><span></span>
      </div>
    `;
    contMensajes.appendChild(contenedor);
    contMensajes.scrollTop = contMensajes.scrollHeight;
    return contenedor;
  }

  function agregarMensajeUI(remitente, texto) {
    if (!contMensajes) return;

    const ahora = new Date();
    const hora = ahora.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const esTutor = remitente === 'tutor';

    const div = document.createElement('div');
    div.className = `burbuja-mensaje burbuja-mensaje--${esTutor ? 'tutor' : 'estudiante'}`;

    const cuerpoHtml = esTutor ? formatearMarkdown(texto) : `<p>${ui.escapar(texto).replace(/\n/g, '<br>')}</p>`;

    div.innerHTML = `
      <span class="burbuja-mensaje__remitente">${esTutor ? '🏛️ Tutor Socrático' : 'Tú'}</span>
      <div class="burbuja-mensaje__cuerpo">${cuerpoHtml}</div>
      <span class="burbuja-mensaje__hora">${hora}</span>
    `;

    contMensajes.appendChild(div);
    contMensajes.scrollTop = contMensajes.scrollHeight;
  }
}

/**
 * Formateador de texto markdown seguro y claro para el diálogo pedagógico
 * @param {string} texto
 * @returns {string} HTML sanitizado
 */
function formatearMarkdown(texto) {
  if (!texto) return '';
  const escapado = ui.escapar(texto);

  // Resaltado de negrita y cursiva
  let conEstilos = escapado
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>');

  // Procesar párrafos y listas con viñetas
  const lineas = conEstilos.split('\n');
  const html = [];
  let listaActiva = false;

  for (const raw of lineas) {
    const linea = raw.trim();
    if (linea.startsWith('•') || linea.startsWith('-')) {
      if (!listaActiva) {
        html.push('<ul style="margin: 4px 0 8px 18px; padding-left: 0;">');
        listaActiva = true;
      }
      html.push(`<li>${linea.replace(/^[-•]\s*/, '')}</li>`);
    } else {
      if (listaActiva) {
        html.push('</ul>');
        listaActiva = false;
      }
      if (linea.length > 0) {
        html.push(`<p>${linea}</p>`);
      }
    }
  }

  if (listaActiva) {
    html.push('</ul>');
  }

  return html.join('') || `<p>${conEstilos}</p>`;
}

inicializar();

