/**
 * Módulo distributivo.js
 * Gestión de grupos, paralelos, docentes y estudiantes (solo rol admin).
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';

let distributivo = [];
let asignaturas = [];
let usuarios = [];

async function inicializar() {
  await montarPlantilla({ titulo: 'Distributivo', roles: ['admin'] });

  document.getElementById('btn-nuevo-grupo')?.addEventListener('click', () => {
    abrirModalGrupo();
  });

  await cargarDatos();
}

async function cargarDatos() {
  ui.cargando(true);
  try {
    const [listaDist, listaAsig, listaUsu] = await Promise.all([
      api.listar('distributivo'),
      api.listar('asignaturas'),
      api.listar('usuarios')
    ]);
    distributivo = listaDist || [];
    asignaturas = listaAsig || [];
    usuarios = listaUsu || [];
    renderizarTabla();
  } catch (err) {
    ui.aviso('Error al cargar datos del distributivo: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function renderizarTabla() {
  const tbody = document.getElementById('cuerpo-tabla-distributivo');
  if (!tbody) return;

  if (distributivo.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; color: var(--color-texto-secundario); padding: var(--espacio-xl);">
          No hay grupos registrados en el distributivo. Haz clic en "+ Nuevo grupo" para crear uno.
        </td>
      </tr>
    `;
    return;
  }

  const mapaAsignaturas = new Map(asignaturas.map(a => [a.id, a]));
  const mapaUsuarios = new Map(usuarios.map(u => [u.id, u]));

  tbody.innerHTML = distributivo.map(grupo => {
    const asig = mapaAsignaturas.get(grupo.asignaturaId);
    const nombreAsig = asig ? asig.nombre : grupo.asignaturaId;
    const docente = mapaUsuarios.get(grupo.docenteId);
    const nombreDocente = docente ? `${docente.nombre} ${docente.apellido}` : 'Docente no asignado';
    const numEstudiantes = Array.isArray(grupo.estudiantes) ? grupo.estudiantes.length : 0;

    return `
      <tr data-id="${ui.escapar(grupo.id)}">
        <td>
          <strong>${ui.escapar(nombreAsig)}</strong>
          ${asig?.nivel ? `<br><small style="color: var(--color-texto-secundario);">${ui.escapar(asig.nivel)}</small>` : ''}
        </td>
        <td><span class="insignia">${ui.escapar(grupo.paralelo || '-')}</span></td>
        <td>${ui.escapar(grupo.periodo || '-')}</td>
        <td>
          ${ui.escapar(nombreDocente)}
          ${docente?.correo ? `<br><small style="color: var(--color-texto-secundario);">${ui.escapar(docente.correo)}</small>` : ''}
        </td>
        <td>
          <span class="insignia insignia--exito">${numEstudiantes} estudiante${numEstudiantes === 1 ? '' : 's'}</span>
        </td>
        <td style="text-align: right;">
          <div style="display: inline-flex; gap: var(--espacio-xs);">
            <button type="button" class="btn btn--secundario btn--pequeno btn-editar-grupo" data-id="${ui.escapar(grupo.id)}">
              Editar
            </button>
            <button type="button" class="btn btn--peligro btn--pequeno btn-eliminar-grupo" data-id="${ui.escapar(grupo.id)}">
              Eliminar
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  // Vincular eventos
  tbody.querySelectorAll('.btn-editar-grupo').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const grupo = distributivo.find(g => g.id === id);
      if (grupo) abrirModalGrupo(grupo);
    });
  });

  tbody.querySelectorAll('.btn-eliminar-grupo').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const grupo = distributivo.find(g => g.id === id);
      if (grupo) eliminarGrupo(grupo);
    });
  });
}

async function abrirModalGrupo(grupo = null) {
  const esEdicion = Boolean(grupo);
  const tituloModal = esEdicion ? 'Editar grupo académico' : 'Nuevo grupo académico';

  if (asignaturas.length === 0) {
    ui.aviso('Primero debes crear al menos una asignatura.', 'error');
    return;
  }

  const docentes = usuarios.filter(u => u.rol === 'docente' && u.activo !== false);
  const estudiantes = usuarios.filter(u => u.rol === 'estudiante' && u.activo !== false);

  if (docentes.length === 0) {
    ui.aviso('No hay docentes activos registrados en el sistema.', 'error');
    return;
  }

  const idsSeleccionados = new Set(Array.isArray(grupo?.estudiantes) ? grupo.estudiantes : []);

  const form = document.createElement('form');
  form.className = 'formulario-distributivo';
  form.innerHTML = `
    <div class="campo-distributivo">
      <label for="dist-asig">Asignatura *</label>
      <select id="dist-asig" required>
        ${asignaturas.map(a => `
          <option value="${ui.escapar(a.id)}" ${grupo?.asignaturaId === a.id ? 'selected' : ''}>
            ${ui.escapar(a.nombre)} (${ui.escapar(a.nivel || 'General')})
          </option>
        `).join('')}
      </select>
    </div>

    <div class="fila-formulario fila-formulario--doble">
      <div class="campo-distributivo">
        <label for="dist-paralelo">Paralelo *</label>
        <input type="text" id="dist-paralelo" required value="${ui.escapar(grupo?.paralelo || 'A')}" placeholder="Ej. A" />
      </div>
      <div class="campo-distributivo">
        <label for="dist-periodo">Período lectivo *</label>
        <input type="text" id="dist-periodo" required value="${ui.escapar(grupo?.periodo || '2026-2027')}" placeholder="Ej. 2026-2027" />
      </div>
    </div>

    <div class="campo-distributivo">
      <label for="dist-docente">Docente responsable *</label>
      <select id="dist-docente" required>
        <option value="">Seleccione un docente...</option>
        ${docentes.map(d => `
          <option value="${ui.escapar(d.id)}" ${grupo?.docenteId === d.id ? 'selected' : ''}>
            ${ui.escapar(d.nombre)} ${ui.escapar(d.apellido)} (${ui.escapar(d.correo)})
          </option>
        `).join('')}
      </select>
    </div>

    <div class="seccion-estudiantes">
      <div class="seccion-estudiantes__cabecera">
        <label for="dist-buscar-estudiantes"><strong>Estudiantes del grupo</strong></label>
        <span id="dist-contador-estudiantes" class="contador-estudiantes">
          Seleccionados: ${idsSeleccionados.size}
        </span>
      </div>
      <input type="search" id="dist-buscar-estudiantes" class="buscador-estudiantes" placeholder="Filtrar estudiante por nombre o correo..." />
      <div id="contenedor-casillas-estudiantes" class="lista-estudiantes-casillas" tabindex="0" role="group" aria-label="Lista de estudiantes disponibles">
        ${estudiantes.map(est => {
          const marcado = idsSeleccionados.has(est.id);
          return `
            <label class="item-estudiante" data-texto="${ui.escapar(`${est.nombre} ${est.apellido} ${est.correo}`.toLowerCase())}">
              <input type="checkbox" value="${ui.escapar(est.id)}" class="chk-estudiante" ${marcado ? 'checked' : ''} />
              <span>
                <strong>${ui.escapar(est.nombre)} ${ui.escapar(est.apellido)}</strong>
                <span class="item-estudiante__correo">(${ui.escapar(est.correo)})</span>
              </span>
            </label>
          `;
        }).join('')}
      </div>
    </div>
  `;

  // Prevenir submit
  form.addEventListener('submit', e => e.preventDefault());

  // Contador y buscador interactivo
  const spanContador = form.querySelector('#dist-contador-estudiantes');
  const actualizaContador = () => {
    const checks = form.querySelectorAll('.chk-estudiante:checked');
    if (spanContador) {
      spanContador.textContent = `Seleccionados: ${checks.length}`;
    }
  };

  form.querySelectorAll('.chk-estudiante').forEach(chk => {
    chk.addEventListener('change', actualizaContador);
  });

  const inputBuscar = form.querySelector('#dist-buscar-estudiantes');
  inputBuscar?.addEventListener('input', () => {
    const q = inputBuscar.value.trim().toLowerCase();
    const items = form.querySelectorAll('.item-estudiante');
    items.forEach(item => {
      const texto = item.getAttribute('data-texto') || '';
      item.style.display = texto.includes(q) ? 'flex' : 'none';
    });
  });

  const accion = await ui.modal({
    titulo: tituloModal,
    contenido: form,
    acciones: [
      { texto: 'Cancelar', valor: null, clase: 'btn--secundario' },
      { texto: esEdicion ? 'Guardar cambios' : 'Crear grupo', valor: 'guardar', clase: 'btn--primario' }
    ]
  });

  if (accion !== 'guardar') return;

  const asignaturaId = form.querySelector('#dist-asig')?.value;
  const paralelo = form.querySelector('#dist-paralelo')?.value.trim();
  const periodo = form.querySelector('#dist-periodo')?.value.trim();
  const docenteId = form.querySelector('#dist-docente')?.value;

  if (!asignaturaId || !paralelo || !periodo || !docenteId) {
    ui.aviso('Todos los campos marcados con (*) son obligatorios.', 'error');
    return;
  }

  const estudiantesSeleccionados = Array.from(form.querySelectorAll('.chk-estudiante:checked')).map(c => c.value);

  const payload = {
    asignaturaId,
    paralelo,
    periodo,
    docenteId,
    estudiantes: estudiantesSeleccionados
  };

  ui.cargando(true);
  try {
    if (esEdicion) {
      await api.actualizar('distributivo', grupo.id, payload);
      ui.aviso('Grupo actualizado exitosamente.', 'exito');
    } else {
      await api.crear('distributivo', payload);
      ui.aviso('Grupo creado exitosamente.', 'exito');
    }
    await cargarDatos();
  } catch (err) {
    ui.aviso('Error al guardar grupo: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function eliminarGrupo(grupo) {
  const mapaAsig = new Map(asignaturas.map(a => [a.id, a.nombre]));
  const nombreAsig = mapaAsig.get(grupo.asignaturaId) || grupo.asignaturaId;

  const confirmado = await ui.confirmar(`¿Estás seguro de eliminar el paralelo "${grupo.paralelo}" de "${nombreAsig}" (${grupo.periodo})?`);
  if (!confirmado) return;

  ui.cargando(true);
  try {
    await api.eliminar('distributivo', grupo.id);
    ui.aviso('Grupo eliminado del distributivo.', 'exito');
    await cargarDatos();
  } catch (err) {
    ui.aviso('Error al eliminar grupo: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

inicializar();
