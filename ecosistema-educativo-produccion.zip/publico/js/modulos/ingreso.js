/**
 * Módulo ingreso.js - Controlador de la página de inicio de sesión
 * Validación en vivo con .campo__error, botón deshabilitado al enviar y redirección a /index.html.
 */

import { montarPlantilla } from '/js/nucleo/plantilla.js';
import { iniciar, usuarioActual } from '/js/nucleo/sesion.js';
import { aviso, escapar } from '/js/nucleo/ui.js';

await montarPlantilla({ titulo: 'Iniciar Sesión', roles: ['publico'] });

const usuarioSesion = usuarioActual();

const contenido = document.getElementById('contenido');
if (contenido) {
  const alertaUsuarioActivo = usuarioSesion ? `
    <div class="alerta alerta--info" style="margin-bottom: var(--espacio-m);">
      Ya has iniciado sesión como <strong>${escapar(usuarioSesion.nombre)}</strong> (${escapar(usuarioSesion.correo)}).
      Puedes ingresar con otra cuenta o <a href="/index.html" class="btn btn--texto" style="padding: 0;">volver al inicio →</a>
    </div>
  ` : '';

  contenido.innerHTML = `
    <div class="auth-contenedor">
      ${alertaUsuarioActivo}
      <article class="auth-tarjeta">
        <header class="auth-cabecera">
          <span class="insignia insignia--primario" style="align-self: center;">Acceso al sistema</span>
          <h1>Iniciar Sesión</h1>
          <p style="color: var(--color-texto-claro); font-size: var(--tamano-s);">
            Ingresa tus credenciales para acceder a la plataforma
          </p>
        </header>

        <form id="formulario-ingreso" class="auth-formulario" novalidate>
          <div class="campo" id="contenedor-correo">
            <label for="correo">Correo electrónico</label>
            <input
              type="email"
              id="correo"
              name="correo"
              autocomplete="email"
              placeholder="nombre@ejemplo.com"
              required
              aria-describedby="error-correo"
            >
            <span class="campo__error" id="error-correo" aria-live="polite"></span>
          </div>

          <div class="campo" id="contenedor-clave">
            <label for="clave">Contraseña</label>
            <input
              type="password"
              id="clave"
              name="clave"
              autocomplete="current-password"
              placeholder="Tu contraseña"
              required
              aria-describedby="error-clave"
            >
            <span class="campo__error" id="error-clave" aria-live="polite"></span>
          </div>

          <button type="submit" id="btn-ingreso" class="btn btn--primario" style="margin-top: var(--espacio-s);">
            Iniciar sesión
          </button>
        </form>

        <div style="margin-top: var(--espacio-m); padding: var(--espacio-s); background-color: var(--color-fondo-suave); border: 1px dashed var(--color-borde); border-radius: var(--radio-s); font-size: var(--tamano-xs);">
          <div style="font-weight: var(--peso-seminegrita); color: var(--color-primario); margin-bottom: var(--espacio-xs);">
            Cuentas demo (contraseña: <code>Demo12345</code> con "D" mayúscula):
          </div>
          <div style="display: flex; gap: var(--espacio-xs); flex-wrap: wrap;">
            <button type="button" class="btn btn--secundario btn--pequeno" id="btn-demo-estudiante" title="Completar datos de Estudiante 1">
              🎓 Estudiante
            </button>
            <button type="button" class="btn btn--secundario btn--pequeno" id="btn-demo-docente" title="Completar datos de Docente 1">
              👨‍🏫 Docente
            </button>
            <button type="button" class="btn btn--secundario btn--pequeno" id="btn-demo-admin" title="Completar datos de Administrador">
              ⚙️ Admin
            </button>
          </div>
        </div>

        <footer class="auth-pie">
          <p>
            ¿No tienes una cuenta aún?
            <a href="/paginas/registro.html" class="btn btn--texto" style="font-weight: var(--peso-seminegrita);">
              Regístrate aquí →
            </a>
          </p>
        </footer>
      </article>
    </div>
  `;

  document.getElementById('btn-demo-estudiante')?.addEventListener('click', () => {
    document.getElementById('correo').value = 'estudiante1@demo.ec';
    document.getElementById('clave').value = 'Demo12345';
  });
  document.getElementById('btn-demo-docente')?.addEventListener('click', () => {
    document.getElementById('correo').value = 'docente1@demo.ec';
    document.getElementById('clave').value = 'Demo12345';
  });
  document.getElementById('btn-demo-admin')?.addEventListener('click', () => {
    document.getElementById('correo').value = 'admin@demo.ec';
    document.getElementById('clave').value = 'Demo12345';
  });


  const form = document.getElementById('formulario-ingreso');
  const btnSubmit = document.getElementById('btn-ingreso');
  const inputCorreo = document.getElementById('correo');
  const inputClave = document.getElementById('clave');
  const contCorreo = document.getElementById('contenedor-correo');
  const contClave = document.getElementById('contenedor-clave');
  const errorCorreo = document.getElementById('error-correo');
  const errorClave = document.getElementById('error-clave');

  const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function validarCorreo() {
    const val = inputCorreo.value.trim();
    if (!val) {
      contCorreo.classList.add('campo--error');
      errorCorreo.textContent = 'El correo electrónico es obligatorio';
      inputCorreo.setAttribute('aria-invalid', 'true');
      return false;
    }
    if (!regexCorreo.test(val)) {
      contCorreo.classList.add('campo--error');
      errorCorreo.textContent = 'Ingresa un formato de correo válido (ej: usuario@dominio.com)';
      inputCorreo.setAttribute('aria-invalid', 'true');
      return false;
    }
    contCorreo.classList.remove('campo--error');
    errorCorreo.textContent = '';
    inputCorreo.setAttribute('aria-invalid', 'false');
    return true;
  }

  function validarClave() {
    const val = inputClave.value;
    if (!val) {
      contClave.classList.add('campo--error');
      errorClave.textContent = 'La contraseña es obligatoria';
      inputClave.setAttribute('aria-invalid', 'true');
      return false;
    }
    contClave.classList.remove('campo--error');
    errorClave.textContent = '';
    inputClave.setAttribute('aria-invalid', 'false');
    return true;
  }

  // Validación en vivo
  inputCorreo.addEventListener('input', validarCorreo);
  inputCorreo.addEventListener('blur', validarCorreo);
  inputClave.addEventListener('input', validarClave);
  inputClave.addEventListener('blur', validarClave);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const okCorreo = validarCorreo();
    const okClave = validarClave();

    if (!okCorreo || !okClave) {
      if (!okCorreo) inputCorreo.focus();
      else inputClave.focus();
      return;
    }

    // Botón deshabilitado mientras envía
    btnSubmit.disabled = true;
    const textoOriginal = btnSubmit.textContent;
    btnSubmit.textContent = 'Iniciando sesión...';

    try {
      await iniciar(inputCorreo.value.trim(), inputClave.value);
      aviso('Bienvenido. Sesión iniciada con éxito.', 'exito');
      // Tras ingresar → /index.html
      setTimeout(() => {
        window.location.href = '/index.html';
      }, 300);
    } catch (err) {
      aviso(err.message || 'Error al iniciar sesión', 'error');
      btnSubmit.disabled = false;
      btnSubmit.textContent = textoOriginal;
    }
  });
}
