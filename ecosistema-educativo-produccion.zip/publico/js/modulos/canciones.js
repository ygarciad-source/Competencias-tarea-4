/**
 * Módulo canciones.js
 * Reproductor de canciones educativas con sincronización de letra LRC.
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';
import { usuarioActual } from '../nucleo/sesion.js';

let canciones = [];
let asignaturas = [];
let unidades = [];
let temas = [];

let cancionActiva = null;
let lineasLrc = [];
let indiceLrcActivo = -1;

const audio = document.getElementById('audio-nativo') || new Audio();

function formatearTiempo(segundosTotales) {
  if (isNaN(segundosTotales) || segundosTotales < 0) return '00:00';
  const min = Math.floor(segundosTotales / 60);
  const seg = Math.floor(segundosTotales % 60);
  return `${String(min).padStart(2, '0')}:${String(seg).padStart(2, '0')}`;
}

async function inicializar() {
  await montarPlantilla({ titulo: 'Canciones Educativas', roles: ['sesion'] });

  const usuario = usuarioActual();
  const puedeEditar = usuario && (usuario.rol === 'docente' || usuario.rol === 'admin');
  const btnCrear = document.getElementById('contenedor-accion-crear');
  if (btnCrear && puedeEditar) {
    btnCrear.style.display = 'block';
  }

  configurarReproductor();
  configurarFiltros();

  await cargarDatos();
}

async function cargarDatos() {
  ui.cargando(true);
  try {
    const [listaCanciones, listaAsignaturas, listaUnidades, listaTemas] = await Promise.all([
      api.listar('canciones'),
      api.listar('asignaturas'),
      api.listar('unidades'),
      api.listar('temas')
    ]);

    canciones = listaCanciones || [];
    asignaturas = listaAsignaturas || [];
    unidades = listaUnidades || [];
    temas = listaTemas || [];

    poblarFiltros();

    // Comprobar parámetro ?temaId=
    const temaIdParam = util.parametro('temaId');
    if (temaIdParam) {
      const temaObj = temas.find(t => t.id === temaIdParam);
      if (temaObj) {
        const unidadObj = unidades.find(u => u.id === temaObj.unidadId);
        if (unidadObj) {
          const selAsig = document.getElementById('filtro-asignatura');
          if (selAsig) selAsig.value = unidadObj.asignaturaId;
          actualizarSelectorTemas(unidadObj.asignaturaId);
        }
        const selTema = document.getElementById('filtro-tema');
        if (selTema) selTema.value = temaIdParam;
      }
    }

    renderizarListaCanciones();

    // Si hay canciones en la lista, seleccionar la primera automáticamente
    const filtradas = obtenerCancionesFiltradas();
    if (filtradas.length > 0) {
      cargarCancionEnReproductor(filtradas[0], false);
    }
  } catch (err) {
    ui.aviso('Error al cargar canciones: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function poblarFiltros() {
  const selAsig = document.getElementById('filtro-asignatura');
  if (selAsig) {
    selAsig.innerHTML = '<option value="">Todas las asignaturas</option>' +
      asignaturas.map(a => `<option value="${ui.escapar(a.id)}">${ui.escapar(a.nombre)}</option>`).join('');
  }
  actualizarSelectorTemas('');
}

function actualizarSelectorTemas(asignaturaId) {
  const selTema = document.getElementById('filtro-tema');
  if (!selTema) return;

  let temasFiltrados = temas;
  if (asignaturaId) {
    const idsUnidades = new Set(unidades.filter(u => u.asignaturaId === asignaturaId).map(u => u.id));
    temasFiltrados = temas.filter(t => idsUnidades.has(t.unidadId));
  }

  selTema.innerHTML = '<option value="">Todos los temas</option>' +
    temasFiltrados.map(t => `<option value="${ui.escapar(t.id)}">${ui.escapar(t.titulo)}</option>`).join('');
}

function configurarFiltros() {
  const selAsig = document.getElementById('filtro-asignatura');
  const selTema = document.getElementById('filtro-tema');

  selAsig?.addEventListener('change', () => {
    actualizarSelectorTemas(selAsig.value);
    renderizarListaCanciones();
  });

  selTema?.addEventListener('change', () => {
    renderizarListaCanciones();
  });
}

function obtenerCancionesFiltradas() {
  const asigId = document.getElementById('filtro-asignatura')?.value;
  const temaId = document.getElementById('filtro-tema')?.value;

  // Mapa de temaId -> asignaturaId
  const mapaUnidadAsig = new Map(unidades.map(u => [u.id, u.asignaturaId]));
  const mapaTemaAsig = new Map(temas.map(t => [t.id, mapaUnidadAsig.get(t.unidadId)]));

  return canciones.filter(c => {
    if (temaId && c.temaId !== temaId) return false;
    if (asigId && mapaTemaAsig.get(c.temaId) !== asigId) return false;
    return true;
  });
}

function renderizarListaCanciones() {
  const listaEl = document.getElementById('lista-canciones');
  const conteoEl = document.getElementById('conteo-canciones');
  if (!listaEl) return;

  const filtradas = obtenerCancionesFiltradas();
  if (conteoEl) {
    conteoEl.textContent = `${filtradas.length} canción${filtradas.length === 1 ? '' : 'es'}`;
  }

  if (filtradas.length === 0) {
    listaEl.innerHTML = `
      <li style="padding: var(--espacio-l); text-align: center; color: var(--color-texto-secundario); font-size: var(--tamano-s);">
        No hay canciones disponibles para los filtros seleccionados.
      </li>
    `;
    return;
  }

  const mapaTemas = new Map(temas.map(t => [t.id, t.titulo]));
  const usuario = usuarioActual();
  const puedeEditar = usuario && (usuario.rol === 'docente' || usuario.rol === 'admin');

  listaEl.innerHTML = filtradas.map(c => {
    const esActiva = cancionActiva && cancionActiva.id === c.id;
    const nombreTema = mapaTemas.get(c.temaId) || 'Tema';

    return `
      <li class="item-cancion ${esActiva ? 'item-cancion--activa' : ''}" data-id="${ui.escapar(c.id)}" role="option" aria-selected="${esActiva}">
        <div class="item-cancion__info">
          <h3 class="item-cancion__titulo">${ui.escapar(c.titulo)}</h3>
          <span class="item-cancion__subtitulo">${ui.escapar(nombreTema)} · ${ui.escapar(c.autoria || 'Anónimo')}</span>
        </div>
        <div style="display: flex; align-items: center; gap: var(--espacio-xs);">
          ${puedeEditar ? `
            <a href="/paginas/editor-cancion.html?id=${encodeURIComponent(c.id)}" class="btn btn--secundario btn--pequeno btn-editar-cancion" style="text-decoration: none;">
              Editar
            </a>
          ` : ''}
          <button type="button" class="btn btn--primario btn--pequeno btn-reproducir-item" data-id="${ui.escapar(c.id)}" aria-label="Reproducir ${ui.escapar(c.titulo)}">
            ${esActiva && !audio.paused ? '⏸' : '▶'}
          </button>
        </div>
      </li>
    `;
  }).join('');

  listaEl.querySelectorAll('.item-cancion').forEach(li => {
    li.addEventListener('click', e => {
      if (e.target.closest('a')) return;
      const id = li.getAttribute('data-id');
      const c = canciones.find(item => item.id === id);
      if (c) {
        const esMisma = cancionActiva && cancionActiva.id === c.id;
        if (esMisma) {
          togglePlayPausa();
        } else {
          cargarCancionEnReproductor(c, true);
        }
      }
    });
  });
}

function parsearLRC(lrcTexto) {
  if (!lrcTexto) return [];
  const lineas = lrcTexto.split('\n');
  const resultado = [];
  const regexLrc = /\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?\](.*)/;

  for (const l of lineas) {
    const coincidencia = l.match(regexLrc);
    if (coincidencia) {
      const min = parseInt(coincidencia[1], 10);
      const seg = parseInt(coincidencia[2], 10);
      const frac = coincidencia[3] ? parseFloat('0.' + coincidencia[3]) : 0;
      const tiempo = min * 60 + seg + frac;
      const texto = coincidencia[4].trim();
      if (texto) {
        resultado.push({ tiempo, texto });
      }
    }
  }

  resultado.sort((a, b) => a.tiempo - b.tiempo);
  return resultado;
}

function cargarCancionEnReproductor(c, autoReproducir = false) {
  cancionActiva = c;
  indiceLrcActivo = -1;

  // Metadatos
  const temaObj = temas.find(t => t.id === c.temaId);
  document.getElementById('cancion-tema-badge').textContent = temaObj ? temaObj.titulo : 'Tema';
  document.getElementById('cancion-licencia-badge').textContent = c.licencia || 'Licencia institucional';
  document.getElementById('titulo-reproductor').textContent = c.titulo;
  document.getElementById('cancion-autoria-texto').textContent = `Autoría: ${c.autoria || 'No especificada'}`;

  // Audio source
  const nativo = document.getElementById('audio-nativo');
  if (nativo) nativo.src = c.audio;
  audio.src = c.audio;

  document.getElementById('btn-reproducir-pausa').disabled = false;

  // Letra
  lineasLrc = parsearLRC(c.lrc);
  renderizarLetra(c);

  renderizarListaCanciones();

  if (autoReproducir) {
    audio.play().catch(err => {
      console.warn('Reproducción automática bloqueada por el navegador:', err);
    });
  }
}

function renderizarLetra(c) {
  const cuerpoLetra = document.getElementById('cuerpo-letra');
  const indicadorTipo = document.getElementById('tipo-letra-indicador');
  if (!cuerpoLetra) return;

  if (lineasLrc.length > 0) {
    if (indicadorTipo) {
      indicadorTipo.textContent = 'Sincronizada (LRC)';
      indicadorTipo.style.display = 'inline-block';
    }

    cuerpoLetra.innerHTML = lineasLrc.map((item, idx) => `
      <div class="linea-lrc" data-idx="${idx}" data-tiempo="${item.tiempo}">
        ${ui.escapar(item.texto)}
      </div>
    `).join('');

    // Clic en línea salta a ese segundo
    cuerpoLetra.querySelectorAll('.linea-lrc').forEach(div => {
      div.addEventListener('click', () => {
        const seg = parseFloat(div.getAttribute('data-tiempo'));
        if (!isNaN(seg)) {
          audio.currentTime = seg;
          if (audio.paused) audio.play();
        }
      });
    });
  } else if (c.letra) {
    if (indicadorTipo) {
      indicadorTipo.textContent = 'Texto plano';
      indicadorTipo.style.display = 'inline-block';
    }
    cuerpoLetra.innerHTML = `<div class="letra-estatica">${ui.escapar(c.letra)}</div>`;
  } else {
    if (indicadorTipo) indicadorTipo.style.display = 'none';
    cuerpoLetra.innerHTML = `<p class="mensaje-sin-letra">Letra no disponible para esta canción.</p>`;
  }
}

function configurarReproductor() {
  const btnPlay = document.getElementById('btn-reproducir-pausa');
  const barraProgreso = document.getElementById('barra-progreso');
  const indicadorProgreso = document.getElementById('indicador-barra-progreso');
  const txtTiempoActual = document.getElementById('tiempo-actual');
  const txtTiempoDuracion = document.getElementById('tiempo-duracion');
  const ctrlVolumen = document.getElementById('control-volumen');

  btnPlay?.addEventListener('click', togglePlayPausa);

  audio.addEventListener('play', () => {
    btnPlay.textContent = '⏸';
    btnPlay.setAttribute('aria-label', 'Pausar');
    renderizarListaCanciones();
  });

  audio.addEventListener('pause', () => {
    btnPlay.textContent = '▶';
    btnPlay.setAttribute('aria-label', 'Reproducir');
    renderizarListaCanciones();
  });

  audio.addEventListener('loadedmetadata', () => {
    if (txtTiempoDuracion) {
      txtTiempoDuracion.textContent = formatearTiempo(audio.duration);
    }
  });

  audio.addEventListener('timeupdate', () => {
    const actual = audio.currentTime;
    const duracion = audio.duration || 0;

    if (txtTiempoActual) txtTiempoActual.textContent = formatearTiempo(actual);

    if (duracion > 0 && barraProgreso && indicadorProgreso) {
      const porcentaje = (actual / duracion) * 100;
      indicadorProgreso.style.width = `${porcentaje}%`;
      barraProgreso.setAttribute('aria-valuenow', String(Math.round(porcentaje)));
      barraProgreso.setAttribute('aria-valuetext', `${formatearTiempo(actual)} de ${formatearTiempo(duracion)}`);
    }

    // Sincronizar LRC
    if (lineasLrc.length > 0) {
      actualizarLineaLrc(actual);
    }
  });

  audio.addEventListener('ended', () => {
    btnPlay.textContent = '▶';
    indicadorProgreso.style.width = '0%';
    barraProgreso.setAttribute('aria-valuenow', '0');
    renderizarListaCanciones();
  });

  // Operar barra con mouse
  barraProgreso?.addEventListener('click', e => {
    const rect = barraProgreso.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    const duracion = audio.duration || 0;
    if (duracion > 0) {
      audio.currentTime = Math.max(0, Math.min(duracion, pos * duracion));
    }
  });

  // Operar barra con teclado (Accesibilidad)
  barraProgreso?.addEventListener('keydown', e => {
    const duracion = audio.duration || 0;
    if (duracion === 0) return;

    if (e.key === 'ArrowRight') {
      e.preventDefault();
      audio.currentTime = Math.min(duracion, audio.currentTime + 5);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      audio.currentTime = Math.max(0, audio.currentTime - 5);
    } else if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      togglePlayPausa();
    } else if (e.key === 'Home') {
      e.preventDefault();
      audio.currentTime = 0;
    } else if (e.key === 'End') {
      e.preventDefault();
      audio.currentTime = duracion;
    }
  });

  // Control de volumen
  ctrlVolumen?.addEventListener('input', e => {
    audio.volume = parseFloat(e.target.value);
  });
}

function togglePlayPausa() {
  if (!cancionActiva) return;
  if (audio.paused) {
    audio.play();
  } else {
    audio.pause();
  }
}

function actualizarLineaLrc(tiempoActual) {
  // Encontrar la línea correspondiente al segundo actual
  let nuevoIndice = -1;
  for (let i = 0; i < lineasLrc.length; i++) {
    if (lineasLrc[i].tiempo <= tiempoActual) {
      nuevoIndice = i;
    } else {
      break;
    }
  }

  if (nuevoIndice !== indiceLrcActivo && nuevoIndice !== -1) {
    indiceLrcActivo = nuevoIndice;

    const cuerpoLetra = document.getElementById('cuerpo-letra');
    if (!cuerpoLetra) return;

    const lineasDOM = cuerpoLetra.querySelectorAll('.linea-lrc');
    lineasDOM.forEach(l => l.classList.remove('linea-lrc--activa'));

    const activaDOM = lineasDOM[nuevoIndice];
    if (activaDOM) {
      activaDOM.classList.add('linea-lrc--activa');
      activaDOM.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }
}

inicializar();
