/**
 * Módulo asignaturas.js
 * Vista de "Mis asignaturas" para estudiantes y docentes con barra de avance.
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';

let asignaturas = [];

/**
 * Calcula el avance porcentual y temas revisados de una asignatura para el usuario actual.
 * Considera solo unidades visibles y temas en estado "publicado".
 * @param {string} asignaturaId
 * @returns {Promise<{ porcentaje: number, revisados: number, total: number, temasPublicados: Array, revisadosIds: Set }>}
 */
export async function calcularAvance(asignaturaId) {
  try {
    const [unidades, todosTemas, progreso] = await Promise.all([
      api.listar('unidades', { asignaturaId }),
      api.listar('temas'),
      api.listar('progreso-temas')
    ]);

    const unidadesVisibles = (unidades || []).filter(u => u.visible !== false);
    const idsUnidades = new Set(unidadesVisibles.map(u => u.id));

    const temasPublicados = (todosTemas || []).filter(t =>
      idsUnidades.has(t.unidadId) && t.estado === 'publicado'
    );

    const revisadosIds = new Set((progreso || []).map(p => p.temaId));
    const total = temasPublicados.length;
    const revisados = temasPublicados.filter(t => revisadosIds.has(t.id)).length;
    const porcentaje = total > 0 ? Math.round((revisados / total) * 100) : 0;

    return {
      porcentaje,
      revisados,
      total,
      temasPublicados,
      revisadosIds
    };
  } catch (err) {
    console.error('Error calculando avance:', err);
    return {
      porcentaje: 0,
      revisados: 0,
      total: 0,
      temasPublicados: [],
      revisadosIds: new Set()
    };
  }
}

async function inicializar() {
  await montarPlantilla({ titulo: 'Mis Asignaturas', roles: ['estudiante', 'docente'] });

  verificarUltimoTema();
  await cargarAsignaturas();
}

function verificarUltimoTema() {
  try {
    const raw = localStorage.getItem('ultimoTema');
    if (!raw) return;
    const ultimo = JSON.parse(raw);
    if (ultimo && ultimo.id && ultimo.titulo) {
      const banner = document.getElementById('banner-ultimo-tema');
      const tituloEl = document.getElementById('banner-titulo-tema');
      const enlaceEl = document.getElementById('banner-enlace-tema');
      if (banner && tituloEl && enlaceEl) {
        tituloEl.textContent = ultimo.titulo;
        enlaceEl.href = `/paginas/tema.html?id=${encodeURIComponent(ultimo.id)}`;
        banner.style.display = 'flex';
      }
    }
  } catch {
    // Si localStorage está corrupto o deshabilitado, continuar sin error
  }
}

async function cargarAsignaturas() {
  ui.cargando(true);
  try {
    const lista = await api.listar('asignaturas');
    asignaturas = lista || [];
    await renderizarAsignaturas();
  } catch (err) {
    ui.aviso('Error al cargar asignaturas: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function renderizarAsignaturas() {
  const contenedor = document.getElementById('contenedor-asignaturas');
  if (!contenedor) return;

  if (asignaturas.length === 0) {
    contenedor.innerHTML = `
      <div class="tarjeta" style="grid-column: 1 / -1; text-align: center; padding: var(--espacio-xxl);">
        <p style="color: var(--color-texto-secundario); margin: 0;">
          No tienes asignaturas inscritas o asignadas en este período lectivo.
        </p>
      </div>
    `;
    return;
  }

  // Calcular avance de cada asignatura en paralelo
  const avances = await Promise.all(asignaturas.map(a => calcularAvance(a.id)));

  contenedor.innerHTML = asignaturas.map((asig, idx) => {
    const avance = avances[idx];
    const { porcentaje, revisados, total } = avance;

    return `
      <article class="tarjeta tarjeta-mi-asignatura" data-id="${ui.escapar(asig.id)}">
        <header class="tarjeta__cabecera">
          <span class="tarjeta-mi-asignatura__nivel">${ui.escapar(asig.nivel || 'General')}</span>
        </header>

        <div class="tarjeta__cuerpo">
          <h2 class="tarjeta-mi-asignatura__titulo">${ui.escapar(asig.nombre)}</h2>
          <p class="tarjeta-mi-asignatura__desc">${ui.escapar(asig.descripcion || 'Sin descripción disponible.')}</p>

          <div class="seccion-avance-asignatura">
            <div class="seccion-avance-asignatura__meta">
              <span>Avance de contenidos</span>
              <span class="porcentaje-avance">${porcentaje}% (${revisados}/${total})</span>
            </div>
            <div class="progreso progreso--primario" role="progressbar" aria-valuenow="${porcentaje}" aria-valuemin="0" aria-valuemax="100" aria-label="Avance de ${ui.escapar(asig.nombre)}">
              <span class="progreso__barra" style="width: ${porcentaje}%;"></span>
            </div>
          </div>
        </div>

        <footer class="tarjeta-mi-asignatura__pie">
          <a href="/paginas/asignatura.html?id=${encodeURIComponent(asig.id)}" class="btn btn--primario btn--pequeno" style="text-decoration: none;">
            Ver unidades y temas →
          </a>
        </footer>
      </article>
    `;
  }).join('');
}

if (typeof document !== 'undefined' && document.getElementById('contenedor-asignaturas')) {
  inicializar();
}

