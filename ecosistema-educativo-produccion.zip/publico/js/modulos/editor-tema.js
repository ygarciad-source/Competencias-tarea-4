/**
 * Módulo editor-tema.js
 * Edición de ficha pedagógica y glosario del tema (roles docente y admin).
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';

let temaActual = null;
let unidadActual = null;
let glosarioTema = [];
let preguntasTema = [];

// Listas en memoria
let objetivos = [];
let ejemplos = [];
let erroresFrecuentes = [];
let preguntasGuia = [];
let recursos = [];

let hayCambiosSinGuardar = false;

function marcarCambio() {
  hayCambiosSinGuardar = true;
}

function contarPalabras(texto) {
  if (!texto) return 0;
  return texto.trim().split(/\s+/).filter(Boolean).length;
}

async function inicializar() {
  await montarPlantilla({ titulo: 'Ficha del Tema', roles: ['docente', 'admin'] });

  const temaId = util.parametro('id');
  if (!temaId) {
    ui.aviso('No se especificó ningún tema para editar.', 'error');
    setTimeout(() => {
      window.location.href = '/paginas/editor-contenidos.html';
    }, 1500);
    return;
  }

  // Protección ante salida con cambios sin guardar
  window.addEventListener('beforeunload', e => {
    if (hayCambiosSinGuardar) {
      e.preventDefault();
      e.returnValue = '';
    }
  });

  document.getElementById('enlace-volver')?.addEventListener('click', async e => {
    if (hayCambiosSinGuardar) {
      e.preventDefault();
      const salir = await ui.confirmar('Tienes cambios sin guardar en la ficha. ¿Estás seguro de salir sin guardar?');
      if (salir) {
        hayCambiosSinGuardar = false;
        window.location.href = '/paginas/editor-contenidos.html';
      }
    }
  });

  vincularEventosFormulario();
  await cargarDatos(temaId);
}

async function cargarDatos(temaId) {
  ui.cargando(true);
  try {
    const [tema, listaGlosario, listaPreguntas] = await Promise.all([
      api.obtener('temas', temaId),
      api.listar('glosario', { temaId }),
      api.listar('preguntas', { temaId }).catch(() => [])
    ]);

    temaActual = tema;
    glosarioTema = listaGlosario || [];
    preguntasTema = listaPreguntas || [];

    if (tema.unidadId) {
      try {
        unidadActual = await api.obtener('unidades', tema.unidadId);
      } catch {
        unidadActual = null;
      }
    }

    rellenarFicha(tema);
    actualizarGlosarioVista();
    actualizarPreguntasVista();
    hayCambiosSinGuardar = false;
  } catch (err) {
    ui.aviso('Error al cargar la información del tema: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function rellenarFicha(t) {
  const metaUnidad = document.getElementById('tema-meta-unidad');
  if (metaUnidad) {
    metaUnidad.textContent = unidadActual ? `${unidadActual.titulo} (Tema ${t.orden || 1})` : `Tema ${t.orden || 1}`;
  }

  const tituloCabecera = document.getElementById('tema-titulo-cabecera');
  if (tituloCabecera) tituloCabecera.textContent = t.titulo || 'Sin título';

  const indicadorEstado = document.getElementById('tema-indicador-estado');
  if (indicadorEstado) {
    const esPublicado = t.estado === 'publicado';
    indicadorEstado.innerHTML = `
      <span class="insignia ${esPublicado ? 'insignia--exito' : 'insignia--advertencia'}">
        ${esPublicado ? 'Publicado' : 'Borrador'}
      </span>
    `;
  }

  // Inputs principales
  document.getElementById('tema-titulo').value = t.titulo || '';
  document.getElementById('tema-estado').value = t.estado || 'borrador';
  document.getElementById('tema-dificultad').value = t.dificultad || 'media';
  document.getElementById('tema-palabras-clave').value = Array.isArray(t.palabrasClave) ? t.palabrasClave.join(', ') : (t.palabrasClave || '');
  document.getElementById('tema-fuentes').value = t.fuentes || '';
  document.getElementById('tema-resumen').value = t.resumen || '';

  actualizarContadorResumen();

  // Listas
  objetivos = Array.isArray(t.objetivos) ? [...t.objetivos] : [];
  ejemplos = Array.isArray(t.ejemplos) ? [...t.ejemplos] : [];
  erroresFrecuentes = Array.isArray(t.erroresFrecuentes) ? [...t.erroresFrecuentes] : [];
  preguntasGuia = Array.isArray(t.preguntasGuia) ? [...t.preguntasGuia] : [];
  recursos = Array.isArray(t.recursos) ? [...t.recursos] : [];

  renderizarListaSimple('lista-objetivos', 'contador-objetivos', objetivos, 'objetivo');
  renderizarListaSimple('lista-ejemplos', 'contador-ejemplos', ejemplos, 'ejemplo');
  renderizarListaSimple('lista-errores', 'contador-errores', erroresFrecuentes, 'error');
  renderizarListaSimple('lista-preguntas', 'contador-preguntas', preguntasGuia, 'pregunta');
  renderizarRecursos();
}

function actualizarContadorResumen() {
  const resumen = document.getElementById('tema-resumen')?.value || '';
  const palabras = contarPalabras(resumen);
  const contadorEl = document.getElementById('contador-palabras-resumen');

  if (contadorEl) {
    contadorEl.textContent = `${palabras} palabra${palabras === 1 ? '' : 's'} (Recomendado: 300 a 800 palabras)`;
    contadorEl.classList.remove('contador-palabras--valido', 'contador-palabras--alerta');
    if (palabras >= 300 && palabras <= 800) {
      contadorEl.classList.add('contador-palabras--valido');
    } else if (palabras > 0) {
      contadorEl.classList.add('contador-palabras--alerta');
    }
  }

  // Actualizar vista previa si está abierta
  const preview = document.getElementById('resumen-preview');
  if (preview && preview.style.display !== 'none') {
    preview.innerHTML = util.formatoBasico(resumen);
  }
}

function renderizarListaSimple(idLista, idContador, arreglo, tipoItem) {
  const ul = document.getElementById(idLista);
  const contador = document.getElementById(idContador);
  if (!ul) return;

  if (contador) contador.textContent = String(arreglo.length);

  if (arreglo.length === 0) {
    ul.innerHTML = `<li style="font-size: var(--tamano-xs); color: var(--color-texto-secundario); padding: var(--espacio-xs);">No hay elementos agregados.</li>`;
    return;
  }

  ul.innerHTML = arreglo.map((texto, idx) => `
    <li class="item-dinamico">
      <span class="item-dinamico__texto">${ui.escapar(texto)}</span>
      <button type="button" class="btn-icono btn-quitar-item" data-tipo="${tipoItem}" data-idx="${idx}" title="Quitar">
        ✕
      </button>
    </li>
  `).join('');

  ul.querySelectorAll('.btn-quitar-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.getAttribute('data-idx'), 10);
      arreglo.splice(idx, 1);
      marcarCambio();
      renderizarListaSimple(idLista, idContador, arreglo, tipoItem);
    });
  });
}

function renderizarRecursos() {
  const ul = document.getElementById('lista-recursos');
  const contador = document.getElementById('contador-recursos');
  if (!ul) return;

  if (contador) contador.textContent = String(recursos.length);

  if (recursos.length === 0) {
    ul.innerHTML = `<li style="font-size: var(--tamano-xs); color: var(--color-texto-secundario); padding: var(--espacio-xs);">No hay recursos complementarios.</li>`;
    return;
  }

  ul.innerHTML = recursos.map((rec, idx) => `
    <li class="item-recurso">
      <div class="item-recurso__meta">
        <span class="insignia">${ui.escapar(rec.tipo || 'enlace')}</span>
        <strong>${ui.escapar(rec.titulo || 'Sin título')}</strong>
        <a href="${ui.escapar(rec.url || '#')}" target="_blank" rel="noopener noreferrer" style="font-size: var(--tamano-xs); color: var(--color-primario); word-break: break-all;">
          ${ui.escapar(rec.url || '')}
        </a>
      </div>
      <button type="button" class="btn-icono btn-quitar-recurso" data-idx="${idx}" title="Quitar recurso">
        ✕
      </button>
    </li>
  `).join('');

  ul.querySelectorAll('.btn-quitar-recurso').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.getAttribute('data-idx'), 10);
      recursos.splice(idx, 1);
      marcarCambio();
      renderizarRecursos();
    });
  });
}

function vincularEventosFormulario() {
  const form = document.getElementById('form-ficha-tema');
  form?.addEventListener('input', () => marcarCambio());
  form?.addEventListener('change', () => marcarCambio());

  // Resumen input y preview
  const txtResumen = document.getElementById('tema-resumen');
  txtResumen?.addEventListener('input', actualizarContadorResumen);

  const btnPreview = document.getElementById('btn-toggle-preview-resumen');
  btnPreview?.addEventListener('click', () => {
    const preview = document.getElementById('resumen-preview');
    if (!preview) return;
    const estaVisible = preview.style.display !== 'none';
    if (estaVisible) {
      preview.style.display = 'none';
      btnPreview.textContent = '👁 Ver vista previa';
    } else {
      preview.innerHTML = util.formatoBasico(txtResumen.value);
      preview.style.display = 'block';
      btnPreview.textContent = '✕ Ocultar vista previa';
    }
  });

  // Agregar a listas dinámicas
  const configurarBotonAgregar = (idInput, idBoton, idLista, idContador, arreglo, tipo) => {
    const btn = document.getElementById(idBoton);
    const input = document.getElementById(idInput);

    const ejecutar = () => {
      const val = input.value.trim();
      if (!val) return;
      arreglo.push(val);
      input.value = '';
      marcarCambio();
      renderizarListaSimple(idLista, idContador, arreglo, tipo);
    };

    btn?.addEventListener('click', ejecutar);
    input?.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        ejecutar();
      }
    });
  };

  configurarBotonAgregar('input-nuevo-objetivo', 'btn-agregar-objetivo', 'lista-objetivos', 'contador-objetivos', objetivos, 'objetivo');
  configurarBotonAgregar('input-nuevo-ejemplo', 'btn-agregar-ejemplo', 'lista-ejemplos', 'contador-ejemplos', ejemplos, 'ejemplo');
  configurarBotonAgregar('input-nuevo-error', 'btn-agregar-error', 'lista-errores', 'contador-errores', erroresFrecuentes, 'error');
  configurarBotonAgregar('input-nueva-pregunta', 'btn-agregar-pregunta', 'lista-preguntas', 'contador-preguntas', preguntasGuia, 'pregunta');

  // Control de subida y recursos
  const recTipo = document.getElementById('rec-tipo');
  const btnSubirRec = document.getElementById('btn-subir-recurso');
  const fileInput = document.getElementById('rec-file-input');
  const recUrl = document.getElementById('rec-url');
  const recTitulo = document.getElementById('rec-titulo');

  const actualizarBotonSubida = () => {
    const tipo = recTipo.value;
    if (btnSubirRec) {
      btnSubirRec.style.display = (tipo === 'pdf' || tipo === 'imagen') ? 'inline-flex' : 'none';
    }
  };
  recTipo?.addEventListener('change', actualizarBotonSubida);
  actualizarBotonSubida();

  btnSubirRec?.addEventListener('click', () => {
    fileInput?.click();
  });

  fileInput?.addEventListener('change', async () => {
    const archivo = fileInput.files?.[0];
    if (!archivo) return;

    ui.cargando(true);
    try {
      const respuesta = await api.subir(archivo);
      if (respuesta && respuesta.url) {
        recUrl.value = respuesta.url;
        if (!recTitulo.value.trim()) {
          recTitulo.value = archivo.name;
        }
        ui.aviso('Archivo subido correctamente.', 'exito');
        marcarCambio();
      }
    } catch (err) {
      ui.aviso('Error al subir archivo: ' + err.message, 'error');
    } finally {
      ui.cargando(false);
      fileInput.value = '';
    }
  });

  document.getElementById('btn-agregar-recurso')?.addEventListener('click', () => {
    const tipo = recTipo.value;
    const titulo = recTitulo.value.trim();
    const url = recUrl.value.trim();

    if (!titulo || !url) {
      ui.aviso('El título y la URL del recurso son requeridos.', 'error');
      return;
    }

    recursos.push({ tipo, titulo, url });
    recTitulo.value = '';
    recUrl.value = '';
    marcarCambio();
    renderizarRecursos();
  });

  // Guardar ficha completa
  document.getElementById('btn-guardar-tema')?.addEventListener('click', () => {
    guardarFichaTema();
  });

  // Generación pedagógica con Gemini IA
  document.getElementById('btn-generar-ia')?.addEventListener('click', () => {
    abrirModalGenerarGlosarioIA();
  });

  document.getElementById('btn-generar-preguntas-ia')?.addEventListener('click', () => {
    abrirModalGenerarPreguntasIA();
  });

  document.getElementById('btn-generar-preguntas-modal')?.addEventListener('click', () => {
    abrirModalGenerarPreguntasIA();
  });
}


async function guardarFichaTema() {
  const titulo = document.getElementById('tema-titulo')?.value.trim();
  const estado = document.getElementById('tema-estado')?.value || 'borrador';
  const dificultad = document.getElementById('tema-dificultad')?.value || 'media';
  const palabrasClaveRaw = document.getElementById('tema-palabras-clave')?.value.trim();
  const fuentes = document.getElementById('tema-fuentes')?.value.trim();
  const resumen = document.getElementById('tema-resumen')?.value.trim();

  if (!titulo) {
    ui.aviso('El título del tema es obligatorio.', 'error');
    return;
  }

  const palabrasClave = palabrasClaveRaw
    ? palabrasClaveRaw.split(',').map(p => p.trim()).filter(Boolean)
    : [];

  const datosActualizados = {
    titulo,
    estado,
    dificultad,
    palabrasClave,
    fuentes,
    resumen,
    objetivos,
    ejemplos,
    erroresFrecuentes,
    preguntasGuia,
    recursos
  };

  ui.cargando(true);
  try {
    const actualizado = await api.actualizar('temas', temaActual.id, datosActualizados);
    temaActual = actualizado;
    hayCambiosSinGuardar = false;

    // Actualizar indicador en cabecera
    const indicadorEstado = document.getElementById('tema-indicador-estado');
    if (indicadorEstado) {
      const esPublicado = actualizado.estado === 'publicado';
      indicadorEstado.innerHTML = `
        <span class="insignia ${esPublicado ? 'insignia--exito' : 'insignia--advertencia'}">
          ${esPublicado ? 'Publicado' : 'Borrador'}
        </span>
      `;
    }

    const tituloCabecera = document.getElementById('tema-titulo-cabecera');
    if (tituloCabecera) tituloCabecera.textContent = actualizado.titulo;

    ui.aviso('Ficha del tema guardada exitosamente.', 'exito');
  } catch (err) {
    ui.aviso('Error al guardar tema: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

/* ==========================================================================
   2. GESTIÓN DEL GLOSARIO DEL TEMA
   ========================================================================== */

function actualizarGlosarioVista() {
  const tbody = document.getElementById('cuerpo-tabla-glosario');
  const badgeTotal = document.getElementById('badge-total-terminos');
  const badge6 = document.getElementById('badge-seis-letras');
  const badgeApto = document.getElementById('badge-apto-juegos');

  const total = glosarioTema.length;
  const terms6 = glosarioTema.filter(g => util.normalizar(g.termino).length === 6).length;
  const esApto = total >= 12 && terms6 >= 3;

  if (badgeTotal) badgeTotal.textContent = `Términos: ${total}`;
  if (badge6) badge6.textContent = `6 letras: ${terms6}`;

  if (badgeApto) {
    if (esApto) {
      badgeApto.textContent = '✔ Apto para juegos';
      badgeApto.className = 'insignia insignia--exito';
    } else {
      badgeApto.textContent = `No apto (${total}/12 y ${terms6}/3 de 6 letras)`;
      badgeApto.className = 'insignia insignia--advertencia';
    }
  }

  if (!tbody) return;

  if (glosarioTema.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" style="text-align: center; color: var(--color-texto-secundario); padding: var(--espacio-xl);">
          No hay términos en el glosario de este tema. Pulsa "+ Nuevo término" para comenzar.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = glosarioTema.map(g => {
    const terminoNorm = util.normalizar(g.termino);
    const es6Letras = terminoNorm.length === 6;
    const cantPalabrasDef = contarPalabras(g.definicion);
    const cantPalabrasPista = contarPalabras(g.pista);

    return `
      <tr data-id="${ui.escapar(g.id)}">
        <td>
          <strong>${ui.escapar(terminoNorm)}</strong>
          <br>
          <span class="insignia ${es6Letras ? 'insignia--exito' : ''}" style="font-size: 10px;">
            ${terminoNorm.length} letras
          </span>
        </td>
        <td>
          ${ui.escapar(g.definicion || '')}
          <br>
          <small style="color: ${cantPalabrasDef > 25 ? 'var(--color-peligro)' : 'var(--color-texto-secundario)'}; font-size: 11px;">
            ${cantPalabrasDef}/25 palabras
          </small>
        </td>
        <td>
          ${ui.escapar(g.pista || '')}
          <br>
          <small style="color: ${cantPalabrasPista > 10 ? 'var(--color-peligro)' : 'var(--color-texto-secundario)'}; font-size: 11px;">
            ${cantPalabrasPista}/10 palabras
          </small>
        </td>
        <td>
          <small>${ui.escapar(g.retroalimentacion || '')}</small>
        </td>
        <td style="text-align: right; white-space: nowrap;">
          <button type="button" class="btn btn--secundario btn--pequeno btn-editar-termino" data-id="${ui.escapar(g.id)}">
            Editar
          </button>
          <button type="button" class="btn btn--peligro btn--pequeno btn-eliminar-termino" data-id="${ui.escapar(g.id)}">
            Eliminar
          </button>
        </td>
      </tr>
    `;
  }).join('');

  // Eventos de botones en la tabla
  tbody.querySelectorAll('.btn-editar-termino').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const termino = glosarioTema.find(item => item.id === id);
      if (termino) abrirModalTermino(termino);
    });
  });

  tbody.querySelectorAll('.btn-eliminar-termino').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const termino = glosarioTema.find(item => item.id === id);
      if (termino) eliminarTermino(termino);
    });
  });
}

document.getElementById('btn-agregar-termino')?.addEventListener('click', () => {
  abrirModalTermino();
});

async function abrirModalTermino(terminoExistente = null) {
  const esEdicion = Boolean(terminoExistente);
  const tituloModal = esEdicion ? 'Editar término del glosario' : 'Nuevo término del glosario';

  const form = document.createElement('form');
  form.className = 'form-glosario-modal';
  form.innerHTML = `
    <div class="campo-tema">
      <label for="modal-glo-termino">Término * (una sola palabra)</label>
      <input type="text" id="modal-glo-termino" required value="${ui.escapar(terminoExistente?.termino || '')}" placeholder="EJEMPLO: METADATO" />
      <small id="modal-glo-termino-letras" style="color: var(--color-texto-secundario);">0 letras</small>
    </div>

    <div class="campo-tema">
      <div class="meta-contador-modal">
        <label for="modal-glo-definicion">Definición *</label>
        <span id="modal-glo-definicion-palabras">0/25 palabras</span>
      </div>
      <textarea id="modal-glo-definicion" rows="3" required placeholder="Explicación clara y concisa">${ui.escapar(terminoExistente?.definicion || '')}</textarea>
    </div>

    <div class="campo-tema">
      <div class="meta-contador-modal">
        <label for="modal-glo-pista">Pista breve *</label>
        <span id="modal-glo-pista-palabras">0/10 palabras</span>
      </div>
      <input type="text" id="modal-glo-pista" required value="${ui.escapar(terminoExistente?.pista || '')}" placeholder="Pista para adivinar el término" />
    </div>

    <div class="campo-tema">
      <label for="modal-glo-retro">Retroalimentación pedagógica *</label>
      <textarea id="modal-glo-retro" rows="2" required placeholder="Mensaje al acertar el término">${ui.escapar(terminoExistente?.retroalimentacion || '')}</textarea>
    </div>
  `;

  form.addEventListener('submit', e => e.preventDefault());

  // Contadores en tiempo real
  const inputTermino = form.querySelector('#modal-glo-termino');
  const spanLetras = form.querySelector('#modal-glo-termino-letras');
  const txtDef = form.querySelector('#modal-glo-definicion');
  const spanDef = form.querySelector('#modal-glo-definicion-palabras');
  const inputPista = form.querySelector('#modal-glo-pista');
  const spanPista = form.querySelector('#modal-glo-pista-palabras');

  const actualizarConteoModal = () => {
    const tNorm = util.normalizar(inputTermino.value);
    spanLetras.textContent = `${tNorm.length} letras${tNorm.length === 6 ? ' (¡De 6 letras!)' : ''}`;
    if (tNorm.length === 6) spanLetras.style.color = 'var(--color-exito)';
    else spanLetras.style.color = 'var(--color-texto-secundario)';

    const palDef = contarPalabras(txtDef.value);
    spanDef.textContent = `${palDef}/25 palabras`;
    spanDef.style.color = palDef > 25 ? 'var(--color-peligro)' : 'var(--color-texto-secundario)';

    const palPista = contarPalabras(inputPista.value);
    spanPista.textContent = `${palPista}/10 palabras`;
    spanPista.style.color = palPista > 10 ? 'var(--color-peligro)' : 'var(--color-texto-secundario)';
  };

  inputTermino.addEventListener('input', actualizarConteoModal);
  txtDef.addEventListener('input', actualizarConteoModal);
  inputPista.addEventListener('input', actualizarConteoModal);
  actualizarConteoModal();

  const accion = await ui.modal({
    titulo: tituloModal,
    contenido: form,
    acciones: [
      { texto: 'Cancelar', valor: null, clase: 'btn--secundario' },
      { texto: esEdicion ? 'Guardar cambios' : 'Crear término', valor: 'guardar', clase: 'btn--primario' }
    ]
  });

  if (accion !== 'guardar') return;

  const terminoRaw = inputTermino.value.trim();
  const terminoNorm = util.normalizar(terminoRaw);
  const definicion = txtDef.value.trim();
  const pista = inputPista.value.trim();
  const retroalimentacion = form.querySelector('#modal-glo-retro')?.value.trim();

  if (!terminoNorm || !definicion || !pista || !retroalimentacion) {
    ui.aviso('Todos los campos son obligatorios.', 'error');
    return;
  }

  if (terminoNorm.includes(' ')) {
    ui.aviso('El término debe ser una sola palabra (sin espacios).', 'error');
    return;
  }

  if (contarPalabras(definicion) > 25) {
    ui.aviso('La definición no debe superar las 25 palabras.', 'error');
    return;
  }

  if (contarPalabras(pista) > 10) {
    ui.aviso('La pista no debe superar las 10 palabras.', 'error');
    return;
  }

  const datosTermino = {
    temaId: temaActual.id,
    termino: terminoNorm,
    definicion,
    pista,
    retroalimentacion,
    origen: 'docente',
    estado: 'aprobado'
  };

  ui.cargando(true);
  try {
    if (esEdicion) {
      await api.actualizar('glosario', terminoExistente.id, datosTermino);
      ui.aviso('Término actualizado exitosamente.', 'exito');
    } else {
      await api.crear('glosario', datosTermino);
      ui.aviso('Término creado exitosamente.', 'exito');
    }

    // Recargar glosario
    const listaActualizada = await api.listar('glosario', { temaId: temaActual.id });
    glosarioTema = listaActualizada || [];
    actualizarGlosarioVista();
  } catch (err) {
    ui.aviso('Error al guardar término: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

async function eliminarTermino(termino) {
  const confirmado = await ui.confirmar(`¿Estás seguro de eliminar el término "${termino.termino}" del glosario?`);
  if (!confirmado) return;

  ui.cargando(true);
  try {
    await api.eliminar('glosario', termino.id);
    ui.aviso('Término eliminado del glosario.', 'exito');
    const listaActualizada = await api.listar('glosario', { temaId: temaActual.id });
    glosarioTema = listaActualizada || [];
    actualizarGlosarioVista();
  } catch (err) {
    ui.aviso('Error al eliminar término: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

let preguntasBorrador = [];

/**
 * Renderiza el banco de preguntas del tema
 */
function actualizarPreguntasVista() {
  const contenedor = document.getElementById('contenedor-preguntas-tema');
  const badgeTotal = document.getElementById('badge-total-preguntas-quiz');
  const badgeAvance = document.getElementById('badge-avance-contenidos');
  const indicadorAvanceCabecera = document.getElementById('tema-indicador-avance');
  if (!contenedor) return;

  if (badgeTotal) {
    badgeTotal.textContent = `${preguntasTema.length} pregunta${preguntasTema.length === 1 ? '' : 's'} registrada${preguntasTema.length === 1 ? '' : 's'}`;
  }

  // Si hay preguntas en el banco o se generaron preguntas con IA, el avance de contenidos es 100%
  const mostrarAvanceCompleto = preguntasTema.length > 0 || preguntasBorrador.length > 0;
  if (badgeAvance) {
    badgeAvance.style.display = mostrarAvanceCompleto ? 'inline-block' : 'none';
  }
  if (indicadorAvanceCabecera) {
    indicadorAvanceCabecera.innerHTML = mostrarAvanceCompleto
      ? '<span class="insignia insignia--exito">Avance de contenidos: 100%</span>'
      : '';
  }

  if (preguntasTema.length === 0) {
    contenedor.innerHTML = `
      <div class="aviso aviso--info">
        No hay preguntas registradas en el banco aún. Haz clic en <strong>"✨ Crear con Gemini IA"</strong> o en <strong>"🎯 Generar Preguntas con IA"</strong> para generar automáticamente reactivos formativos sobre oraciones condicionales en inglés listos para revisión y publicación.
      </div>
    `;
    return;
  }

  contenedor.innerHTML = preguntasTema.map((p, idx) => {
    let opcionesHtml = '';
    if (Array.isArray(p.opciones) && p.opciones.length > 0) {
      opcionesHtml = `
        <ul class="opciones-lista-ia">
          ${p.opciones.map((opc, opcIdx) => {
            const esCorrecta = Number(p.correcta) === opcIdx || p.correcta === opc || (p.tipo === 'vf' && ((p.correcta === true && String(opc).toLowerCase() === 'verdadero') || (p.correcta === false && String(opc).toLowerCase() === 'falso')));
            return `
              <li class="opcion-item-ia ${esCorrecta ? 'opcion-item-ia--correcta' : ''}">
                <span><strong>${String.fromCharCode(65 + opcIdx)}.</strong> ${ui.escapar(String(opc))}</span>
                ${esCorrecta ? '<span>✓ Respuesta correcta</span>' : ''}
              </li>
            `;
          }).join('')}
        </ul>
      `;
    } else if (p.tipo === 'completar') {
      opcionesHtml = `
        <div class="opcion-item-ia opcion-item-ia--correcta" style="margin-bottom: var(--espacio-s);">
          <span>Respuesta para completar: <strong>${ui.escapar(String(p.correcta))}</strong></span>
        </div>
      `;
    }

    return `
      <article class="tarjeta-pregunta-ia" data-id="${ui.escapar(p.id)}">
        <header class="tarjeta-pregunta-ia__cabecera">
          <div class="fila" style="gap: var(--espacio-xs); flex-wrap: wrap;">
            <span class="insignia insignia--primario">Pregunta ${idx + 1}</span>
            <span class="insignia insignia--secundario">${ui.escapar(p.tipo || 'opcion')}</span>
            <span class="insignia insignia--acento">Nivel ${p.nivel || 1}</span>
            ${p.origen === 'ia' ? '<span class="insignia" style="background:#e0f2fe; color:#0369a1;">✨ Gemini 3.5 Flash</span>' : ''}
          </div>
          <div class="tarjeta-pregunta-ia__acciones">
            <button type="button" class="btn btn--texto btn--pequeno btn-editar-pregunta" data-idx="${idx}" title="Editar pregunta">
              ✏️ Editar
            </button>
            <button type="button" class="btn btn--texto btn--pequeno btn-eliminar-pregunta" data-id="${ui.escapar(p.id)}" style="color: var(--color-error);" title="Eliminar pregunta">
              ✕ Eliminar
            </button>
          </div>
        </header>

        <p class="tarjeta-pregunta-ia__enunciado">${ui.escapar(p.enunciado)}</p>

        ${opcionesHtml}

        ${p.retroalimentacion ? `
          <div class="tarjeta-pregunta-ia__retro">
            <strong>Retroalimentación explicativa:</strong> ${ui.escapar(p.retroalimentacion)}
          </div>
        ` : ''}
      </article>
    `;
  }).join('');

  // Event listeners para editar preguntas registradas
  contenedor.querySelectorAll('.btn-editar-pregunta').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-idx'));
      if (preguntasTema[idx]) {
        abrirModalEditarPregunta(preguntasTema[idx], idx, false);
      }
    });
  });

  // Event listeners para eliminar preguntas registradas
  contenedor.querySelectorAll('.btn-eliminar-pregunta').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      const confirmado = await ui.confirmar('¿Deseas eliminar esta pregunta del banco de quizes del tema?');
      if (!confirmado) return;
      ui.cargando(true);
      try {
        await api.eliminar('preguntas', id);
        preguntasTema = preguntasTema.filter(p => p.id !== id);
        actualizarPreguntasVista();
        ui.aviso('Pregunta eliminada con éxito.', 'exito');
      } catch (err) {
        ui.aviso('Error al eliminar pregunta: ' + err.message, 'error');
      } finally {
        ui.cargando(false);
      }
    });
  });
}

/**
 * Renderiza el panel de borrador para revisar, editar y guardar preguntas antes de publicarlas
 */
function actualizarBorradorVista() {
  const panel = document.getElementById('panel-borrador-preguntas');
  const lista = document.getElementById('lista-borrador-preguntas');
  const contadorBtn = document.getElementById('contador-borrador-btn');
  const btnGuardarTodas = document.getElementById('btn-guardar-todas-borrador');
  const btnCancelar = document.getElementById('btn-cancelar-borrador');

  if (!panel || !lista) return;

  if (preguntasBorrador.length === 0) {
    panel.style.display = 'none';
    lista.innerHTML = '';
    return;
  }

  panel.style.display = 'block';
  if (contadorBtn) contadorBtn.textContent = preguntasBorrador.length;

  lista.innerHTML = preguntasBorrador.map((p, idx) => {
    let opcionesHtml = '';
    if (Array.isArray(p.opciones) && p.opciones.length > 0) {
      opcionesHtml = `
        <ul class="opciones-lista-ia">
          ${p.opciones.map((opc, opcIdx) => {
            const esCorrecta = Number(p.correcta) === opcIdx;
            return `
              <li class="opcion-item-ia ${esCorrecta ? 'opcion-item-ia--correcta' : ''}">
                <span><strong>${String.fromCharCode(65 + opcIdx)}.</strong> ${ui.escapar(String(opc))}</span>
                ${esCorrecta ? '<span>✓ Respuesta correcta</span>' : ''}
              </li>
            `;
          }).join('')}
        </ul>
      `;
    }

    return `
      <article class="tarjeta-pregunta-borrador" data-idx="${idx}">
        <header class="tarjeta-pregunta-ia__cabecera">
          <div class="fila" style="gap: var(--espacio-xs); flex-wrap: wrap;">
            <span class="insignia insignia--advertencia">Borrador IA (${idx + 1}/${preguntasBorrador.length})</span>
            <span class="insignia insignia--secundario">${ui.escapar(p.tipo || 'opcion')}</span>
            <span class="insignia insignia--acento">Nivel ${p.nivel || 1}</span>
            <span class="insignia" style="background:#fef3c7; color:#92400e;">Revisión pendiente</span>
          </div>
          <div class="tarjeta-pregunta-ia__acciones">
            <button type="button" class="btn btn--secundario btn--pequeno btn-editar-borrador" data-idx="${idx}">
              ✏️ Editar
            </button>
            <button type="button" class="btn btn--primario btn--pequeno btn-guardar-borrador-item" data-idx="${idx}">
              💾 Guardar
            </button>
            <button type="button" class="btn btn--texto btn--pequeno btn-descartar-borrador-item" data-idx="${idx}" style="color: var(--color-error);">
              ✕ Descartar
            </button>
          </div>
        </header>

        <p class="tarjeta-pregunta-ia__enunciado">${ui.escapar(p.enunciado)}</p>

        ${opcionesHtml}

        ${p.retroalimentacion ? `
          <div class="tarjeta-pregunta-ia__retro">
            <strong>Retroalimentación explicativa:</strong> ${ui.escapar(p.retroalimentacion)}
          </div>
        ` : ''}
      </article>
    `;
  }).join('');

  // Acciones en cada item del borrador
  lista.querySelectorAll('.btn-editar-borrador').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-idx'));
      if (preguntasBorrador[idx]) {
        abrirModalEditarPregunta(preguntasBorrador[idx], idx, true);
      }
    });
  });

  lista.querySelectorAll('.btn-guardar-borrador-item').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = Number(btn.getAttribute('data-idx'));
      const item = preguntasBorrador[idx];
      if (!item) return;

      ui.cargando(true);
      try {
        const guardada = await api.crear('preguntas', {
          temaId: temaActual.id,
          nivel: Number(item.nivel) || 1,
          tipo: item.tipo || 'opcion',
          enunciado: item.enunciado,
          opciones: item.opciones,
          correcta: item.correcta,
          retroalimentacion: item.retroalimentacion,
          origen: 'ia',
          estado: 'aprobado'
        });

        preguntasTema.push(guardada);
        preguntasBorrador.splice(idx, 1);
        actualizarBorradorVista();
        actualizarPreguntasVista();
        ui.aviso('Pregunta guardada en el banco de quizes.', 'exito');
      } catch (err) {
        ui.aviso('Error al guardar pregunta: ' + err.message, 'error');
      } finally {
        ui.cargando(false);
      }
    });
  });

  lista.querySelectorAll('.btn-descartar-borrador-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-idx'));
      preguntasBorrador.splice(idx, 1);
      actualizarBorradorVista();
      actualizarPreguntasVista();
    });
  });

  // Guardar todas las preguntas del borrador
  if (btnGuardarTodas) {
    btnGuardarTodas.onclick = async () => {
      if (preguntasBorrador.length === 0) return;
      ui.cargando(true);
      try {
        let guardadasCount = 0;
        for (const item of preguntasBorrador) {
          const guardada = await api.crear('preguntas', {
            temaId: temaActual.id,
            nivel: Number(item.nivel) || 1,
            tipo: item.tipo || 'opcion',
            enunciado: item.enunciado,
            opciones: item.opciones,
            correcta: item.correcta,
            retroalimentacion: item.retroalimentacion,
            origen: 'ia',
            estado: 'aprobado'
          });
          preguntasTema.push(guardada);
          guardadasCount++;
        }
        preguntasBorrador = [];
        actualizarBorradorVista();
        actualizarPreguntasVista();
        ui.aviso(`Se guardaron y publicaron ${guardadasCount} preguntas formativas en el banco de quizes.`, 'exito');
      } catch (err) {
        ui.aviso('Error al guardar preguntas: ' + err.message, 'error');
      } finally {
        ui.cargando(false);
      }
    };
  }

  // Cancelar/descartar todo el borrador
  if (btnCancelar) {
    btnCancelar.onclick = async () => {
      const confirmado = await ui.confirmar('¿Deseas descartar todas las preguntas del borrador generado?');
      if (!confirmado) return;
      preguntasBorrador = [];
      actualizarBorradorVista();
      actualizarPreguntasVista();
    };
  }
}

/**
 * Modal para editar una pregunta (tanto en borrador de revisión como en el banco guardado)
 * @param {object} pregunta
 * @param {number} index
 * @param {boolean} esBorrador
 */
async function abrirModalEditarPregunta(pregunta, index, esBorrador = false) {
  const opciones = Array.isArray(pregunta.opciones) && pregunta.opciones.length >= 4
    ? pregunta.opciones
    : [
        pregunta.opciones?.[0] || 'Opción A',
        pregunta.opciones?.[1] || 'Opción B',
        pregunta.opciones?.[2] || 'Opción C',
        pregunta.opciones?.[3] || 'Opción D'
      ];

  const indiceCorrecta = Number(pregunta.correcta) || 0;

  const contenidoModal = `
    <form id="form-editar-pregunta-modal" class="modal-editar-pregunta">
      <div class="campo">
        <label for="edit-preg-enunciado"><strong>Enunciado de la pregunta:</strong></label>
        <textarea id="edit-preg-enunciado" class="control" rows="3" required>${ui.escapar(pregunta.enunciado || '')}</textarea>
      </div>

      <div class="campo">
        <label><strong>Cuatro opciones de respuesta (selecciona el botón de la respuesta correcta):</strong></label>
        ${opciones.slice(0, 4).map((opc, opcIdx) => `
          <div class="modal-editar-pregunta__opcion-fila">
            <input
              type="radio"
              name="edit-preg-radio-correcta"
              id="edit-radio-${opcIdx}"
              value="${opcIdx}"
              class="modal-editar-pregunta__radio"
              ${indiceCorrecta === opcIdx ? 'checked' : ''}
              title="Marcar como respuesta correcta"
            />
            <label for="edit-radio-${opcIdx}" style="min-width: 28px; font-weight: bold;">${String.fromCharCode(65 + opcIdx)}.</label>
            <input
              type="text"
              id="edit-opcion-${opcIdx}"
              class="control"
              value="${ui.escapar(String(opc))}"
              required
              placeholder="Texto de la opción ${String.fromCharCode(65 + opcIdx)}..."
            />
          </div>
        `).join('')}
      </div>

      <div class="campo">
        <label for="edit-preg-retro"><strong>Retroalimentación explicativa:</strong></label>
        <textarea id="edit-preg-retro" class="control" rows="2" required placeholder="Explica la regla gramatical y por qué es la respuesta correcta...">${ui.escapar(pregunta.retroalimentacion || '')}</textarea>
      </div>
    </form>
  `;

  const respuestaModal = await ui.modal({
    titulo: esBorrador ? '✏️ Editar Pregunta del Borrador' : '✏️ Editar Pregunta del Banco',
    contenido: contenidoModal,
    acciones: [
      { id: 'cancelar', texto: 'Cancelar', clase: 'btn btn--secundario' },
      { id: 'guardar', texto: 'Guardar cambios', clase: 'btn btn--primario' }
    ]
  });

  if (respuestaModal === 'guardar') {
    const enunciado = document.getElementById('edit-preg-enunciado')?.value.trim();
    const retroalimentacion = document.getElementById('edit-preg-retro')?.value.trim();
    const radios = document.getElementsByName('edit-preg-radio-correcta');
    let nuevaCorrecta = 0;
    for (const r of radios) {
      if (r.checked) {
        nuevaCorrecta = Number(r.value);
        break;
      }
    }

    const nuevasOpciones = [
      document.getElementById('edit-opcion-0')?.value.trim() || 'Opción A',
      document.getElementById('edit-opcion-1')?.value.trim() || 'Opción B',
      document.getElementById('edit-opcion-2')?.value.trim() || 'Opción C',
      document.getElementById('edit-opcion-3')?.value.trim() || 'Opción D'
    ];

    if (!enunciado) {
      ui.aviso('El enunciado de la pregunta no puede estar vacío.', 'error');
      return;
    }

    const preguntaModificada = {
      ...pregunta,
      tipo: 'opcion',
      enunciado,
      opciones: nuevasOpciones,
      correcta: nuevaCorrecta,
      retroalimentacion
    };

    if (esBorrador) {
      preguntasBorrador[index] = preguntaModificada;
      actualizarBorradorVista();
      ui.aviso('Pregunta en borrador actualizada exitosamente.', 'exito');
    } else {
      ui.cargando(true);
      try {
        const actualizada = await api.actualizar('preguntas', pregunta.id, {
          tipo: 'opcion',
          enunciado,
          opciones: nuevasOpciones,
          correcta: nuevaCorrecta,
          retroalimentacion
        });
        preguntasTema[index] = actualizada || preguntaModificada;
        actualizarPreguntasVista();
        ui.aviso('Pregunta actualizada en el banco de quizes.', 'exito');
      } catch (err) {
        ui.aviso('Error al actualizar pregunta: ' + err.message, 'error');
      } finally {
        ui.cargando(false);
      }
    }
  }
}

/**
 * Modal para generar preguntas formativas con Gemini IA
 */
async function abrirModalGenerarPreguntasIA() {
  if (!temaActual || !temaActual.id) {
    ui.aviso('Primero debes seleccionar un tema válido.', 'error');
    return;
  }

  const tituloMinus = (temaActual.titulo || '').toLowerCase();
  const resumenMinus = (temaActual.resumen || '').toLowerCase();
  const esCondicionales = (
    tituloMinus.includes('condicional') ||
    tituloMinus.includes('ingles') ||
    tituloMinus.includes('english') ||
    resumenMinus.includes('conditional') ||
    resumenMinus.includes('condicional')
  );

  const descripcionContexto = esCondicionales
    ? `
      <div class="aviso aviso--exito" style="margin-bottom: var(--espacio-m);">
        <strong>🎯 Generación Especializada: Oraciones Condicionales en Inglés</strong><br>
        Gemini 3.5 Flash generará preguntas formativas de opción múltiple con 4 opciones de respuesta, respuesta correcta y retroalimentación explicativa, cubriendo exclusivamente:
        <strong>Zero Conditional, First Conditional, Second Conditional, Third Conditional y Mixed Conditionals</strong>.
      </div>
    `
    : `
      <p style="margin: 0 0 var(--espacio-m) 0; color: var(--color-texto-suave);">
        Gemini 3.5 Flash analizará los objetivos y contenidos del tema <strong>"${ui.escapar(temaActual.titulo)}"</strong> para generar reactivos con 4 opciones y retroalimentación pedagógica explicativa.
      </p>
    `;

  const contenidoModal = `
    <div class="form-glosario-modal">
      ${descripcionContexto}

      <div class="campo">
        <label for="ia-preguntas-nivel">Nivel Cognitivo (Taxonomía de Bloom):</label>
        <select id="ia-preguntas-nivel" class="control">
          <option value="1|Recordar (Nivel 1)">Nivel 1 · Recordar (Identificación de estructuras y verbos condicionales)</option>
          <option value="2|Comprender (Nivel 2)" selected>Nivel 2 · Comprender (Uso, significado y reglas de las oraciones condicionales)</option>
          <option value="3|Aplicar (Nivel 3)">Nivel 3 · Aplicar (Completar y conjugar oraciones en contextos comunicativos)</option>
          <option value="4|Analizar (Nivel 4)">Nivel 4 · Analizar (Corrección de errores y diferenciación entre condicionales)</option>
          <option value="5|Evaluar (Nivel 5)">Nivel 5 · Evaluar (Selección precisa según intención comunicativa)</option>
        </select>
      </div>

      <div class="campo">
        <label for="ia-preguntas-cantidad">Cantidad de reactivos a generar:</label>
        <select id="ia-preguntas-cantidad" class="control">
          <option value="5" selected>5 preguntas (1 por cada condicional: Zero, 1st, 2nd, 3rd y Mixed)</option>
          <option value="3">3 preguntas formativas</option>
          <option value="8">8 preguntas formativas</option>
          <option value="10">10 preguntas formativas</option>
        </select>
      </div>
    </div>
  `;

  const respuestaModal = await ui.modal({
    titulo: '🎯 Generar Preguntas Formativas con Gemini IA',
    contenido: contenidoModal,
    acciones: [
      { id: 'cancelar', texto: 'Cancelar', clase: 'btn btn--secundario' },
      { id: 'generar', texto: '✨ Generar para Revisión', clase: 'btn btn--acento' }
    ]
  });

  if (respuestaModal === 'generar') {
    const selectorNivel = document.getElementById('ia-preguntas-nivel')?.value || '2|Comprender';
    const [nivelNum, nivelBloom] = selectorNivel.split('|');
    const cantidad = Number(document.getElementById('ia-preguntas-cantidad')?.value) || 5;

    ui.cargando(true);
    try {
      const res = await api.ia('generar-preguntas', {
        temaId: temaActual.id,
        nivel: Number(nivelNum) || 1,
        nivelBloom,
        cantidad,
        guardar: false,
        condicionales: esCondicionales
      });

      if (res && res.ok && Array.isArray(res.datos)) {
        // Normalizar preguntas generadas para asegurar 4 opciones y formato correcto
        preguntasBorrador = res.datos.map((item, i) => {
          let opciones = Array.isArray(item.opciones) ? item.opciones : [];
          while (opciones.length < 4) {
            opciones.push(`Opción ${String.fromCharCode(65 + opciones.length)}`);
          }
          if (opciones.length > 4) {
            opciones = opciones.slice(0, 4);
          }

          let correcta = 0;
          if (typeof item.correcta === 'number' && item.correcta >= 0 && item.correcta < 4) {
            correcta = item.correcta;
          } else if (typeof item.correcta === 'string') {
            const encontrado = opciones.findIndex(o => String(o).toLowerCase() === item.correcta.toLowerCase());
            correcta = encontrado >= 0 ? encontrado : 0;
          }

          return {
            enunciado: item.enunciado || `Pregunta formativa ${i + 1} sobre oraciones condicionales`,
            tipo: 'opcion',
            nivel: Number(nivelNum) || 1,
            opciones,
            correcta,
            retroalimentacion: item.retroalimentacion || 'Retroalimentación formativa de la oración condicional evaluada.'
          };
        });

        actualizarBorradorVista();
        actualizarPreguntasVista();

        // Desplazar suavemente hacia el panel de borrador para revisión del docente
        const panelBorrador = document.getElementById('panel-borrador-preguntas');
        if (panelBorrador) {
          panelBorrador.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        ui.aviso(`Se generaron ${preguntasBorrador.length} preguntas formativas. Revisa, edita o descarta cada pregunta antes de publicarla.`, 'exito');
      }
    } catch (err) {
      ui.aviso('Error al generar preguntas con IA: ' + err.message, 'error');
    } finally {
      ui.cargando(false);
    }
  }
}

/**
 * Modal para generar términos de glosario con Gemini IA
 */
async function abrirModalGenerarGlosarioIA() {
  if (!temaActual || !temaActual.id) {
    ui.aviso('Primero debes seleccionar un tema válido.', 'error');
    return;
  }

  const contenidoModal = `
    <div class="form-glosario-modal">
      <p style="margin: 0; color: var(--color-texto-suave);">
        Gemini 3.5 Flash extraerá términos clave del tema con definiciones cortas (≤25 palabras), pistas y palabras de 6 letras para juegos.
      </p>

      <div class="campo">
        <label for="ia-glosario-cantidad">Cantidad de términos:</label>
        <select id="ia-glosario-cantidad" class="control">
          <option value="3">3 términos</option>
          <option value="5" selected>5 términos (Recomendado)</option>
          <option value="8">8 términos</option>
        </select>
      </div>
    </div>
  `;

  const respuestaModal = await ui.modal({
    titulo: '✨ Generar Glosario con Gemini IA',
    contenido: contenidoModal,
    acciones: [
      { id: 'cancelar', texto: 'Cancelar', clase: 'btn btn--secundario' },
      { id: 'generar', texto: '✨ Generar Términos', clase: 'btn btn--primario' }
    ]
  });

  if (respuestaModal === 'generar') {
    const cantidad = Number(document.getElementById('ia-glosario-cantidad')?.value) || 5;

    ui.cargando(true);
    try {
      const res = await api.ia('generar-glosario', {
        temaId: temaActual.id,
        cantidad,
        guardar: true
      });

      if (res && res.ok) {
        const listaGlosarioActualizada = await api.listar('glosario', { temaId: temaActual.id });
        glosarioTema = listaGlosarioActualizada || [];
        actualizarGlosarioVista();
        ui.aviso(`Se generaron y guardaron ${res.cantidad || glosarioTema.length} términos con Gemini IA.`, 'exito');
      }
    } catch (err) {
      ui.aviso('Error al generar glosario con IA: ' + err.message, 'error');
    } finally {
      ui.cargando(false);
    }
  }
}

inicializar();

