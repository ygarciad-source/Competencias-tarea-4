/**
 * Módulo perfil.js - Visualización y gestión de perfil de usuario
 * Permite editar nombre, apellido, foto y contraseña con actualización de sesión.
 */

import { montarPlantilla } from '/js/nucleo/plantilla.js';
import { usuarioActual } from '/js/nucleo/sesion.js';
import { llamar, subir } from '/js/nucleo/api.js';
import { aviso, escapar } from '/js/nucleo/ui.js';

await montarPlantilla({ titulo: 'Mi Perfil', roles: ['sesion'] });

const contenido = document.getElementById('contenido');
let usuarioLocal = usuarioActual();

if (contenido && usuarioLocal) {
  function renderizarPerfil() {
    const inicial = (usuarioLocal.nombre ? usuarioLocal.nombre[0] : 'U').toUpperCase();
    const avatarHTML = usuarioLocal.foto
      ? `<img src="${escapar(usuarioLocal.foto)}" alt="Foto de perfil de ${escapar(usuarioLocal.nombre)}">`
      : escapar(inicial);

    contenido.innerHTML = `
      <div class="perfil-contenedor">
        <article class="perfil-tarjeta">
          <header class="perfil-cabecera">
            <div class="perfil-avatar-contenedor">
              <div id="avatar-preview" class="perfil-avatar">
                ${avatarHTML}
              </div>
            </div>
            <div class="perfil-info">
              <h1 id="perfil-nombre-completo" style="font-size: var(--tamano-xl); margin: 0;">
                ${escapar(usuarioLocal.nombre)} ${escapar(usuarioLocal.apellido || '')}
              </h1>
              <div class="fila" style="gap: var(--espacio-xs); align-items: center; margin-top: var(--espacio-xs);">
                <span class="insignia insignia--primario" style="text-transform: capitalize;">${escapar(usuarioLocal.rol || 'estudiante')}</span>
                <span style="color: var(--color-texto-claro); font-size: var(--tamano-s);">${escapar(usuarioLocal.correo)}</span>
              </div>
            </div>
          </header>

          <section class="perfil-seccion">
            <h2>Datos Personales</h2>
            <form id="form-perfil" class="pila" style="gap: var(--espacio-m);" novalidate>
              <div class="campo" id="cont-foto">
                <label for="foto">Foto de perfil (JPG, PNG o WEBP, máx 2 MB)</label>
                <input type="file" id="foto" name="foto" accept="image/png, image/jpeg, image/webp">
                <span class="campo__error" id="error-foto"></span>
              </div>

              <div class="campo" id="cont-nombre">
                <label for="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" value="${escapar(usuarioLocal.nombre)}" required>
                <span class="campo__error" id="error-nombre"></span>
              </div>

              <div class="campo" id="cont-apellido">
                <label for="apellido">Apellido</label>
                <input type="text" id="apellido" name="apellido" value="${escapar(usuarioLocal.apellido || '')}" required>
                <span class="campo__error" id="error-apellido"></span>
              </div>

              <div class="campo">
                <label for="correo">Correo institucional (no editable)</label>
                <input type="email" id="correo" value="${escapar(usuarioLocal.correo)}" disabled style="opacity: 0.7;">
              </div>

              <div class="fila" style="justify-content: flex-end;">
                <button type="submit" id="btn-guardar-perfil" class="btn btn--primario">
                  Guardar cambios
                </button>
              </div>
            </form>
          </section>

          <section class="perfil-seccion" style="border-top: 1px solid var(--color-borde); padding-top: var(--espacio-l);">
            <h2>Cambiar Contraseña</h2>
            <form id="form-clave" class="pila" style="gap: var(--espacio-m);" novalidate>
              <div class="campo" id="cont-clave-actual">
                <label for="clave-actual">Contraseña actual</label>
                <input type="password" id="clave-actual" required autocomplete="current-password">
                <span class="campo__error" id="error-clave-actual"></span>
              </div>

              <div class="campo" id="cont-clave-nueva">
                <label for="clave-nueva">Nueva contraseña (mínimo 6 caracteres)</label>
                <input type="password" id="clave-nueva" required autocomplete="new-password">
                <span class="campo__error" id="error-clave-nueva"></span>
              </div>

              <div class="campo" id="cont-clave-repetir">
                <label for="clave-repetir">Repetir nueva contraseña</label>
                <input type="password" id="clave-repetir" required autocomplete="new-password">
                <span class="campo__error" id="error-clave-repetir"></span>
              </div>

              <div class="fila" style="justify-content: flex-end;">
                <button type="submit" id="btn-cambiar-clave" class="btn btn--secundario">
                  Actualizar contraseña
                </button>
              </div>
            </form>
          </section>

          <!-- Sección de logros para Sprint 5 -->
          <section id="logros"></section>
        </article>
      </div>
    `;

    conectarEventos();
  }

  function conectarEventos() {
    const formPerfil = document.getElementById('form-perfil');
    const inputNombre = document.getElementById('nombre');
    const inputApellido = document.getElementById('apellido');
    const inputFoto = document.getElementById('foto');
    const btnGuardarPerfil = document.getElementById('btn-guardar-perfil');
    const avatarPreview = document.getElementById('avatar-preview');
    const errorFoto = document.getElementById('error-foto');

    // Previsualización de la foto seleccionada
    inputFoto.addEventListener('change', () => {
      errorFoto.textContent = '';
      const archivo = inputFoto.files[0];
      if (archivo) {
        if (archivo.size > 2 * 1024 * 1024) {
          errorFoto.textContent = 'La imagen excede el límite de 2 MB';
          inputFoto.value = '';
          return;
        }
        const lector = new FileReader();
        lector.onload = (e) => {
          avatarPreview.innerHTML = `<img src="${escapar(e.target.result)}" alt="Previsualización">`;
        };
        lector.readAsDataURL(archivo);
      }
    });

    // Guardar cambios del perfil
    formPerfil.addEventListener('submit', async (e) => {
      e.preventDefault();
      const nombre = inputNombre.value.trim();
      const apellido = inputApellido.value.trim();

      if (!nombre || !apellido) {
        aviso('Por favor completa nombre y apellido.', 'error');
        return;
      }

      btnGuardarPerfil.disabled = true;
      const textoOriginal = btnGuardarPerfil.textContent;
      btnGuardarPerfil.textContent = 'Guardando...';

      try {
        let fotoUrl = usuarioLocal.foto || null;

        // Subir foto si se seleccionó un archivo nuevo
        if (inputFoto.files && inputFoto.files[0]) {
          const resultadoSubida = await subir(inputFoto.files[0]);
          if (resultadoSubida && resultadoSubida.url) {
            fotoUrl = resultadoSubida.url;
          }
        }

        const datosActualizados = await llamar('PUT', '/api/auth/perfil', {
          nombre,
          apellido,
          foto: fotoUrl
        });

        // Actualizar usuario en sessionStorage
        usuarioLocal = {
          ...usuarioLocal,
          nombre: datosActualizados.nombre,
          apellido: datosActualizados.apellido,
          foto: datosActualizados.foto
        };

        if (typeof sessionStorage !== 'undefined') {
          sessionStorage.setItem('usuario', JSON.stringify(usuarioLocal));
        }

        aviso('Perfil actualizado correctamente', 'exito');
        renderizarPerfil();
      } catch (err) {
        aviso(err.message || 'Error al actualizar perfil', 'error');
        btnGuardarPerfil.disabled = false;
        btnGuardarPerfil.textContent = textoOriginal;
      }
    });

    // Cambio de contraseña
    const formClave = document.getElementById('form-clave');
    const inputClaveActual = document.getElementById('clave-actual');
    const inputClaveNueva = document.getElementById('clave-nueva');
    const inputClaveRepetir = document.getElementById('clave-repetir');
    const errorClaveRepetir = document.getElementById('error-clave-repetir');
    const btnCambiarClave = document.getElementById('btn-cambiar-clave');

    formClave.addEventListener('submit', async (e) => {
      e.preventDefault();
      errorClaveRepetir.textContent = '';

      const claveActual = inputClaveActual.value;
      const claveNueva = inputClaveNueva.value;
      const claveRepetir = inputClaveRepetir.value;

      if (!claveActual || !claveNueva || !claveRepetir) {
        aviso('Completa todos los campos de contraseña', 'error');
        return;
      }

      if (claveNueva.length < 6) {
        aviso('La nueva contraseña debe tener al menos 6 caracteres', 'error');
        return;
      }

      if (claveNueva !== claveRepetir) {
        errorClaveRepetir.textContent = 'Las contraseñas no coinciden';
        return;
      }

      btnCambiarClave.disabled = true;
      const textoOriginalClave = btnCambiarClave.textContent;
      btnCambiarClave.textContent = 'Actualizando...';

      try {
        await llamar('POST', '/api/auth/clave', { claveActual, claveNueva });
        aviso('Contraseña actualizada correctamente', 'exito');
        formClave.reset();
      } catch (err) {
        aviso(err.message || 'Error al cambiar contraseña', 'error');
      } finally {
        btnCambiarClave.disabled = false;
        btnCambiarClave.textContent = textoOriginalClave;
      }
    });
  }

  renderizarPerfil();
}
