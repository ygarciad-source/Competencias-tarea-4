/**
 * Módulo editor-cancion.js
 * Editor de canciones educativas asociadas a temas (docente, admin).
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';

let cancionId = null;
let cancion = null;
let temas = [];

async function inicializar() {
  await montarPlantilla({ titulo: 'Editor de Canción', roles: ['docente', 'admin'] });

  cancionId = util.parametro('id');
  if (cancionId) {
    document.getElementById('titulo-pagina-editor').textContent = 'Editar Canción Educativa';
  }

  configurarEventos();
  await cargarTemas();

  if (cancionId) {
    await cargarCancion(cancionId);
  }
}

async function cargarTemas() {
  try {
    const lista = await api.listar('temas');
    temas = lista || [];
    const select = document.getElementById('cancion-tema');
    if (select) {
      select.innerHTML = '<option value="">Selecciona un tema...</option>' +
        temas.map(t => `<option value="${ui.escapar(t.id)}">${ui.escapar(t.titulo)}</option>`).join('');
    }
  } catch (err) {
    ui.aviso('Error al cargar temas: ' + err.message, 'error');
  }
}

async function cargarCancion(id) {
  ui.cargando(true);
  try {
    cancion = await api.obtener('canciones', id);
    document.getElementById('cancion-titulo').value = cancion.titulo || '';
    document.getElementById('cancion-tema').value = cancion.temaId || '';
    document.getElementById('cancion-audio').value = cancion.audio || '';
    document.getElementById('cancion-autoria').value = cancion.autoria || '';
    document.getElementById('cancion-letra').value = cancion.letra || '';
    document.getElementById('cancion-lrc').value = cancion.lrc || '';

    const selLicencia = document.getElementById('cancion-licencia');
    const inputOtra = document.getElementById('cancion-otra-licencia');
    const contOtra = document.getElementById('contenedor-otra-licencia');

    const lic = cancion.licencia || 'Propia';
    if (['Propia', 'CC BY', 'CC BY-SA'].includes(lic)) {
      selLicencia.value = lic;
      contOtra.style.display = 'none';
    } else {
      selLicencia.value = 'Otra';
      inputOtra.value = lic;
      contOtra.style.display = 'block';
    }
  } catch (err) {
    ui.aviso('Error al cargar la canción: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function configurarEventos() {
  // Selector de licencia
  const selLic = document.getElementById('cancion-licencia');
  const contOtra = document.getElementById('contenedor-otra-licencia');
  selLic?.addEventListener('change', () => {
    contOtra.style.display = selLic.value === 'Otra' ? 'block' : 'none';
  });

  // Subida de audio MP3
  const btnSubirAudio = document.getElementById('btn-subir-audio');
  const fileAudio = document.getElementById('archivo-audio');
  const inputAudio = document.getElementById('cancion-audio');

  btnSubirAudio?.addEventListener('click', () => {
    fileAudio?.click();
  });

  fileAudio?.addEventListener('change', async () => {
    const archivo = fileAudio.files?.[0];
    if (!archivo) return;

    ui.cargando(true);
    try {
      const resp = await api.subir(archivo);
      if (resp && resp.url) {
        inputAudio.value = resp.url;
        ui.aviso('Audio MP3 subido exitosamente.', 'exito');
      }
    } catch (err) {
      ui.aviso('Error al subir audio: ' + err.message, 'error');
    } finally {
      ui.cargando(false);
      fileAudio.value = '';
    }
  });

  // Guardar canción
  document.getElementById('btn-guardar-cancion')?.addEventListener('click', () => {
    guardarCancion();
  });
}

async function guardarCancion() {
  const titulo = document.getElementById('cancion-titulo')?.value.trim();
  const temaId = document.getElementById('cancion-tema')?.value;
  const audio = document.getElementById('cancion-audio')?.value.trim();
  const autoria = document.getElementById('cancion-autoria')?.value.trim();
  const selLic = document.getElementById('cancion-licencia')?.value;
  const letra = document.getElementById('cancion-letra')?.value.trim();
  const lrc = document.getElementById('cancion-lrc')?.value.trim();

  let licencia = selLic;
  if (selLic === 'Otra') {
    licencia = document.getElementById('cancion-otra-licencia')?.value.trim();
  }

  if (!titulo || !temaId || !audio || !autoria || !licencia) {
    ui.aviso('Título, tema, audio MP3, autoría y licencia son obligatorios.', 'error');
    return;
  }

  const payload = {
    titulo,
    temaId,
    audio,
    autoria,
    licencia,
    letra: letra || '',
    lrc: lrc || ''
  };

  ui.cargando(true);
  try {
    if (cancionId) {
      await api.actualizar('canciones', cancionId, payload);
      ui.aviso('Canción actualizada exitosamente.', 'exito');
    } else {
      await api.crear('canciones', payload);
      ui.aviso('Canción creada exitosamente.', 'exito');
    }

    setTimeout(() => {
      window.location.href = '/paginas/canciones.html';
    }, 1200);
  } catch (err) {
    ui.aviso('Error al guardar canción: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

inicializar();
