/**
 * Módulo prueba-datos.js - Controlador de la vista de prueba de datos
 * Demuestra la integración de api.crear, api.listar y ui.aviso.
 */

import { montarPlantilla } from '/js/nucleo/plantilla.js';
import api from '/js/nucleo/api.js';
import ui from '/js/nucleo/ui.js';
import util from '/js/nucleo/util.js';

await montarPlantilla({ titulo: 'Prueba de datos', roles: ['publico'] });

const contenido = document.getElementById('contenido');
contenido.innerHTML = `
  <div class="pila" style="gap: var(--espacio-xl);">
    <section class="tarjeta seccion-formulario">
      <div class="tarjeta__cabecera">
        <h3>Guardar nuevo registro en "prueba"</h3>
        <span class="insignia insignia--acento">POST /api/prueba</span>
      </div>
      <form id="form-prueba">
        <div class="tarjeta__cuerpo">
          <div class="campo">
            <label for="campo-texto">Texto del registro</label>
            <input type="text" id="campo-texto" name="texto" placeholder="Escribe un mensaje o dato de prueba..." required autocomplete="off">
            <small>El valor se guardará como un registro en la colección "prueba" mediante <code>api.crear</code>.</small>
          </div>
        </div>
        <div class="tarjeta__pie">
          <button type="submit" id="btn-guardar" class="btn btn--primario">
            Guardar en colección
          </button>
        </div>
      </form>
    </section>

    <section class="pila" style="gap: var(--espacio-m);">
      <div class="cabecera-registros">
        <h2>Registros Almacenados (Colección: prueba)</h2>
        <button id="btn-refrescar" class="btn btn--secundario btn--pequeno" type="button">
          ↻ Actualizar lista
        </button>
      </div>
      <div id="contenedor-registros">
        <div class="cargando">
          <span class="cargando-spinner" aria-hidden="true"></span>
          <span>Cargando registros...</span>
        </div>
      </div>
    </section>
  </div>
`;

const formPrueba = document.getElementById('form-prueba');
const campoTexto = document.getElementById('campo-texto');
const btnGuardar = document.getElementById('btn-guardar');
const btnRefrescar = document.getElementById('btn-refrescar');
const contenedorRegistros = document.getElementById('contenedor-registros');

/**
 * Consulta la lista de registros en /api/prueba y los renderiza en pantalla.
 */
async function cargarRegistros() {
  try {
    const lista = await api.listar('prueba');

    if (!Array.isArray(lista) || lista.length === 0) {
      contenedorRegistros.innerHTML = `
        <div class="vacio">
          <div class="vacio__icono" aria-hidden="true">📭</div>
          <h3 class="vacio__titulo">No hay registros aún</h3>
          <p class="vacio__descripcion">
            Escribe un texto en el formulario superior para almacenar el primer registro en la colección "prueba".
          </p>
        </div>
      `;
      return;
    }

    // Renderizar tabla con los registros obtenidos
    const filasHTML = lista.slice().reverse().map(item => {
      const fechaTexto = item.fecha
        ? `${util.fechaRelativa(item.fecha)} (${util.fechaLarga(item.fecha)})`
        : 'Sin fecha';

      return `
        <tr>
          <td><code>${ui.escapar(item.id || '—')}</code></td>
          <td><strong>${ui.escapar(item.texto || '')}</strong></td>
          <td><small>${ui.escapar(fechaTexto)}</small></td>
        </tr>
      `;
    }).join('');

    contenedorRegistros.innerHTML = `
      <div class="tabla">
        <table>
          <thead>
            <tr>
              <th scope="col" style="width: 140px;">Identificador</th>
              <th scope="col">Texto</th>
              <th scope="col" style="width: 280px;">Fecha de Registro</th>
            </tr>
          </thead>
          <tbody>
            ${filasHTML}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    contenedorRegistros.innerHTML = `
      <div class="alerta alerta--error" role="alert">
        <strong>Error al cargar los registros</strong>
        ${ui.escapar(err.message || 'No fue posible obtener los datos.')}
      </div>
    `;
    ui.aviso(`Error al cargar datos: ${err.message}`, 'error');
  }
}

// Evento de envío del formulario
formPrueba.addEventListener('submit', async event => {
  event.preventDefault();
  const texto = campoTexto.value.trim();

  if (!texto) {
    ui.aviso('El campo de texto no puede estar vacío.', 'advertencia');
    campoTexto.focus();
    return;
  }

  btnGuardar.disabled = true;

  try {
    const nuevo = await api.crear('prueba', { texto });
    ui.aviso(`Registro ${nuevo.id} guardado con éxito.`, 'exito');
    campoTexto.value = '';
    await cargarRegistros();
  } catch (err) {
    ui.aviso(`Error al guardar: ${err.message}`, 'error');
  } finally {
    btnGuardar.disabled = false;
  }
});

btnRefrescar.addEventListener('click', async () => {
  await cargarRegistros();
  ui.aviso('Lista de registros actualizada.', 'info');
});

// Carga inicial
await cargarRegistros();
