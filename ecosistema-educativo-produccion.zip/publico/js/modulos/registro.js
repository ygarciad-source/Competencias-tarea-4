/**
 * Módulo registro.js - Controlador de la página de registro
 * Validación en vivo con .campo__error, casilla de privacidad obligatoria,
 * inicio de sesión automático y redirección a /index.html.
 */

import { montarPlantilla } from '/js/nucleo/plantilla.js';
import { registrar, usuarioActual } from '/js/nucleo/sesion.js';
import { aviso, escapar } from '/js/nucleo/ui.js';

await montarPlantilla({ titulo: 'Registro de Cuenta', roles: ['publico'] });

const usuarioSesion = usuarioActual();

const contenido = document.getElementById('contenido');
if (contenido) {
  const alertaUsuarioActivo = usuarioSesion ? `
    <div class="alerta alerta--info" style="margin-bottom: var(--espacio-m);">
      Ya has iniciado sesión como <strong>${escapar(usuarioSesion.nombre)}</strong> (${escapar(usuarioSesion.correo)}).
      Puedes registrar una nueva cuenta o <a href="/index.html" class="btn btn--texto" style="padding: 0;">volver al inicio →</a>
    </div>
  ` : '';

  contenido.innerHTML = `
    <div class="auth-contenedor">
      ${alertaUsuarioActivo}
      <article class="auth-tarjeta">
        <header class="auth-cabecera">
          <span class="insignia insignia--acento" style="align-self: center;">Nueva Cuenta</span>
          <h1>Registrarse</h1>
          <p style="color: var(--color-texto-claro); font-size: var(--tamano-s);">
            Crea tu perfil para acceder a los módulos de aprendizaje
          </p>
        </header>

        <form id="formulario-registro" class="auth-formulario" novalidate>
          <div class="auth-fila-dos">
            <div class="campo" id="contenedor-nombre">
              <label for="nombre">Nombre</label>
              <input
                type="text"
                id="nombre"
                name="nombre"
                autocomplete="given-name"
                placeholder="Ej: Ana"
                required
                aria-describedby="error-nombre"
              >
              <span class="campo__error" id="error-nombre" aria-live="polite"></span>
            </div>

            <div class="campo" id="contenedor-apellido">
              <label for="apellido">Apellido</label>
              <input
                type="text"
                id="apellido"
                name="apellido"
                autocomplete="family-name"
                placeholder="Ej: García"
                required
                aria-describedby="error-apellido"
              >
              <span class="campo__error" id="error-apellido" aria-live="polite"></span>
            </div>
          </div>

          <div class="campo" id="contenedor-correo">
            <label for="correo">Correo electrónico</label>
            <input
              type="email"
              id="correo"
              name="correo"
              autocomplete="email"
              placeholder="ana.garcia@ejemplo.com"
              required
              aria-describedby="error-correo"
            >
            <span class="campo__error" id="error-correo" aria-live="polite"></span>
          </div>

          <div class="campo" id="contenedor-rol">
            <label for="rol">Rol institucional</label>
            <select id="rol" name="rol">
              <option value="estudiante" selected>Estudiante</option>
              <option value="docente">Docente</option>
            </select>
          </div>

          <div class="auth-fila-dos">
            <div class="campo" id="contenedor-clave">
              <label for="clave">Contraseña</label>
              <input
                type="password"
                id="clave"
                name="clave"
                autocomplete="new-password"
                placeholder="Mínimo 6 caracteres"
                required
                aria-describedby="error-clave"
              >
              <span class="campo__error" id="error-clave" aria-live="polite"></span>
            </div>

            <div class="campo" id="contenedor-confirmar-clave">
              <label for="confirmar-clave">Confirmar contraseña</label>
              <input
                type="password"
                id="confirmar-clave"
                name="confirmarClave"
                autocomplete="new-password"
                placeholder="Repite tu contraseña"
                required
                aria-describedby="error-confirmar-clave"
              >
              <span class="campo__error" id="error-confirmar-clave" aria-live="polite"></span>
            </div>
          </div>

          <div class="campo" id="contenedor-consentimiento">
            <div class="auth-casilla">
              <input
                type="checkbox"
                id="consentimiento"
                name="consentimiento"
                required
                aria-describedby="error-consentimiento"
              >
              <label for="consentimiento">
                Acepto el <a href="/paginas/privacidad.html" target="_blank" style="color: var(--color-info); text-decoration: underline;">aviso de privacidad</a>
              </label>
            </div>
            <span class="campo__error" id="error-consentimiento" aria-live="polite"></span>
          </div>

          <button type="submit" id="btn-registro" class="btn btn--primario" style="margin-top: var(--espacio-s);">
            Crear cuenta
          </button>
        </form>

        <footer class="auth-pie">
          <p>
            ¿Ya tienes una cuenta registrada?
            <a href="/paginas/ingreso.html" class="btn btn--texto" style="font-weight: var(--peso-seminegrita);">
              Inicia sesión aquí →
            </a>
          </p>
        </footer>
      </article>
    </div>
  `;

  const form = document.getElementById('formulario-registro');
  const btnSubmit = document.getElementById('btn-registro');

  const inputNombre = document.getElementById('nombre');
  const inputApellido = document.getElementById('apellido');
  const inputCorreo = document.getElementById('correo');
  const selectRol = document.getElementById('rol');
  const inputClave = document.getElementById('clave');
  const inputConfirmar = document.getElementById('confirmar-clave');
  const checkConsentimiento = document.getElementById('consentimiento');

  const contNombre = document.getElementById('contenedor-nombre');
  const contApellido = document.getElementById('contenedor-apellido');
  const contCorreo = document.getElementById('contenedor-correo');
  const contClave = document.getElementById('contenedor-clave');
  const contConfirmar = document.getElementById('contenedor-confirmar-clave');
  const contConsentimiento = document.getElementById('contenedor-consentimiento');

  const errorNombre = document.getElementById('error-nombre');
  const errorApellido = document.getElementById('error-apellido');
  const errorCorreo = document.getElementById('error-correo');
  const errorClave = document.getElementById('error-clave');
  const errorConfirmar = document.getElementById('error-confirmar-clave');
  const errorConsentimiento = document.getElementById('error-consentimiento');

  const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function validarNombre() {
    const val = inputNombre.value.trim();
    if (!val) {
      contNombre.classList.add('campo--error');
      errorNombre.textContent = 'El nombre es obligatorio';
      inputNombre.setAttribute('aria-invalid', 'true');
      return false;
    }
    if (val.length < 2) {
      contNombre.classList.add('campo--error');
      errorNombre.textContent = 'El nombre debe tener al menos 2 caracteres';
      inputNombre.setAttribute('aria-invalid', 'true');
      return false;
    }
    contNombre.classList.remove('campo--error');
    errorNombre.textContent = '';
    inputNombre.setAttribute('aria-invalid', 'false');
    return true;
  }

  function validarApellido() {
    const val = inputApellido.value.trim();
    if (!val) {
      contApellido.classList.add('campo--error');
      errorApellido.textContent = 'El apellido es obligatorio';
      inputApellido.setAttribute('aria-invalid', 'true');
      return false;
    }
    if (val.length < 2) {
      contApellido.classList.add('campo--error');
      errorApellido.textContent = 'El apellido debe tener al menos 2 caracteres';
      inputApellido.setAttribute('aria-invalid', 'true');
      return false;
    }
    contApellido.classList.remove('campo--error');
    errorApellido.textContent = '';
    inputApellido.setAttribute('aria-invalid', 'false');
    return true;
  }

  function validarCorreo() {
    const val = inputCorreo.value.trim();
    if (!val) {
      contCorreo.classList.add('campo--error');
      errorCorreo.textContent = 'El correo electrónico es obligatorio';
      inputCorreo.setAttribute('aria-invalid', 'true');
      return false;
    }
    if (!regexCorreo.test(val)) {
      contCorreo.classList.add('campo--error');
      errorCorreo.textContent = 'Ingresa un formato de correo válido (ej: usuario@dominio.com)';
      inputCorreo.setAttribute('aria-invalid', 'true');
      return false;
    }
    contCorreo.classList.remove('campo--error');
    errorCorreo.textContent = '';
    inputCorreo.setAttribute('aria-invalid', 'false');
    return true;
  }

  function validarClave() {
    const val = inputClave.value;
    if (!val) {
      contClave.classList.add('campo--error');
      errorClave.textContent = 'La contraseña es obligatoria';
      inputClave.setAttribute('aria-invalid', 'true');
      return false;
    }
    if (val.length < 6) {
      contClave.classList.add('campo--error');
      errorClave.textContent = 'La contraseña debe tener al menos 6 caracteres';
      inputClave.setAttribute('aria-invalid', 'true');
      return false;
    }
    contClave.classList.remove('campo--error');
    errorClave.textContent = '';
    inputClave.setAttribute('aria-invalid', 'false');

    // Re-validar confirmación si ya fue escrita
    if (inputConfirmar.value) {
      validarConfirmar();
    }
    return true;
  }

  function validarConfirmar() {
    const val = inputConfirmar.value;
    if (!val) {
      contConfirmar.classList.add('campo--error');
      errorConfirmar.textContent = 'Confirma tu contraseña';
      inputConfirmar.setAttribute('aria-invalid', 'true');
      return false;
    }
    if (val !== inputClave.value) {
      contConfirmar.classList.add('campo--error');
      errorConfirmar.textContent = 'Las contraseñas no coinciden';
      inputConfirmar.setAttribute('aria-invalid', 'true');
      return false;
    }
    contConfirmar.classList.remove('campo--error');
    errorConfirmar.textContent = '';
    inputConfirmar.setAttribute('aria-invalid', 'false');
    return true;
  }

  function validarConsentimiento() {
    if (!checkConsentimiento.checked) {
      contConsentimiento.classList.add('campo--error');
      errorConsentimiento.textContent = 'Debes aceptar el aviso de privacidad para registrarte';
      checkConsentimiento.setAttribute('aria-invalid', 'true');
      return false;
    }
    contConsentimiento.classList.remove('campo--error');
    errorConsentimiento.textContent = '';
    checkConsentimiento.setAttribute('aria-invalid', 'false');
    return true;
  }

  // Validación en vivo
  inputNombre.addEventListener('input', validarNombre);
  inputNombre.addEventListener('blur', validarNombre);

  inputApellido.addEventListener('input', validarApellido);
  inputApellido.addEventListener('blur', validarApellido);

  inputCorreo.addEventListener('input', validarCorreo);
  inputCorreo.addEventListener('blur', validarCorreo);

  inputClave.addEventListener('input', validarClave);
  inputClave.addEventListener('blur', validarClave);

  inputConfirmar.addEventListener('input', validarConfirmar);
  inputConfirmar.addEventListener('blur', validarConfirmar);

  checkConsentimiento.addEventListener('change', validarConsentimiento);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const okNombre = validarNombre();
    const okApellido = validarApellido();
    const okCorreo = validarCorreo();
    const okClave = validarClave();
    const okConfirmar = validarConfirmar();
    const okConsentimiento = validarConsentimiento();

    if (!okNombre || !okApellido || !okCorreo || !okClave || !okConfirmar || !okConsentimiento) {
      if (!okNombre) inputNombre.focus();
      else if (!okApellido) inputApellido.focus();
      else if (!okCorreo) inputCorreo.focus();
      else if (!okClave) inputClave.focus();
      else if (!okConfirmar) inputConfirmar.focus();
      else if (!okConsentimiento) checkConsentimiento.focus();
      return;
    }

    // Botón deshabilitado mientras envía
    btnSubmit.disabled = true;
    const textoOriginal = btnSubmit.textContent;
    btnSubmit.textContent = 'Creando cuenta...';

    const datosRegistro = {
      nombre: inputNombre.value.trim(),
      apellido: inputApellido.value.trim(),
      correo: inputCorreo.value.trim(),
      rol: selectRol.value || 'estudiante',
      clave: inputClave.value,
      consentimiento: {
        aceptado: true,
        fecha: new Date().toISOString()
      }
    };

    try {
      // Inicia sesión automáticamente al terminar según contrato y especificación
      await registrar(datosRegistro);
      aviso('¡Cuenta creada con éxito! Bienvenido al Ecosistema Educativo.', 'exito');
      // Tras ingresar → /index.html
      setTimeout(() => {
        window.location.href = '/index.html';
      }, 300);
    } catch (err) {
      aviso(err.message || 'Error al procesar el registro', 'error');
      btnSubmit.disabled = false;
      btnSubmit.textContent = textoOriginal;
    }
  });
}
