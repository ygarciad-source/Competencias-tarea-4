/**
 * Módulo noticias.js
 * Listado de noticias paginadas de 9 en 9 con filtros y estado de lectura.
 */

import { montarPlantilla } from '../nucleo/plantilla.js';
import * as api from '../nucleo/api.js';
import * as ui from '../nucleo/ui.js';
import * as util from '../nucleo/util.js';
import { usuarioActual } from '../nucleo/sesion.js';

const NOTICIAS_POR_PAGINA = 9;

let todasNoticias = [];
let lecturasIds = new Set();
let mapaTemas = new Map();
let paginaActual = 1;
let usuario = null;

async function inicializar() {
  await montarPlantilla({ titulo: 'Noticias', roles: ['sesion'] });

  usuario = usuarioActual();
  const puedeEditar = usuario && (usuario.rol === 'docente' || usuario.rol === 'admin');

  const btnCrear = document.getElementById('contenedor-accion-crear');
  if (btnCrear && puedeEditar) {
    btnCrear.style.display = 'block';
  }

  configurarFiltros();
  configurarPaginacion();

  await cargarDatos();
}

async function cargarDatos() {
  ui.cargando(true);
  try {
    const [listaNoticias, listaLecturas, listaTemas] = await Promise.all([
      api.listar('noticias'),
      api.listar('lecturas-noticias'),
      api.listar('temas')
    ]);

    todasNoticias = listaNoticias || [];
    lecturasIds = new Set((listaLecturas || []).map(l => l.noticiaId));
    mapaTemas = new Map((listaTemas || []).map(t => [t.id, t.titulo]));

    poblarSelectorTemas(listaTemas || []);
    paginaActual = 1;
    renderizarListado();
  } catch (err) {
    ui.aviso('Error al cargar noticias: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }
}

function poblarSelectorTemas(temas) {
  const select = document.getElementById('filtro-tema');
  if (!select) return;
  select.innerHTML = '<option value="">Todos los temas</option>' +
    temas.map(t => `<option value="${ui.escapar(t.id)}">${ui.escapar(t.titulo)}</option>`).join('');
}

function configurarFiltros() {
  document.getElementById('filtro-categoria')?.addEventListener('change', () => {
    paginaActual = 1;
    renderizarListado();
  });

  document.getElementById('filtro-tema')?.addEventListener('change', () => {
    paginaActual = 1;
    renderizarListado();
  });
}

function configurarPaginacion() {
  document.getElementById('btn-pagina-anterior')?.addEventListener('click', () => {
    if (paginaActual > 1) {
      paginaActual--;
      renderizarListado();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });

  document.getElementById('btn-pagina-siguiente')?.addEventListener('click', () => {
    const filtradas = obtenerNoticiasFiltradas();
    const totalPaginas = Math.ceil(filtradas.length / NOTICIAS_POR_PAGINA) || 1;
    if (paginaActual < totalPaginas) {
      paginaActual++;
      renderizarListado();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });
}

function obtenerNoticiasFiltradas() {
  const cat = document.getElementById('filtro-categoria')?.value;
  const tema = document.getElementById('filtro-tema')?.value;

  let resultado = todasNoticias.filter(n => {
    if (cat && n.categoria !== cat) return false;
    if (tema && n.temaId !== tema) return false;
    return true;
  });

  // Ordenar: Destacadas primero, luego por fecha más reciente
  resultado.sort((a, b) => {
    const destA = a.destacada ? 1 : 0;
    const destB = b.destacada ? 1 : 0;
    if (destA !== destB) return destB - destA;

    const fechaA = new Date(a.fechaPublicacion || a.fecha || 0).getTime();
    const fechaB = new Date(b.fechaPublicacion || b.fecha || 0).getTime();
    return fechaB - fechaA;
  });

  return resultado;
}

function renderizarListado() {
  const contenedor = document.getElementById('cuadricula-noticias');
  const navPaginacion = document.getElementById('navegacion-paginacion');
  const infoPaginacion = document.getElementById('info-paginacion');
  const btnAnt = document.getElementById('btn-pagina-anterior');
  const btnSig = document.getElementById('btn-pagina-siguiente');

  if (!contenedor) return;

  const filtradas = obtenerNoticiasFiltradas();
  const totalNoticias = filtradas.length;
  const totalPaginas = Math.ceil(totalNoticias / NOTICIAS_POR_PAGINA) || 1;

  if (paginaActual > totalPaginas) paginaActual = totalPaginas;

  if (totalNoticias === 0) {
    contenedor.innerHTML = `
      <div class="tarjeta" style="grid-column: 1 / -1; text-align: center; padding: var(--espacio-xxl);">
        <p style="color: var(--color-texto-secundario); margin: 0;">
          No hay noticias disponibles que coincidan con los filtros seleccionados.
        </p>
      </div>
    `;
    if (navPaginacion) navPaginacion.style.display = 'none';
    return;
  }

  // Paginación
  const inicio = (paginaActual - 1) * NOTICIAS_POR_PAGINA;
  const fin = inicio + NOTICIAS_POR_PAGINA;
  const paginaItems = filtradas.slice(inicio, fin);

  const puedeEditar = usuario && (usuario.rol === 'docente' || usuario.rol === 'admin');

  contenedor.innerHTML = paginaItems.map(item => {
    const yaLeida = lecturasIds.has(item.id);
    const esBorrador = item.estado === 'borrador';
    const nombreTema = item.temaId ? (mapaTemas.get(item.temaId) || 'Tema') : null;
    const fechaTexto = util.fechaRelativa(item.fechaPublicacion || item.fecha);

    return `
      <article class="tarjeta tarjeta-noticia ${item.destacada ? 'tarjeta-noticia--destacada' : ''}" data-id="${ui.escapar(item.id)}">
        ${item.imagen ? `
          <div class="tarjeta-noticia__imagen-caja">
            <img src="${ui.escapar(item.imagen)}" alt="${ui.escapar(item.titulo)}" class="tarjeta-noticia__imagen" loading="lazy" />
          </div>
        ` : ''}

        <div class="tarjeta-noticia__cuerpo">
          <div class="tarjeta-noticia__insignias">
            <span class="insignia insignia--primario">${ui.escapar(item.categoria || 'Institucional')}</span>
            ${item.destacada ? `<span class="insignia">⭐ Destacada</span>` : ''}
            ${!yaLeida ? `<span class="insignia insignia--acento">Nuevo</span>` : ''}
            ${esBorrador ? `<span class="insignia insignia--advertencia">Borrador</span>` : ''}
            ${nombreTema ? `<span class="insignia" style="font-size: 10px;">${ui.escapar(nombreTema)}</span>` : ''}
          </div>

          <h2 class="tarjeta-noticia__titulo">
            <a href="/paginas/noticia.html?id=${encodeURIComponent(item.id)}">
              ${ui.escapar(item.titulo)}
            </a>
          </h2>

          <p class="tarjeta-noticia__resumen">
            ${ui.escapar(item.resumen || '')}
          </p>
        </div>

        <footer class="tarjeta-noticia__pie">
          <span>${ui.escapar(fechaTexto)}</span>
          <div style="display: flex; align-items: center; gap: var(--espacio-xs);">
            ${puedeEditar ? `
              <a href="/paginas/editor-noticia.html?id=${encodeURIComponent(item.id)}" class="btn btn--secundario btn--pequeno" style="text-decoration: none;">
                Editar
              </a>
            ` : ''}
            <a href="/paginas/noticia.html?id=${encodeURIComponent(item.id)}" class="btn btn--texto btn--pequeno" style="text-decoration: none;">
              Leer más →
            </a>
          </div>
        </footer>
      </article>
    `;
  }).join('');

  // Actualizar controles de paginación
  if (navPaginacion) {
    navPaginacion.style.display = totalPaginas > 1 ? 'flex' : 'none';
    if (infoPaginacion) infoPaginacion.textContent = `Página ${paginaActual} de ${totalPaginas} (${totalNoticias} noticias)`;
    if (btnAnt) btnAnt.disabled = paginaActual <= 1;
    if (btnSig) btnSig.disabled = paginaActual >= totalPaginas;
  }
}

inicializar();
