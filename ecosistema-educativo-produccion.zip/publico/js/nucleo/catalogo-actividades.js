/**
 * Módulo catalogo-actividades.js - Catálogo de actividades lúdicas e interactivas
 * Cada actividad tiene: { id, texto, descripcion, href } (href sin parámetros)
 */

export const ACTIVIDADES = [
  {
    id: 'canciones',
    texto: 'Canciones del tema',
    descripcion: 'Aprende con música',
    href: '/paginas/canciones.html'
  },
  {
    id: 'quiz',
    texto: 'Quiz por niveles',
    descripcion: 'Supera 5 niveles y gana diplomas',
    href: '/paginas/quiz.html'
  }
];


export default ACTIVIDADES;
