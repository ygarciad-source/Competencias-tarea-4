/**
 * Módulo api.js - Cliente API del navegador
 * Conecta con el servidor Express bajo las rutas /api/...
 */

/**
 * Obtiene el token de autenticación actual desde sessionStorage.
 * @returns {string|null}
 */
function obtenerToken() {
  try {
    if (typeof sessionStorage !== 'undefined') {
      return sessionStorage.getItem('token');
    }
  } catch {
    // Si sessionStorage no está accesible por permisos del navegador
  }
  return null;
}

/**
 * Limpia las credenciales almacenadas y redirige a la página de ingreso,
 * excepto si ya se encuentra en ingreso.html o registro.html.
 */
function limpiarSesionYRedirigir() {
  try {
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('usuario');
    }
  } catch {
    // Ignorar si sessionStorage no está disponible
  }

  if (typeof window !== 'undefined' && window.location) {
    const ruta = window.location.pathname || '';
    const enIngresoORegistro = ruta.endsWith('ingreso.html') || ruta.endsWith('registro.html');
    if (!enIngresoORegistro) {
      window.location.href = '/paginas/ingreso.html';
    }
  }
}

/**
 * Procesa la respuesta de la petición HTTP, gestionando errores y códigos 401.
 * @param {Response} res
 * @returns {Promise<any>}
 */
async function procesarRespuesta(res) {
  let datos = null;
  const contentType = res.headers ? (res.headers.get('content-type') || '') : '';

  if (contentType.includes('application/json')) {
    try {
      datos = await res.json();
    } catch {
      datos = null;
    }
  } else {
    try {
      const texto = await res.text();
      try {
        datos = JSON.parse(texto);
      } catch {
        datos = texto ? { error: texto } : null;
      }
    } catch {
      datos = null;
    }
  }

  if (res.status === 401) {
    limpiarSesionYRedirigir();
    const mensaje = (datos && datos.error) ? datos.error : 'Sesión no autorizada o expirada (401)';
    throw new Error(mensaje);
  }

  if (datos && typeof datos === 'object' && datos.error) {
    throw new Error(datos.error);
  }

  if (!res.ok) {
    const mensaje = (datos && datos.error) || `Error ${res.status}: ${res.statusText || 'Solicitud fallida'}`;
    throw new Error(mensaje);
  }

  return datos;
}

/**
 * Realiza una llamada HTTP a cualquier ruta /api/...
 * @param {string} metodo - 'GET', 'POST', 'PUT', 'DELETE', etc.
 * @param {string} ruta - Ruta absoluta o relativa al dominio (ej: '/api/usuarios')
 * @param {any} [cuerpo] - Objeto o dato a serializar en JSON
 * @returns {Promise<any>}
 */
export async function llamar(metodo, ruta, cuerpo) {
  const met = String(metodo).toUpperCase();
  const url = ruta.startsWith('/') ? ruta : `/${ruta}`;

  const headers = {};
  const token = obtenerToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const opciones = {
    method: met,
    headers
  };

  if (cuerpo !== undefined && cuerpo !== null && met !== 'GET' && met !== 'HEAD') {
    headers['Content-Type'] = 'application/json';
    opciones.body = typeof cuerpo === 'string' ? cuerpo : JSON.stringify(cuerpo);
  }

  const res = await fetch(url, opciones);
  return procesarRespuesta(res);
}

/**
 * Lista registros de una colección con filtros opcionales.
 * GET /api/:col?campo=valor
 * @param {string} col - Nombre de la colección
 * @param {Record<string, any>} [filtros={}] - Filtros por clave y valor
 * @returns {Promise<Array<any>>}
 */
export async function listar(col, filtros = {}) {
  const params = new URLSearchParams();
  if (filtros && typeof filtros === 'object') {
    for (const [clave, valor] of Object.entries(filtros)) {
      if (valor !== undefined && valor !== null) {
        params.append(clave, valor);
      }
    }
  }
  const qs = params.toString();
  const ruta = `/api/${col}${qs ? `?${qs}` : ''}`;
  return llamar('GET', ruta);
}

/**
 * Obtiene un registro por su identificador.
 * GET /api/:col/:id
 * @param {string} col
 * @param {string} id
 * @returns {Promise<any>}
 */
export async function obtener(col, id) {
  return llamar('GET', `/api/${col}/${encodeURIComponent(id)}`);
}

/**
 * Crea un nuevo registro en una colección.
 * POST /api/:col
 * @param {string} col
 * @param {Record<string, any>} datos
 * @returns {Promise<any>}
 */
export async function crear(col, datos) {
  return llamar('POST', `/api/${col}`, datos);
}

/**
 * Actualiza un registro existente fusionando los cambios.
 * PUT /api/:col/:id
 * @param {string} col
 * @param {string} id
 * @param {Record<string, any>} cambios
 * @returns {Promise<any>}
 */
export async function actualizar(col, id, cambios) {
  return llamar('PUT', `/api/${col}/${encodeURIComponent(id)}`, cambios);
}

/**
 * Elimina un registro por su id.
 * DELETE /api/:col/:id
 * @param {string} col
 * @param {string} id
 * @returns {Promise<any>}
 */
export async function eliminar(col, id) {
  return llamar('DELETE', `/api/${col}/${encodeURIComponent(id)}`);
}

/**
 * Sube un archivo mediante FormData en el campo "archivo".
 * POST /api/subidas -> { url }
 * @param {File|Blob} archivo
 * @returns {Promise<{ url: string }>}
 */
export async function subir(archivo) {
  const formData = new FormData();
  formData.append('archivo', archivo);

  const headers = {};
  const token = obtenerToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch('/api/subidas', {
    method: 'POST',
    headers,
    body: formData
  });

  return procesarRespuesta(res);
}

/**
 * Ejecuta una tarea de Inteligencia Artificial.
 * POST /api/ia/:tarea
 * @param {string} tarea
 * @param {any} datos
 * @returns {Promise<any>}
 */
export async function ia(tarea, datos) {
  return llamar('POST', `/api/ia/${encodeURIComponent(tarea)}`, datos);
}

export default {
  listar,
  obtener,
  crear,
  actualizar,
  eliminar,
  llamar,
  subir,
  ia
};
