/**
 * Módulo plantilla.js - Montaje común de layout institucional
 * Genera encabezado, menú lateral filtrado por rol y pie de página con control responsive.
 */

import { MENU } from './menu.js';
import { usuarioActual, exigirRol, cerrar } from './sesion.js';
import { registrarEvento } from './bitacora.js';
import { aviso, escapar } from './ui.js';
import * as api from './api.js';

export const NOMBRE = 'Ecosistema Educativo';


/**
 * Monta la plantilla común en la página.
 * Inserta encabezado y menú lateral en #plantilla, añade el pie al final de body,
 * marca el enlace activo y actualiza el document.title.
 * @param {object} opciones
 * @param {string} opciones.titulo - Título de la vista actual
 * @param {string|string[]} [opciones.roles] - Roles requeridos para acceder a la página
 */
export async function montarPlantilla({ titulo = '', roles } = {}) {
  // 1. Título del documento
  if (typeof document !== 'undefined') {
    document.title = titulo ? `${titulo} · ${NOMBRE}` : NOMBRE;
  }

  // 2. Control de acceso: llama a exigirRol(roles) si se indican
  if (roles !== undefined && roles !== null) {
    const permitido = exigirRol(roles);
    if (!permitido) return;
  }

  // Mostrar avisos pendientes de redirección (por ejemplo, rol no permitido)
  try {
    if (typeof sessionStorage !== 'undefined') {
      const avisoPendiente = sessionStorage.getItem('aviso_pendiente');
      if (avisoPendiente) {
        sessionStorage.removeItem('aviso_pendiente');
        try {
          const obj = JSON.parse(avisoPendiente);
          aviso(obj.texto, obj.tipo || 'info');
        } catch {
          aviso(avisoPendiente, 'info');
        }
      }
    }
  } catch {
    // Silencioso
  }

  const usuario = usuarioActual();

  // 3. Auditoría: con sesión llama a registrarEvento("pagina", location.pathname) sin esperar
  if (usuario && typeof window !== 'undefined' && window.location) {
    registrarEvento('pagina', window.location.pathname);
  }

  if (typeof document === 'undefined') return;

  // 4. Filtrar MENU por rol ("publico" = todos, "sesion" = con sesión)
  const enlacesVisibles = MENU.filter(item => {
    if (!item.roles || item.roles.includes('publico')) return true;
    if (!usuario) return false;
    if (item.roles.includes('sesion')) return true;
    if (usuario.rol === 'admin') return true;
    return item.roles.includes(usuario.rol);
  });

  // Ruta actual para aria-current="page"
  const rutaActual = typeof window !== 'undefined' ? window.location.pathname : '';

  // 5. Inserción en #plantilla
  const contenedorPlantilla = document.getElementById('plantilla');
  if (contenedorPlantilla) {
    const enlacesHTML = enlacesVisibles.map(item => {
      const esActual = rutaActual === item.href ||
        (item.href === '/index.html' && (rutaActual === '/' || rutaActual === ''));

      const claseActivo = esActual ? 'menu__enlace--activo' : '';
      const attrCurrent = esActual ? 'aria-current="page"' : '';

      const badgeNoticias = (item.href === '/paginas/noticias.html' && usuario)
        ? `<span id="badge-noticias-no-leidas" class="insignia insignia--acento" style="font-size: var(--tamano-xs); margin-left: auto; display: none;"></span>`
        : '';

      return `
        <a href="${item.href}" class="menu__enlace ${claseActivo}" ${attrCurrent} style="display: flex; align-items: center; justify-content: space-between;">
          <span>${escapar(item.texto)}</span>
          ${badgeNoticias}
        </a>
      `;
    }).join('');


    // Encabezado con estado de autenticación
    let accionesHTML = '';
    if (usuario) {
      const nombreCompleto = `${usuario.nombre || ''} ${usuario.apellido || ''}`.trim() || 'Usuario';
      accionesHTML = `
        <a href="/paginas/perfil.html" class="encabezado__perfil" style="display: flex; align-items: center; gap: var(--espacio-xs); color: var(--color-texto-inverso); text-decoration: none; font-size: var(--tamano-s);" title="Ver mi perfil">
          <span style="font-weight: var(--peso-seminegrita);">${escapar(nombreCompleto)}</span>
          <span class="insignia insignia--acento" style="font-size: var(--tamano-xs); text-transform: capitalize;">${escapar(usuario.rol || 'estudiante')}</span>
        </a>
        <button id="btn-cerrar-sesion" class="btn btn--pequeno btn--secundario" type="button" aria-label="Cerrar sesión">
          Salir
        </button>
      `;
    } else {
      accionesHTML = `
        <a href="/paginas/ingreso.html" class="btn btn--pequeno btn--secundario">
          Ingresar
        </a>
        <a href="/paginas/registro.html" class="btn btn--pequeno btn--acento">
          Registrarse
        </a>
      `;
    }

    contenedorPlantilla.innerHTML = `
      <header class="encabezado" role="banner">
        <div class="encabezado__contenedor">
          <div style="display: flex; align-items: center; gap: var(--espacio-m);">
            <button id="btn-toggle-menu" class="encabezado__toggle" type="button" aria-label="Abrir menú de navegación" aria-controls="menu-lateral" aria-expanded="false">
              ☰
            </button>
            <a href="/index.html" class="encabezado__marca">
              <span>${NOMBRE}</span>
            </a>
            ${titulo ? `
              <span class="encabezado__titulo-pagina" style="color: var(--color-texto-inverso); font-size: var(--tamano-s); opacity: 0.9; margin-left: var(--espacio-s);">
                · ${escapar(titulo)}
              </span>
            ` : ''}
          </div>
          <div class="encabezado__acciones" style="display: flex; align-items: center; gap: var(--espacio-s); margin-left: auto;">
            ${accionesHTML}
          </div>
        </div>
      </header>

      <div id="menu-cortina" class="menu-cortina" aria-hidden="true"></div>

      <aside id="menu-lateral" class="menu-lateral" aria-label="Menú principal">
        <div class="menu__grupo">Navegación</div>
        ${enlacesHTML}
      </aside>
    `;

    // Configurar botón salir si está presente
    const btnCerrar = document.getElementById('btn-cerrar-sesion');
    if (btnCerrar) {
      btnCerrar.addEventListener('click', async () => {
        await cerrar();
      });
    }

    // Configurar comportamiento interactivo del menú móvil
    const btnToggle = document.getElementById('btn-toggle-menu');
    const menuLateral = document.getElementById('menu-lateral');
    const cortina = document.getElementById('menu-cortina');

    if (btnToggle && menuLateral && cortina) {
      const alternarMenu = () => {
        const abierto = menuLateral.classList.toggle('abierto');
        cortina.classList.toggle('abierto', abierto);
        btnToggle.setAttribute('aria-expanded', String(abierto));
      };

      btnToggle.addEventListener('click', alternarMenu);
      cortina.addEventListener('click', alternarMenu);

      menuLateral.querySelectorAll('.menu__enlace').forEach(enlace => {
        enlace.addEventListener('click', () => {
          if (window.innerWidth <= 768) {
            menuLateral.classList.remove('abierto');
            cortina.classList.remove('abierto');
            btnToggle.setAttribute('aria-expanded', 'false');
          }
        });
      });
    }

    // Actualizar contador de noticias no leídas si el usuario tiene sesión
    if (usuario && document.getElementById('badge-noticias-no-leidas')) {
      actualizarContadorNoticias();
    }
  }

  // 6. Pie de página al final del body

  let pie = document.querySelector('footer.pie');
  if (!pie) {
    pie = document.createElement('footer');
    pie.className = 'pie';
    pie.setAttribute('role', 'contentinfo');
    const anio = new Date().getFullYear();
    pie.innerHTML = `
      <div class="contenedor pie__contenedor" style="text-align: center;">
        <p>&copy; ${anio} ${NOMBRE}. Todos los derechos reservados.</p>
      </div>
    `;
    document.body.appendChild(pie);
  }
}

/**
 * Consulta las noticias publicadas y las lecturas del usuario para actualizar el badge.
 */
async function actualizarContadorNoticias() {
  try {
    const badge = document.getElementById('badge-noticias-no-leidas');
    if (!badge) return;

    const [noticias, lecturas] = await Promise.all([
      api.listar('noticias'),
      api.listar('lecturas-noticias')
    ]);

    const publicadas = (noticias || []).filter(n => n.estado === 'publicado');
    const leidasIds = new Set((lecturas || []).map(l => l.noticiaId));
    const sinLeer = publicadas.filter(n => !leidasIds.has(n.id)).length;

    if (sinLeer > 0) {
      badge.textContent = String(sinLeer);
      badge.style.display = 'inline-block';
    } else {
      badge.style.display = 'none';
    }
  } catch {
    // Si falla o no hay conexión, se mantiene oculto silenciosamente
  }
}

export default {
  NOMBRE,
  montarPlantilla
};

