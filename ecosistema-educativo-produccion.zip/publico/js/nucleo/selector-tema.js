/**
 * Módulo selector-tema.js
 * Selector pedagógico de temas para actividades.
 * Contrato §A: obtenerTemaActividad() → Promise<tema>
 */

import * as api from './api.js';
import * as util from './util.js';
import * as ui from './ui.js';

/**
 * Obtiene el tema para la actividad actual:
 * Si viene el parámetro ?temaId= en la URL lo carga; si no, despliega un selector interactivo.
 * @returns {Promise<object>} Tema seleccionado
 */
export async function obtenerTemaActividad() {
  const temaIdParam = util.parametro('temaId');

  if (temaIdParam) {
    try {
      const tema = await api.obtener('temas', temaIdParam);
      if (tema && tema.id) return tema;
    } catch (err) {
      console.warn('No se pudo cargar el tema desde temaId:', err);
    }
  }

  // Si no viene en la URL o falló, cargar temas disponibles del usuario
  ui.cargando(true);
  let temasDisponibles = [];

  try {
    const [todasAsig, todasUnidades, todosTemas] = await Promise.all([
      api.listar('asignaturas'),
      api.listar('unidades'),
      api.listar('temas')
    ]);

    const idsAsig = new Set((todasAsig || []).map(a => a.id));
    const unidadesValidas = (todasUnidades || []).filter(u => idsAsig.has(u.asignaturaId) && u.visible !== false);
    const idsUnidades = new Set(unidadesValidas.map(u => u.id));

    temasDisponibles = (todosTemas || []).filter(t =>
      idsUnidades.has(t.unidadId) && t.estado === 'publicado'
    );
  } catch (err) {
    ui.aviso('Error al cargar temas: ' + err.message, 'error');
  } finally {
    ui.cargando(false);
  }

  if (temasDisponibles.length === 0) {
    ui.aviso('No tienes temas publicados asignados actualmente.', 'advertencia');
    throw new Error('No hay temas disponibles');
  }

  // Si hay exactamente uno, seleccionarlo
  if (temasDisponibles.length === 1) {
    const unico = temasDisponibles[0];
    const url = new URL(window.location.href);
    url.searchParams.set('temaId', unico.id);
    window.history.replaceState({}, '', url.toString());
    return unico;
  }

  // Desplegar modal para seleccionar tema
  const opcionesHtml = temasDisponibles.map(t => `
    <option value="${ui.escapar(t.id)}">${ui.escapar(t.titulo)}</option>
  `).join('');

  const modalHtml = `
    <div class="pila" style="gap: var(--espacio-m);">
      <p style="margin: 0; color: var(--color-texto-suave);">
        Selecciona el tema pedagógico sobre el cual deseas realizar esta actividad:
      </p>
      <div class="campo">
        <label for="selector-tema-actividad">Tema disponible:</label>
        <select id="selector-tema-actividad" class="control">
          ${opcionesHtml}
        </select>
      </div>
    </div>
  `;

  const respuesta = await ui.modal({
    titulo: 'Seleccionar Tema de Aprendizaje',
    contenido: modalHtml,
    acciones: [
      { id: 'seleccionar', texto: 'Comenzar actividad →', clase: 'btn btn--primario' }
    ]
  });

  const selectEl = document.getElementById('selector-tema-actividad');
  const seleccionadoId = selectEl?.value || temasDisponibles[0].id;
  const temaElegido = temasDisponibles.find(t => t.id === seleccionadoId) || temasDisponibles[0];

  // Actualizar URL sin recargar
  const url = new URL(window.location.href);
  url.searchParams.set('temaId', temaElegido.id);
  window.history.replaceState({}, '', url.toString());

  return temaElegido;
}

export default {
  obtenerTemaActividad
};
