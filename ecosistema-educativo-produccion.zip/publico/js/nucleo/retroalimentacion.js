/**
 * Módulo retroalimentacion.js
 * Retroalimentación formativa inmediata y resúmenes de evaluación.
 * Contrato §A: mostrarRetro, mostrarResumen
 */

import * as ui from './ui.js';

/**
 * Muestra la retroalimentación inmediata tras responder una pregunta o reactivo.
 * @param {object} opciones
 * @param {boolean} opciones.correcto - Si la respuesta fue acertada
 * @param {string} opciones.explicacion - Retroalimentación explicativa
 * @param {string} [opciones.sugerencia] - Pista o sugerencia pedagógica
 * @param {string} [opciones.enlaceTema] - URL del tema para profundizar
 * @returns {Promise<void>}
 */
export async function mostrarRetro({ correcto, explicacion = '', sugerencia = '', enlaceTema = '' } = {}) {
  const icono = correcto ? '✔' : '✕';
  const claseColor = correcto ? 'color: var(--color-exito);' : 'color: var(--color-error);';
  const titulo = correcto ? '¡Respuesta correcta!' : 'Respuesta incorrecta';

  const contenidoHtml = `
    <div class="pila" style="gap: var(--espacio-m); text-align: center;">
      <div style="font-size: 3rem; line-height: 1; ${claseColor}">
        ${icono}
      </div>
      <h3 style="margin: 0; ${claseColor}">${titulo}</h3>

      ${explicacion ? `
        <div style="background: var(--color-fondo); padding: var(--espacio-m); border-radius: var(--radio-m); text-align: left; font-size: var(--tamano-s); line-height: 1.5;">
          <strong>Explicación:</strong>
          <p style="margin: var(--espacio-xs) 0 0 0;">${ui.escapar(explicacion)}</p>
        </div>
      ` : ''}

      ${sugerencia ? `
        <p style="margin: 0; font-size: var(--tamano-xs); color: var(--color-texto-suave);">
          💡 <em>${ui.escapar(sugerencia)}</em>
        </p>
      ` : ''}

      ${enlaceTema ? `
        <a href="${ui.escapar(enlaceTema)}" target="_blank" style="font-size: var(--tamano-xs); color: var(--color-primario);">
          📖 Repasar contenidos del tema en una nueva pestaña →
        </a>
      ` : ''}
    </div>
  `;

  await ui.modal({
    titulo: 'Retroalimentación Pedagógica',
    contenido: contenidoHtml,
    acciones: [
      { id: 'continuar', texto: 'Siguiente pregunta →', clase: 'btn btn--primario' }
    ]
  });
}

/**
 * Muestra el resumen final de la evaluación / quiz.
 * @param {object} opciones
 * @param {string} opciones.titulo
 * @param {number} opciones.aciertos
 * @param {number} opciones.errores
 * @param {Array<{ preguntaId, enunciado, retroalimentacion }>} [opciones.recomendaciones]
 * @param {string} [opciones.enlaceTema]
 * @returns {Promise<"repetir" | "salir">}
 */
export async function mostrarResumen({
  titulo = 'Resumen de Evaluación',
  aciertos = 0,
  errores = 0,
  recomendaciones = [],
  enlaceTema = ''
} = {}) {
  const total = aciertos + errores;
  const porcentaje = total > 0 ? Math.round((aciertos / total) * 100) : 0;
  const aprobado = porcentaje >= 70;

  const recomendacionesHtml = Array.isArray(recomendaciones) && recomendaciones.length > 0
    ? `
      <div style="margin-top: var(--espacio-m); text-align: left;">
        <h4 style="margin: 0 0 var(--espacio-s) 0; font-size: var(--tamano-s); color: var(--color-primario);">
          Temas y conceptos a repasar:
        </h4>
        <ul style="margin: 0; padding-left: var(--espacio-m); display: flex; flex-direction: column; gap: var(--espacio-xs); font-size: var(--tamano-xs); color: var(--color-texto-suave);">
          ${recomendaciones.map(r => `
            <li>
              <strong>${ui.escapar(r.enunciado || '')}:</strong> ${ui.escapar(r.retroalimentacion || '')}
            </li>
          `).join('')}
        </ul>
      </div>
    `
    : '';

  const contenidoHtml = `
    <div class="pila" style="gap: var(--espacio-m); text-align: center;">
      <div style="font-size: 3.5rem; line-height: 1;">
        ${aprobado ? '🏆' : '🎯'}
      </div>
      <h3 style="margin: 0; color: ${aprobado ? 'var(--color-exito)' : 'var(--color-advertencia)'};">
        ${aprobado ? '¡Felicitaciones! Nivel Aprobado' : 'Buen esfuerzo, sigue practicando'}
      </h3>

      <div style="display: flex; justify-content: center; gap: var(--espacio-l); margin: var(--espacio-s) 0;">
        <div style="text-align: center;">
          <span style="display: block; font-size: 2rem; font-weight: 700; color: var(--color-primario);">${porcentaje}%</span>
          <span style="font-size: var(--tamano-xs); color: var(--color-texto-suave);">Rendimiento</span>
        </div>
        <div style="text-align: center;">
          <span style="display: block; font-size: 2rem; font-weight: 700; color: var(--color-exito);">${aciertos}</span>
          <span style="font-size: var(--tamano-xs); color: var(--color-texto-suave);">Aciertos</span>
        </div>
        <div style="text-align: center;">
          <span style="display: block; font-size: 2rem; font-weight: 700; color: var(--color-error);">${errores}</span>
          <span style="font-size: var(--tamano-xs); color: var(--color-texto-suave);">Errores</span>
        </div>
      </div>

      ${recomendacionesHtml}

      ${enlaceTema ? `
        <a href="${ui.escapar(enlaceTema)}" style="font-size: var(--tamano-xs); color: var(--color-primario);">
          📖 Volver a estudiar la ficha del tema →
        </a>
      ` : ''}
    </div>
  `;

  const respuesta = await ui.modal({
    titulo,
    contenido: contenidoHtml,
    acciones: [
      { id: 'repetir', texto: '🔄 Reintentar nivel', clase: 'btn btn--secundario' },
      { id: 'salir', texto: 'Continuar →', clase: 'btn btn--primario' }
    ]
  });

  return respuesta === 'repetir' ? 'repetir' : 'salir';
}

export default {
  mostrarRetro,
  mostrarResumen
};
