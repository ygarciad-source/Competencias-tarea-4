/**
 * Módulo ui.js - Componentes de interfaz de usuario para el navegador
 * Proporciona avisos tipo toast, ventanas modales accesibles, indicador de carga y saneamiento de HTML.
 */

/**
 * Escapa caracteres especiales de HTML para prevenir inyecciones.
 * @param {string} texto
 * @returns {string}
 */
export function escapar(texto) {
  if (texto === null || texto === undefined) return '';
  const mapa = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  };
  return String(texto).replace(/[&<>"']/g, c => mapa[c] || c);
}

/**
 * Limpia y sanea una cadena HTML usando DOMPurify si está cargado;
 * de lo contrario, aplica escapar().
 * @param {string} html
 * @returns {string}
 */
export function limpiar(html) {
  if (html === null || html === undefined) return '';
  if (typeof window !== 'undefined' && window.DOMPurify && typeof window.DOMPurify.sanitize === 'function') {
    return window.DOMPurify.sanitize(String(html));
  }
  return escapar(html);
}

/**
 * Obtiene o crea el contenedor de toasts en el documento con aria-live="polite".
 * @returns {HTMLElement|null}
 */
function obtenerContenedorAvisos() {
  if (typeof document === 'undefined') return null;
  let contenedor = document.getElementById('contenedor-avisos');
  if (!contenedor) {
    contenedor = document.createElement('div');
    contenedor.id = 'contenedor-avisos';
    contenedor.className = 'contenedor-avisos';
    contenedor.setAttribute('aria-live', 'polite');
    contenedor.setAttribute('aria-atomic', 'true');
    document.body.appendChild(contenedor);
  }
  return contenedor;
}

/**
 * Muestra un aviso tipo toast que se cierra automáticamente a los 4 segundos.
 * @param {string} texto - Mensaje a mostrar
 * @param {'info'|'exito'|'error'} [tipo='info'] - Tipo visual de notificación
 * @returns {HTMLElement|null} Elemento DOM del aviso
 */
export function aviso(texto, tipo = 'info') {
  const contenedor = obtenerContenedorAvisos();
  if (!contenedor) return null;

  const elemento = document.createElement('div');
  elemento.className = `aviso aviso--${tipo}`;
  elemento.setAttribute('role', 'status');
  elemento.textContent = texto;

  const cerrar = () => {
    if (elemento.parentNode) {
      elemento.classList.add('aviso--saliendo');
      setTimeout(() => {
        if (elemento.parentNode) {
          elemento.parentNode.removeChild(elemento);
        }
      }, 200);
    }
  };

  elemento.addEventListener('click', cerrar);
  contenedor.appendChild(elemento);

  setTimeout(cerrar, 4000);
  return elemento;
}

/**
 * Selector de elementos que pueden recibir foco dentro de un diálogo modal.
 */
const SELECTORES_FOCO = [
  'button:not([disabled])',
  '[href]',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])'
].join(', ');

/**
 * Muestra una ventana modal accesible.
 * role="dialog", aria-modal="true", atrapa el foco y se cierra con Esc o clic fuera.
 * @param {object} opciones
 * @param {string} [opciones.titulo=''] - Título del diálogo
 * @param {string|HTMLElement} [opciones.contenido=''] - Texto/HTML saneado o nodo DOM
 * @param {Array<{ texto: string, valor: any, clase?: string }>} [opciones.acciones] - Botones de acción
 * @returns {Promise<any|null>} Devuelve el valor de la acción pulsada o null si se cancela/cierra
 */
export function modal({ titulo = '', contenido = '', acciones = [] } = {}) {
  return new Promise(resolve => {
    if (typeof document === 'undefined') {
      resolve(null);
      return;
    }

    const focoAnterior = document.activeElement;
    let resuelto = false;

    // Crear capa de fondo / telón
    const telon = document.createElement('div');
    telon.className = 'modal-telon';
    telon.setAttribute('role', 'presentation');

    // Diálogo accesible
    const dialogo = document.createElement('div');
    dialogo.className = 'modal-dialogo';
    dialogo.setAttribute('role', 'dialog');
    dialogo.setAttribute('aria-modal', 'true');
    dialogo.setAttribute('tabindex', '-1');

    const idTitulo = `modal-titulo-${Date.now()}`;
    dialogo.setAttribute('aria-labelledby', idTitulo);

    // Cabecera
    const cabecera = document.createElement('header');
    cabecera.className = 'modal-cabecera';

    const h2 = document.createElement('h2');
    h2.id = idTitulo;
    h2.className = 'modal-titulo';
    h2.textContent = titulo;
    cabecera.appendChild(h2);

    const btnCerrar = document.createElement('button');
    btnCerrar.type = 'button';
    btnCerrar.className = 'modal-cerrar';
    btnCerrar.setAttribute('aria-label', 'Cerrar ventana');
    btnCerrar.innerHTML = '&times;';
    cabecera.appendChild(btnCerrar);

    // Cuerpo
    const cuerpo = document.createElement('div');
    cuerpo.className = 'modal-cuerpo';
    if (contenido instanceof HTMLElement || (typeof Node !== 'undefined' && contenido instanceof Node)) {
      cuerpo.appendChild(contenido);
    } else {
      cuerpo.innerHTML = limpiar(String(contenido));
    }

    // Pie con acciones
    const pie = document.createElement('footer');
    pie.className = 'modal-acciones';

    const listaAcciones = (Array.isArray(acciones) && acciones.length > 0)
      ? acciones
      : [{ texto: 'Aceptar', valor: true, clase: 'btn-primario' }];

    const botonesAccion = [];
    listaAcciones.forEach(acc => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `btn ${acc.clase || ''}`.trim();
      btn.textContent = acc.texto;
      btn.addEventListener('click', () => terminar(acc.valor));
      pie.appendChild(btn);
      botonesAccion.push(btn);
    });

    dialogo.appendChild(cabecera);
    dialogo.appendChild(cuerpo);
    dialogo.appendChild(pie);
    telon.appendChild(dialogo);

    // Función de cierre y restauración
    function terminar(valor) {
      if (resuelto) return;
      resuelto = true;

      document.removeEventListener('keydown', gestionarTeclas);
      if (telon.parentNode) {
        telon.parentNode.removeChild(telon);
      }

      if (focoAnterior && typeof focoAnterior.focus === 'function') {
        focoAnterior.focus();
      }

      resolve(valor !== undefined ? valor : null);
    }

    // Cerrar con botón X o clic en fondo
    btnCerrar.addEventListener('click', () => terminar(null));
    telon.addEventListener('click', evento => {
      if (evento.target === telon) {
        terminar(null);
      }
    });

    // Atrapar foco y gestionar tecla Esc
    function gestionarTeclas(evento) {
      if (evento.key === 'Escape') {
        evento.preventDefault();
        terminar(null);
        return;
      }

      if (evento.key === 'Tab') {
        const elementos = Array.from(dialogo.querySelectorAll(SELECTORES_FOCO))
          .filter(el => !el.disabled && el.offsetParent !== null);

        if (elementos.length === 0) {
          evento.preventDefault();
          return;
        }

        const primer = elementos[0];
        const ultimo = elementos[elementos.length - 1];

        if (evento.shiftKey) {
          if (document.activeElement === primer || !dialogo.contains(document.activeElement)) {
            evento.preventDefault();
            ultimo.focus();
          }
        } else {
          if (document.activeElement === ultimo || !dialogo.contains(document.activeElement)) {
            evento.preventDefault();
            primer.focus();
          }
        }
      }
    }

    document.addEventListener('keydown', gestionarTeclas);
    document.body.appendChild(telon);

    // Dar foco al primer botón o al diálogo
    const focoInicial = botonesAccion[botonesAccion.length - 1] || dialogo.querySelector(SELECTORES_FOCO) || dialogo;
    setTimeout(() => {
      if (typeof focoInicial.focus === 'function') {
        focoInicial.focus();
      }
    }, 20);
  });
}

/**
 * Muestra un diálogo de confirmación accesible usando modal().
 * @param {string} texto - Pregunta o texto descriptivo
 * @returns {Promise<boolean>} Devuelve true si el usuario aceptó, false si canceló o cerró
 */
export async function confirmar(texto) {
  const resultado = await modal({
    titulo: 'Confirmación',
    contenido: texto,
    acciones: [
      { texto: 'Cancelar', valor: false, clase: 'btn-secundario' },
      { texto: 'Aceptar', valor: true, clase: 'btn-primario' }
    ]
  });
  return resultado === true;
}

/**
 * Controla el indicador de estado de carga en la interfaz.
 * @param {boolean} estado - true para mostrar el indicador .cargando, false para ocultarlo
 */
export function cargando(estado) {
  if (typeof document === 'undefined') return;

  let el = document.querySelector('.cargando');

  if (estado) {
    if (!el) {
      el = document.createElement('div');
      el.className = 'cargando';
      el.setAttribute('role', 'status');
      el.setAttribute('aria-live', 'polite');
      el.setAttribute('aria-label', 'Cargando');
      el.innerHTML = '<span class="cargando-spinner" aria-hidden="true"></span><span class="cargando-texto">Cargando...</span>';
      document.body.appendChild(el);
    }
    el.removeAttribute('hidden');
    el.style.display = '';
    document.body.setAttribute('aria-busy', 'true');
  } else {
    if (el) {
      el.setAttribute('hidden', '');
      el.style.display = 'none';
    }
    document.body.removeAttribute('aria-busy');
  }
}

export default {
  aviso,
  modal,
  confirmar,
  cargando,
  escapar,
  limpiar
};
