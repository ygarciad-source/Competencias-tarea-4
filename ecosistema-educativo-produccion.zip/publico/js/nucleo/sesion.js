/**
 * Módulo sesion.js - Gestión de sesión y control de acceso en el navegador
 * Almacena token y usuario en sessionStorage y verifica roles según contrato §A.
 */

import { llamar } from './api.js';

/**
 * Obtiene el token de autenticación guardado en sessionStorage.
 * @returns {string|null}
 */
export function token() {
  try {
    if (typeof sessionStorage !== 'undefined') {
      return sessionStorage.getItem('token');
    }
  } catch {
    // Silencioso en caso de restricciones de almacenamiento
  }
  return null;
}

/**
 * Obtiene el objeto del usuario autenticado guardado en sessionStorage.
 * @returns {{ id: string, nombre: string, apellido: string, rol: string }|null}
 */
export function usuarioActual() {
  try {
    if (typeof sessionStorage !== 'undefined') {
      const datos = sessionStorage.getItem('usuario');
      if (datos) {
        return JSON.parse(datos);
      }
    }
  } catch {
    // Silencioso en caso de error de parseo o almacenamiento
  }
  return null;
}

/**
 * Registra un nuevo usuario en el sistema e inicia sesión automáticamente.
 * Guarda "token" y "usuario" en sessionStorage.
 * @param {object} datos - { nombre, apellido, correo, clave, consentimiento, rol }
 * @returns {Promise<{ token: string, usuario: object }>}
 */
export async function registrar(datos) {
  const respuesta = await llamar('POST', '/api/auth/registro', datos);
  if (respuesta && respuesta.token && respuesta.usuario) {
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('token', respuesta.token);
        sessionStorage.setItem('usuario', JSON.stringify(respuesta.usuario));
      }
    } catch (e) {
      console.error('Error al guardar sesión:', e);
    }
  }
  return respuesta;
}

/**
 * Inicia sesión verificando credenciales en el servidor.
 * Guarda "token" y "usuario" en sessionStorage.
 * @param {string} correo
 * @param {string} clave
 * @returns {Promise<{ token: string, usuario: object }>}
 */
export async function iniciar(correo, clave) {
  const respuesta = await llamar('POST', '/api/auth/login', { correo, clave });
  if (respuesta && respuesta.token && respuesta.usuario) {
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('token', respuesta.token);
        sessionStorage.setItem('usuario', JSON.stringify(respuesta.usuario));
      }
    } catch (e) {
      console.error('Error al guardar sesión:', e);
    }
  }
  return respuesta;
}

/**
 * Cierra la sesión activa en el servidor y limpia sessionStorage.
 * Redirige a la página de ingreso.
 * @returns {Promise<void>}
 */
export async function cerrar() {
  try {
    await llamar('POST', '/api/auth/logout');
  } catch {
    // Si falla la petición de logout en red, igual se limpia la sesión local
  } finally {
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.removeItem('token');
        sessionStorage.removeItem('usuario');
      }
    } catch {
      // Silencioso
    }

    if (typeof window !== 'undefined') {
      window.location.href = '/paginas/ingreso.html';
    }
  }
}

/**
 * Exige los roles indicados para la página actual.
 * - Sin sesión → redirige a /paginas/ingreso.html
 * - Rol no permitido → redirige a /index.html con un aviso
 * @param {string|string[]} roles
 * @returns {boolean} true si el acceso está autorizado, false si fue redirigido
 */
export function exigirRol(roles) {
  if (!roles) return true;

  const lista = Array.isArray(roles) ? roles : [roles];

  // Si incluye 'publico', no exige sesión
  if (lista.includes('publico')) {
    return true;
  }

  const usuario = usuarioActual();

  // Sin sesión → /paginas/ingreso.html
  if (!usuario) {
    if (typeof window !== 'undefined') {
      window.location.href = '/paginas/ingreso.html';
    }
    return false;
  }

  // Rol permitido si pide 'sesion', coincide con rol del usuario o es admin
  const rol = usuario.rol;
  const autorizado = lista.includes('sesion') ||
                     lista.includes(rol) ||
                     rol === 'admin';

  if (!autorizado) {
    // Rol no permitido → /index.html con un aviso
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('aviso_pendiente', JSON.stringify({
          texto: 'No tienes los permisos necesarios para acceder a esta página.',
          tipo: 'error'
        }));
      }
    } catch {
      // Silencioso
    }

    if (typeof window !== 'undefined') {
      window.location.href = '/index.html';
    }
    return false;
  }

  return true;
}

export default {
  token,
  usuarioActual,
  registrar,
  iniciar,
  cerrar,
  exigirRol
};
