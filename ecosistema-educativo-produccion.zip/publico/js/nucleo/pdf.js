/**
 * Módulo pdf.js
 * Generación de diplomas y certificados descargables.
 * Contrato §A: generarDiploma({ tipo, temaId, nivel }) → { codigo }
 */

import * as api from './api.js';
import { usuarioActual } from './sesion.js';

const NOMBRES_BLOOM = {
  1: 'Recordar',
  2: 'Comprender',
  3: 'Aplicar',
  4: 'Analizar',
  5: 'Evaluar'
};

/**
 * Genera y registra un diploma para el estudiante, abriendo la vista de impresión/descarga en PDF.
 * @param {object} opciones
 * @param {"cumplimiento" | "nivel-quiz"} opciones.tipo
 * @param {string} opciones.temaId
 * @param {number} [opciones.nivel]
 * @returns {Promise<{ codigo: string }>}
 */
export async function generarDiploma({ tipo = 'nivel-quiz', temaId, nivel = 1 } = {}) {
  const usuario = usuarioActual();
  if (!usuario) {
    throw new Error('Sesión requerida para emitir diploma');
  }

  // Cargar información del tema
  const tema = await api.obtener('temas', temaId);
  const nombreNivel = NOMBRES_BLOOM[nivel] || `Nivel ${nivel}`;
  const nombreEstudiante = `${usuario.nombre || ''} ${usuario.apellido || ''}`.trim() || 'Estudiante';

  // Generar código único de verificación
  const aleatorio = Math.random().toString(36).substring(2, 8).toUpperCase();
  const codigo = `CERT-${tipo === 'nivel-quiz' ? `NQ${nivel}` : 'CUMP'}-${aleatorio}`;

  const detalleCertificado = {
    temaId,
    temaTitulo: tema?.titulo || 'Competencias Digitales',
    nivel: Number(nivel),
    nivelNombre: nombreNivel,
    fechaEmision: new Date().toISOString()
  };

  // Guardar en la colección certificados
  try {
    await api.crear('certificados', {
      codigo,
      usuarioId: usuario.id,
      tipo,
      detalle: detalleCertificado,
      nombreCompleto: nombreEstudiante
    });
  } catch (err) {
    console.warn('Nota al registrar certificado en base de datos:', err.message);
  }

  // Generar documento imprimible
  abrirVentanaDiploma({
    codigo,
    nombreEstudiante,
    temaTitulo: detalleCertificado.temaTitulo,
    nivel: Number(nivel),
    nombreNivel,
    fecha: new Date().toLocaleDateString('es-EC', { year: 'numeric', month: 'long', day: 'numeric' })
  });

  return { codigo };
}

/**
 * Despliega la ventana con el diploma institucional estilizado listo para imprimir / guardar como PDF
 */
function abrirVentanaDiploma({ codigo, nombreEstudiante, temaTitulo, nivel, nombreNivel, fecha }) {
  const ventana = window.open('', '_blank', 'width=950,height=700');
  if (!ventana) {
    alert('Por favor habilita las ventanas emergentes para visualizar y descargar tu diploma.');
    return;
  }

  const html = `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <title>Diploma de Acreditación · ${codigo}</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=Poppins:wght@300;400;600&display=swap');
        
        * { box-sizing: border-box; }
        body {
          margin: 0;
          padding: 20px;
          background-color: #f1f5f9;
          font-family: 'Poppins', sans-serif;
          color: #002e45;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 100vh;
        }

        .acciones-impresion {
          margin-bottom: 20px;
          display: flex;
          gap: 12px;
        }

        .btn-imprimir {
          background-color: #ff6900;
          color: #ffffff;
          border: none;
          padding: 12px 24px;
          font-size: 15px;
          font-weight: 600;
          border-radius: 6px;
          cursor: pointer;
          box-shadow: 0 4px 12px rgba(255, 105, 0, 0.3);
          transition: background-color 0.2s;
        }
        .btn-imprimir:hover { background-color: #e05d00; }

        .diploma-contenedor {
          width: 860px;
          height: 600px;
          background: #ffffff;
          padding: 30px;
          position: relative;
          box-shadow: 0 10px 30px rgba(0, 46, 69, 0.15);
          border: 12px solid #002e45;
          border-radius: 8px;
        }

        .diploma-borde-dorado {
          border: 3px solid #d4af37;
          height: 100%;
          padding: 30px 40px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: space-between;
          text-align: center;
          position: relative;
          background: radial-gradient(circle at center, rgba(255,255,255,1) 0%, rgba(248,250,252,0.8) 100%);
        }

        .institucion {
          font-family: 'Cinzel', serif;
          font-size: 20px;
          letter-spacing: 2px;
          color: #002e45;
          text-transform: uppercase;
          margin-bottom: 4px;
        }

        .subinstitucion {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 3px;
          color: #264763;
        }

        .titulo-diploma {
          font-family: 'Cinzel', serif;
          font-size: 32px;
          font-weight: 800;
          color: #ff6900;
          letter-spacing: 3px;
          margin: 15px 0 5px 0;
          text-transform: uppercase;
        }

        .otorga-a {
          font-size: 13px;
          color: #556877;
          font-style: italic;
          margin-bottom: 6px;
        }

        .nombre-estudiante {
          font-family: 'Cinzel', serif;
          font-size: 28px;
          font-weight: 700;
          color: #002e45;
          border-bottom: 2px solid #d4af37;
          padding-bottom: 4px;
          margin-bottom: 12px;
          min-width: 400px;
        }

        .descripcion-logro {
          font-size: 13px;
          line-height: 1.6;
          color: #182d3e;
          max-width: 650px;
          margin-bottom: 10px;
        }

        .meta-pie {
          width: 100%;
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          padding-top: 15px;
          border-top: 1px solid rgba(0, 46, 69, 0.1);
        }

        .sello-digital {
          font-size: 10px;
          color: #556877;
          text-align: left;
        }

        .codigo-verificacion {
          font-family: monospace;
          font-size: 12px;
          font-weight: bold;
          color: #002e45;
          letter-spacing: 1px;
        }

        @media print {
          body { background: transparent; padding: 0; }
          .acciones-impresion { display: none; }
          .diploma-contenedor {
            box-shadow: none;
            width: 100%;
            height: 100%;
            page-break-inside: avoid;
          }
        }
      </style>
    </head>
    <body>
      <div class="acciones-impresion">
        <button class="btn-imprimir" onclick="window.print()">🖨 Imprimir / Guardar como PDF</button>
      </div>

      <div class="diploma-contenedor">
        <div class="diploma-borde-dorado">
          <div>
            <div class="institucion">Universidad Estatal de Milagro · UNEMI</div>
            <div class="subinstitucion">Ecosistema Educativo de Competencias Digitales</div>
          </div>

          <div>
            <div class="titulo-diploma">Diploma de Superación</div>
            <div class="otorga-a">Se otorga con distinción académica a:</div>
            <div class="nombre-estudiante">${nombreEstudiante}</div>
            <div class="descripcion-logro">
              Por haber superado satisfactoriamente la evaluación formativa del <strong>Nivel ${nivel} (Taxonomía de Bloom · ${nombreNivel})</strong> correspondiente al tema pedagógico:
              <br>
              <strong>"${temaTitulo}"</strong>
            </div>
          </div>

          <div class="meta-pie">
            <div class="sello-digital">
              <div>Emitido en Milagro, Ecuador</div>
              <div>Fecha: ${fecha}</div>
            </div>

            <div>
              <div style="font-size: 2.2rem; line-height: 1;">🏅</div>
            </div>

            <div style="text-align: right;">
              <div class="codigo-verificacion">CÓDIGO: ${codigo}</div>
              <div style="font-size: 9px; color: #556877;">Acreditación digital verificada</div>
            </div>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  ventana.document.write(html);
  ventana.document.close();
}

export default {
  generarDiploma
};
