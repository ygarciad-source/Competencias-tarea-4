/**
 * Módulo bitacora.js - Registro de eventos de auditoría y analítica
 * Envía eventos al servidor para su almacenamiento en bitacora.jsonl.
 */

import { llamar } from './api.js';

/**
 * Registra un evento de actividad o navegación en el servidor.
 * @param {string} tipo - Tipo de evento (ej: 'pagina', 'clic', 'actividad')
 * @param {string} recurso - Recurso asociado (ej: '/index.html', 'tema_000001')
 * @returns {Promise<object|null>}
 */
export async function registrarEvento(tipo, recurso) {
  try {
    return await llamar('POST', '/api/eventos', { tipo, recurso });
  } catch (err) {
    // Registro tolerante a fallos para no interrumpir la experiencia de usuario
    console.debug('Error al registrar evento en bitácora:', err?.message);
    return null;
  }
}

export default {
  registrarEvento
};
