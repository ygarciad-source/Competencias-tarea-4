/**
 * Módulo gamificacion.js (cliente)
 * Gestión de intentos, logros e insignias para el usuario.
 * Contrato §A: registrarIntento, mostrarLogros, logrosDe
 */

import * as api from './api.js';
import * as ui from './ui.js';

/**
 * Registra un intento de actividad en el servidor.
 * @param {object} datos - { actividad, temaId, nivel, puntaje, maximo, errores, duracionSeg, detalle }
 * @returns {Promise<{ puntosGanados: number, puntosTotales: number, insigniasNuevas: Array }>}
 */
export async function registrarIntento(datos) {
  return api.llamar('POST', '/api/intentos', datos);
}

/**
 * Obtiene el registro de logros de un usuario ("yo" por defecto).
 * @param {string} [usuarioId="yo"]
 * @returns {Promise<{ usuarioId, puntos, insignias, nivelQuiz }>}
 */
export async function logrosDe(usuarioId = 'yo') {
  return api.llamar('GET', `/api/logros/${encodeURIComponent(usuarioId)}`);
}

/**
 * Despliega un modal o aviso festivo cuando el usuario gana puntos o nuevas insignias.
 * @param {object} resultado - { puntosGanados, puntosTotales, insigniasNuevas }
 */
export async function mostrarLogros(resultado = {}) {
  const { puntosGanados = 0, insigniasNuevas = [] } = resultado;

  if (puntosGanados <= 0 && (!insigniasNuevas || insigniasNuevas.length === 0)) {
    return;
  }

  const insigniasHtml = Array.isArray(insigniasNuevas) && insigniasNuevas.length > 0
    ? `
      <div style="margin-top: var(--espacio-m); text-align: center;">
        <span class="insignia insignia--acento" style="font-weight: 700;">¡NUEVA INSIGNIA DESBLOQUEADA!</span>
        <div style="display: flex; justify-content: center; gap: var(--espacio-m); margin-top: var(--espacio-s); flex-wrap: wrap;">
          ${insigniasNuevas.map(ins => `
            <div style="background: var(--color-fondo); border: 2px solid var(--color-acento); border-radius: var(--radio-m); padding: var(--espacio-m); text-align: center; min-width: 140px;">
              <span style="font-size: 2.8rem; display: block; line-height: 1;">${ui.escapar(ins.icono || '🏆')}</span>
              <strong style="display: block; margin-top: var(--espacio-xs); color: var(--color-primario); font-size: var(--tamano-s);">${ui.escapar(ins.nombre)}</strong>
            </div>
          `).join('')}
        </div>
      </div>
    `
    : '';

  const contenidoHtml = `
    <div class="pila" style="gap: var(--espacio-m); text-align: center;">
      <div style="font-size: 3.5rem; line-height: 1;">🎉</div>
      <h3 style="margin: 0; color: var(--color-primario);">¡Progreso Registrado!</h3>

      ${puntosGanados > 0 ? `
        <div style="background: rgba(255, 105, 0, 0.1); border: 1px solid var(--color-acento); border-radius: var(--radio-m); padding: var(--espacio-m);">
          <span style="font-size: var(--tamano-xs); text-transform: uppercase; letter-spacing: 0.05em; font-weight: 700; color: var(--color-acento);">Puntos obtenidos</span>
          <div style="font-size: 2.5rem; font-weight: 800; color: var(--color-primario);">+${puntosGanados} pts</div>
        </div>
      ` : ''}

      ${insigniasHtml}
    </div>
  `;

  await ui.modal({
    titulo: 'Recompensas de Aprendizaje',
    contenido: contenidoHtml,
    acciones: [
      { id: 'cerrar', texto: '¡Genial! Continuar', clase: 'btn btn--acento' }
    ]
  });
}

export default {
  registrarIntento,
  mostrarLogros,
  logrosDe
};
