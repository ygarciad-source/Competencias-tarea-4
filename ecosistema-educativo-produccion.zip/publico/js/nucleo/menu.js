/**
 * Módulo menu.js - Definición de navegación del sistema
 * Define los elementos del menú principal y sus roles autorizados.
 */

export const MENU = [
  { texto: 'Inicio', href: '/index.html', roles: ['publico'] },
  { texto: 'Mis asignaturas', href: '/paginas/asignaturas.html', roles: ['estudiante', 'docente'] },
  { texto: 'Noticias', href: '/paginas/noticias.html', roles: ['sesion'] },
  { texto: 'Canciones', href: '/paginas/canciones.html', roles: ['sesion'] },
  { texto: 'Contenidos', href: '/paginas/editor-contenidos.html', roles: ['docente', 'admin'] },
  { texto: 'Asignaturas', href: '/paginas/admin-asignaturas.html', roles: ['admin'] },
  { texto: 'Distributivo', href: '/paginas/distributivo.html', roles: ['admin'] },
  { texto: 'Usuarios', href: '/paginas/admin-usuarios.html', roles: ['admin'] },
  { texto: 'Configuración IA', href: '/paginas/admin-ajustes.html', roles: ['admin'] },
  { texto: 'Mi perfil', href: '/paginas/perfil.html', roles: ['sesion'] }
];


export default MENU;
