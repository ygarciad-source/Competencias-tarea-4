/**
 * Módulo util.js - Utilidades generales para el navegador
 * Funciones de normalización de cadenas, barajado inmutable, fechas en es-EC,
 * lectura de parámetros de URL y formateo básico seguro de texto.
 */

import { escapar } from './ui.js';

/**
 * Normaliza un texto: convierte a mayúsculas, elimina tildes y diéresis,
 * conserva la letra Ñ y remueve espacios sobrantes al inicio y final.
 * @param {string} texto
 * @returns {string}
 */
export function normalizar(texto) {
  if (texto === null || texto === undefined) return '';
  let s = String(texto).trim();
  if (!s) return '';

  // Asegurar formato NFC y convertir a mayúsculas
  s = s.normalize('NFC').toUpperCase();

  // Preservar la Ñ sustituyéndola temporalmente por un token seguro
  s = s.replace(/Ñ/g, '\u0001');

  // Descomponer en NFD y remover marcas diacríticas (tildes, diéresis)
  s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');

  // Restaurar la Ñ
  s = s.replace(/\u0001/g, 'Ñ');

  return s;
}

/**
 * Baraja una lista mediante el algoritmo Fisher-Yates sin mutar el arreglo original.
 * @template T
 * @param {Array<T>} lista
 * @returns {Array<T>} Nueva lista con los elementos barajados
 */
export function barajar(lista) {
  if (!Array.isArray(lista)) return [];
  const copia = [...lista];
  for (let i = copia.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

/**
 * Analiza una fecha ISO o string representativo evitando el desfase de zona horaria en fechas simples.
 * @param {string|Date} iso
 * @returns {Date|null}
 */
function parsearFecha(iso) {
  if (!iso) return null;
  if (iso instanceof Date) return isNaN(iso.getTime()) ? null : iso;
  const str = String(iso).trim();
  if (!str) return null;

  // Formato YYYY-MM-DD sin hora: interpretar como fecha local para evitar desfase de huso horario
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
    const [y, m, d] = str.split('-').map(Number);
    return new Date(y, m - 1, d);
  }

  const d = new Date(str);
  return isNaN(d.getTime()) ? null : d;
}

/**
 * Formatea una fecha en formato largo en español de Ecuador (ej: "24 de octubre de 2026").
 * @param {string|Date} iso - Fecha en formato ISO o compatible
 * @returns {string}
 */
export function fechaLarga(iso) {
  const fecha = parsearFecha(iso);
  if (!fecha) return '';
  try {
    const formateador = new Intl.DateTimeFormat('es-EC', { dateStyle: 'long' });
    return formateador.format(fecha);
  } catch {
    return fecha.toLocaleDateString('es-EC');
  }
}

/**
 * Formatea una fecha relativa en español de Ecuador (ej: "hace 5 minutos", "ayer", "en 2 horas").
 * @param {string|Date} iso - Fecha en formato ISO o compatible
 * @returns {string}
 */
export function fechaRelativa(iso) {
  const fecha = parsearFecha(iso);
  if (!fecha) return '';

  const ahora = Date.now();
  const diffSegundos = Math.round((fecha.getTime() - ahora) / 1000);
  const diffMinutos = Math.round(diffSegundos / 60);
  const diffHoras = Math.round(diffMinutos / 60);
  const diffDias = Math.round(diffHoras / 24);
  const diffSemanas = Math.round(diffDias / 7);
  const diffMeses = Math.round(diffDias / 30);
  const diffAnios = Math.round(diffDias / 365);

  try {
    const rtf = new Intl.RelativeTimeFormat('es-EC', { numeric: 'auto' });

    if (Math.abs(diffSegundos) < 60) {
      return rtf.format(diffSegundos, 'second');
    }
    if (Math.abs(diffMinutos) < 60) {
      return rtf.format(diffMinutos, 'minute');
    }
    if (Math.abs(diffHoras) < 24) {
      return rtf.format(diffHoras, 'hour');
    }
    if (Math.abs(diffDias) < 7) {
      return rtf.format(diffDias, 'day');
    }
    if (Math.abs(diffSemanas) < 5) {
      return rtf.format(diffSemanas, 'week');
    }
    if (Math.abs(diffMeses) < 12) {
      return rtf.format(diffMeses, 'month');
    }
    return rtf.format(diffAnios, 'year');
  } catch {
    return fechaLarga(iso);
  }
}

/**
 * Obtiene el valor de un parámetro de búsqueda de la URL actual.
 * @param {string} nombre - Clave del parámetro a obtener
 * @returns {string|null}
 */
export function parametro(nombre) {
  if (typeof window === 'undefined' || !window.location || !nombre) {
    return null;
  }
  const params = new URLSearchParams(window.location.search);
  return params.get(nombre);
}

/**
 * Aplica formato básico seguro a un texto:
 * 1. Escapa todo el HTML para prevenir inyecciones.
 * 2. Convierte **texto** en <strong>texto</strong>.
 * 3. Convierte líneas que inician con "- " en listas <ul><li>...</li></ul>.
 * 4. Envuelve bloques separados por líneas en blanco en párrafos <p>...</p>.
 * @param {string} texto
 * @returns {string} Cadena HTML segura
 */
export function formatoBasico(texto) {
  if (texto === null || texto === undefined) return '';
  const str = String(texto);
  if (!str.trim()) return '';

  // Escapar HTML previamente
  let escapado = escapar(str);

  // Convertir **texto** en <strong>texto</strong>
  escapado = escapado.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

  // Normalizar saltos de línea y separar bloques por líneas en blanco
  const bloques = escapado
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split(/\n\s*\n+/)
    .map(b => b.trim())
    .filter(Boolean);

  const partes = bloques.map(bloque => {
    const lineas = bloque.split('\n');
    const contieneListas = lineas.some(l => l.trim().startsWith('- '));

    if (contieneListas) {
      let resultado = '';
      let enLista = false;

      for (const linea of lineas) {
        const limpia = linea.trim();
        if (limpia.startsWith('- ')) {
          if (!enLista) {
            resultado += '<ul>';
            enLista = true;
          }
          resultado += `<li>${limpia.slice(2).trim()}</li>`;
        } else {
          if (enLista) {
            resultado += '</ul>';
            enLista = false;
          }
          if (limpia) {
            resultado += `<p>${limpia}</p>`;
          }
        }
      }

      if (enLista) {
        resultado += '</ul>';
      }
      return resultado;
    }

    return `<p>${bloque.replace(/\n/g, '<br>')}</p>`;
  });

  return partes.join('\n');
}

export default {
  normalizar,
  barajar,
  fechaLarga,
  fechaRelativa,
  parametro,
  formatoBasico
};
