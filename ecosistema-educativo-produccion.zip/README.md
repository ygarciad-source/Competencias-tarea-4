# Ecosistema Educativo Digital - UNEMI

Plataforma educativa modular desarrollada para la **Universidad Estatal de Milagro (UNEMI)**, centrada en el desarrollo de **Competencias Digitales Docentes (DigCompEdu y UNESCO TIC)** y la enseñanza aplicada del **Idioma Inglés (Oraciones Condicionales)** mediante **Inteligencia Artificial Socrática y Evaluativa (Google Gemini 3.5 Flash)**.

---

## 🚀 Despliegue en Render (Paso a Paso)

Este repositorio está preparado para desplegarse automáticamente en **[Render.com](https://render.com/)**:

### Opción 1: Despliegue con Repositorio GitHub
1. Ingresa a tu cuenta en [Render Dashboard](https://dashboard.render.com/).
2. Haz clic en el botón **New +** y selecciona **Web Service**.
3. Conecta tu cuenta de GitHub y selecciona el repositorio:
   `https://github.com/ygarciad-source/Competencias-tarea-4.git`
4. Configura los parámetros básicos del servicio:
   - **Name:** `ecosistema-educativo`
   - **Region:** `Oregon (US West)` o la más cercana a ti.
   - **Branch:** `main`
   - **Runtime:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** `Free`
5. En la sección **Environment Variables**, añade las siguientes variables:
   - `PORT`: `10000` (Render asigna los puertos automáticamente, o usa 3000)
   - `NODE_ENV`: `production`
   - `CLAVE_SECRETA_JWT`: `clave_secreta_jwt_muy_segura_unemi`
   - `IA_PROVEEDOR`: `gemini`
   - `IA_MODELO`: `gemini-3.5-flash`
   - `GEMINI_API_KEY`: *(Tu clave de API de Google Gemini)*
6. Haz clic en **Create Web Service**.
7. En 2-3 minutos Render finalizará la construcción y tu aplicación estará disponible en una URL pública del tipo `https://ecosistema-educativo.onrender.com`.

---

## 🛠️ Ejecución Local

1. Clona o descomprime el código fuente:
   ```bash
   npm install
   ```
2. Inicializa los datos y la cuenta de administrador:
   ```bash
   npm run semilla
   npm run crear-admin
   ```
3. Inicia el servidor de desarrollo:
   ```bash
   npm run dev
   ```
4. Abre en tu navegador web: `http://localhost:3000`

---

## 🏛️ Características Principales

- **Tutor Socrático con IA:** Orientación pedagógica dialógica, reflexiva y delimitada al currículo.
- **Banco de Quizes por Niveles de Bloom:** Generación, revisión, edición y publicación con Gemini 3.5 Flash.
- **Oraciones Condicionales en Inglés:** Cobertura de Zero, 1st, 2nd, 3rd y Mixed Conditionals.
- **Gamificación Integral:** Puntos, insignias, cuotas diarias y diplomas en PDF imprimibles.
