import * as almacen from './almacen.js';

/**
 * Módulo acceso.js - Gestión de acceso académico y relaciones por grupo
 * Contrato §B: gruposDe, asignaturasDe, asignaturaDeTema, puedeEditarAsignatura, estudiantesDe, docentesDe
 */

/**
 * Obtiene los grupos del distributivo según el rol del usuario:
 * - admin: ve todos los grupos
 * - docente: grupos donde es docenteId
 * - estudiante: grupos donde figura en estudiantes
 * @param {object} usuario
 * @returns {Promise<Array>}
 */
export async function gruposDe(usuario) {
  if (!usuario) return [];
  const distributivo = await almacen.leer('distributivo');
  if (usuario.rol === 'admin') {
    return distributivo;
  }
  if (usuario.rol === 'docente') {
    return distributivo.filter(g => g.docenteId === usuario.id);
  }
  if (usuario.rol === 'estudiante') {
    return distributivo.filter(g => Array.isArray(g.estudiantes) && g.estudiantes.includes(usuario.id));
  }
  return [];
}

/**
 * Obtiene las asignaturas a las que pertenece el usuario:
 * - admin: ve todas las asignaturas
 * - docente / estudiante: asignaturas de sus grupos asignados
 * @param {object} usuario
 * @returns {Promise<Array>}
 */
export async function asignaturasDe(usuario) {
  if (!usuario) return [];
  const todas = await almacen.leer('asignaturas');
  if (usuario.rol === 'admin') {
    return todas;
  }
  const grupos = await gruposDe(usuario);
  const idsAsignaturas = new Set(grupos.map(g => g.asignaturaId).filter(Boolean));
  return todas.filter(a => idsAsignaturas.has(a.id));
}

/**
 * Resuelve la asignatura de un tema navegando tema -> unidad -> asignatura.
 * @param {string} temaId
 * @returns {Promise<object|null>}
 */
export async function asignaturaDeTema(temaId) {
  if (!temaId) return null;
  const temas = await almacen.leer('temas');
  const tema = temas.find(t => t.id === temaId);
  if (!tema || !tema.unidadId) return null;

  const unidades = await almacen.leer('unidades');
  const unidad = unidades.find(u => u.id === tema.unidadId);
  if (!unidad || !unidad.asignaturaId) return null;

  const asignaturas = await almacen.leer('asignaturas');
  return asignaturas.find(a => a.id === unidad.asignaturaId) || null;
}

/**
 * Evalúa si un usuario tiene permisos de edición en una asignatura:
 * - admin: siempre true
 * - docente: true si tiene asignado al menos un grupo de esa asignatura
 * - otros roles: false
 * @param {object} usuario
 * @param {string} asignaturaId
 * @returns {Promise<boolean>}
 */
export async function puedeEditarAsignatura(usuario, asignaturaId) {
  if (!usuario || !asignaturaId) return false;
  if (usuario.rol === 'admin') return true;
  if (usuario.rol !== 'docente') return false;

  const distributivo = await almacen.leer('distributivo');
  return distributivo.some(g => g.docenteId === usuario.id && g.asignaturaId === asignaturaId);
}

/**
 * Obtiene los estudiantes pertenecientes a los grupos de un docente.
 * @param {string} docenteId
 * @returns {Promise<Array>}
 */
export async function estudiantesDe(docenteId) {
  if (!docenteId) return [];
  const distributivo = await almacen.leer('distributivo');
  const gruposDocente = distributivo.filter(g => g.docenteId === docenteId);
  const idsEstudiantes = new Set();
  for (const g of gruposDocente) {
    if (Array.isArray(g.estudiantes)) {
      g.estudiantes.forEach(id => idsEstudiantes.add(id));
    }
  }

  const usuarios = await almacen.leer('usuarios');
  return usuarios.filter(u => idsEstudiantes.has(u.id));
}

/**
 * Obtiene los docentes asignados a los grupos de un estudiante.
 * @param {string} estudianteId
 * @returns {Promise<Array>}
 */
export async function docentesDe(estudianteId) {
  if (!estudianteId) return [];
  const distributivo = await almacen.leer('distributivo');
  const gruposEstudiante = distributivo.filter(g => Array.isArray(g.estudiantes) && g.estudiantes.includes(estudianteId));
  const idsDocentes = new Set(gruposEstudiante.map(g => g.docenteId).filter(Boolean));

  const usuarios = await almacen.leer('usuarios');
  return usuarios.filter(u => idsDocentes.has(u.id));
}

export default {
  gruposDe,
  asignaturasDe,
  asignaturaDeTema,
  puedeEditarAsignatura,
  estudiantesDe,
  docentesDe
};
