import * as almacen from '../almacen.js';
import { asignaturasDe, puedeEditarAsignatura } from '../acceso.js';

/**
 * Gancho para la colección "temas"
 */

export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;

  const misAsignaturas = await asignaturasDe(usuario);
  const idsAsignaturas = new Set(misAsignaturas.map(a => a.id));

  const unidades = await almacen.leer('unidades');

  if (usuario.rol === 'estudiante') {
    const unidadesValidas = new Set(
      unidades
        .filter(u => idsAsignaturas.has(u.asignaturaId) && u.visible !== false)
        .map(u => u.id)
    );
    return lista.filter(t => unidadesValidas.has(t.unidadId) && t.estado === 'publicado');
  }

  const unidadesDocente = new Set(
    unidades
      .filter(u => idsAsignaturas.has(u.asignaturaId))
      .map(u => u.id)
  );
  return lista.filter(t => unidadesDocente.has(t.unidadId));
}

export async function antesDeGuardar(datos, usuario, anterior) {
  const unidadId = datos?.unidadId || anterior?.unidadId;
  const unidades = await almacen.leer('unidades');
  const unidad = unidades.find(u => u.id === unidadId);

  const asignaturaId = unidad ? unidad.asignaturaId : null;
  const puede = await puedeEditarAsignatura(usuario, asignaturaId);
  if (!puede) {
    const error = new Error('No tienes permisos para editar temas en esta asignatura');
    error.estado = 403;
    throw error;
  }

  return datos;
}

export default {
  filtrarLista,
  antesDeGuardar
};
