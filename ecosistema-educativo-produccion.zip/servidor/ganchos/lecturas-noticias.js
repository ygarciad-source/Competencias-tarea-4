import * as almacen from '../almacen.js';

/**
 * Gancho para la colección "lecturas-noticias"
 */

export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;
  return lista.filter(l => l.usuarioId === usuario.id);
}

export async function antesDeGuardar(datos, usuario, anterior) {
  if (!usuario) {
    const error = new Error('Autenticación requerida');
    error.estado = 401;
    throw error;
  }

  // Fija usuarioId = usuario.id
  datos.usuarioId = usuario.id;

  if (!datos.noticiaId) {
    const error = new Error('El campo noticiaId es obligatorio');
    error.estado = 400;
    throw error;
  }

  // Evita duplicados (usuarioId + noticiaId)
  const lecturas = await almacen.leer('lecturas-noticias');
  const existe = lecturas.some(l =>
    l.usuarioId === datos.usuarioId &&
    l.noticiaId === datos.noticiaId &&
    (!anterior || l.id !== anterior.id)
  );

  if (existe) {
    const error = new Error('La lectura de esta noticia ya está registrada');
    error.estado = 400;
    throw error;
  }

  return datos;
}

export default {
  filtrarLista,
  antesDeGuardar
};
