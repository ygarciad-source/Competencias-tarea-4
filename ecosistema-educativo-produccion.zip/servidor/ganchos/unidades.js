import { asignaturasDe, puedeEditarAsignatura } from '../acceso.js';

/**
 * Gancho para la colección "unidades"
 */

export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;

  const misAsignaturas = await asignaturasDe(usuario);
  const permitidas = new Set(misAsignaturas.map(a => a.id));

  if (usuario.rol === 'estudiante') {
    return lista.filter(u => permitidas.has(u.asignaturaId) && u.visible !== false);
  }

  return lista.filter(u => permitidas.has(u.asignaturaId));
}

export async function antesDeGuardar(datos, usuario, anterior) {
  const asignaturaId = datos?.asignaturaId || anterior?.asignaturaId;
  const puede = await puedeEditarAsignatura(usuario, asignaturaId);
  if (!puede) {
    const error = new Error('No tienes permisos para editar unidades en esta asignatura');
    error.estado = 403;
    throw error;
  }
  return datos;
}

export default {
  filtrarLista,
  antesDeGuardar
};
