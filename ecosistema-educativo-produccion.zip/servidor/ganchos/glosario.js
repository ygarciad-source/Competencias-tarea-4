import * as almacen from '../almacen.js';
import { asignaturasDe, asignaturaDeTema, puedeEditarAsignatura } from '../acceso.js';

/**
 * Gancho para la colección "glosario"
 */

export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;

  const misAsignaturas = await asignaturasDe(usuario);
  const idsAsignaturas = new Set(misAsignaturas.map(a => a.id));

  const unidades = await almacen.leer('unidades');
  const temas = await almacen.leer('temas');

  if (usuario.rol === 'estudiante') {
    const unidadesValidas = new Set(
      unidades
        .filter(u => idsAsignaturas.has(u.asignaturaId) && u.visible !== false)
        .map(u => u.id)
    );
    const temasValidos = new Set(
      temas
        .filter(t => unidadesValidas.has(t.unidadId) && t.estado === 'publicado')
        .map(t => t.id)
    );

    return lista.filter(g => temasValidos.has(g.temaId) && g.estado === 'aprobado');
  }

  // Docente
  const unidadesDocente = new Set(
    unidades
      .filter(u => idsAsignaturas.has(u.asignaturaId))
      .map(u => u.id)
  );
  const temasDocente = new Set(
    temas
      .filter(t => unidadesDocente.has(t.unidadId))
      .map(t => t.id)
  );

  return lista.filter(g => temasDocente.has(g.temaId));
}

export async function antesDeGuardar(datos, usuario, anterior) {
  const temaId = datos?.temaId || anterior?.temaId;
  const asignatura = await asignaturaDeTema(temaId);
  const asignaturaId = asignatura ? asignatura.id : null;

  const puede = await puedeEditarAsignatura(usuario, asignaturaId);
  if (!puede) {
    const error = new Error('No tienes permisos para editar el glosario en esta asignatura');
    error.estado = 403;
    throw error;
  }

  return datos;
}

export default {
  filtrarLista,
  antesDeGuardar
};
