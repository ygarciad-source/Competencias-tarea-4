import * as almacen from '../almacen.js';
import { asignaturasDe, asignaturaDeTema, puedeEditarAsignatura } from '../acceso.js';

/**
 * Gancho para la colección "canciones"
 */

export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;

  const misAsignaturas = await asignaturasDe(usuario);
  const idsAsignaturas = new Set(misAsignaturas.map(a => a.id));

  const unidades = await almacen.leer('unidades');
  const temas = await almacen.leer('temas');

  // Mapear cada tema a su asignatura
  const mapaUnidadAsig = new Map(unidades.map(u => [u.id, u.asignaturaId]));
  const mapaTemaAsig = new Map(temas.map(t => [t.id, mapaUnidadAsig.get(t.unidadId)]));

  return lista.filter(c => {
    const asigId = mapaTemaAsig.get(c.temaId);
    return idsAsignaturas.has(asigId);
  });
}

export async function antesDeGuardar(datos, usuario, anterior) {
  if (!usuario) {
    const error = new Error('Autenticación requerida');
    error.estado = 401;
    throw error;
  }

  const temaId = datos?.temaId || anterior?.temaId;
  if (!temaId) {
    const error = new Error('El campo temaId es obligatorio');
    error.estado = 400;
    throw error;
  }

  const asignatura = await asignaturaDeTema(temaId);
  const asignaturaId = asignatura ? asignatura.id : null;

  const puede = await puedeEditarAsignatura(usuario, asignaturaId);
  if (!puede) {
    const error = new Error('No tienes permisos para editar canciones en esta asignatura');
    error.estado = 403;
    throw error;
  }

  return datos;
}

export default {
  filtrarLista,
  antesDeGuardar
};
