/**
 * Gancho para la colección "noticias"
 */

export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];

  // Los estudiantes solo ven noticias publicadas
  if (usuario.rol === 'estudiante') {
    return lista.filter(n => n.estado === 'publicado');
  }

  // Docentes y admin pueden ver borradores y publicadas
  return lista;
}

export async function antesDeGuardar(datos, usuario, anterior) {
  if (!usuario) {
    const error = new Error('Autenticación requerida');
    error.estado = 401;
    throw error;
  }

  // Fija autorId al crear
  if (!anterior || !datos.autorId) {
    datos.autorId = usuario.id;
  }

  // Fija fechaPublicacion cuando el estado pasa a "publicado"
  if (datos.estado === 'publicado') {
    if (!anterior || anterior.estado !== 'publicado' || !anterior.fechaPublicacion) {
      datos.fechaPublicacion = new Date().toISOString();
    }
  }

  return datos;
}

export default {
  filtrarLista,
  antesDeGuardar
};
