import * as almacen from '../almacen.js';
import { estudiantesDe } from '../acceso.js';

/**
 * Gancho para la colección "progreso-temas"
 */

export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;

  if (usuario.rol === 'docente') {
    const misEstudiantes = await estudiantesDe(usuario.id);
    const ids = new Set(misEstudiantes.map(e => e.id));
    ids.add(usuario.id);
    return lista.filter(p => ids.has(p.usuarioId));
  }

  if (usuario.rol === 'estudiante') {
    return lista.filter(p => p.usuarioId === usuario.id);
  }

  return [];
}

export async function antesDeGuardar(datos, usuario, anterior) {
  if (!usuario) {
    const error = new Error('Autenticación requerida');
    error.estado = 401;
    throw error;
  }

  // Fija usuarioId = usuario.id
  datos.usuarioId = usuario.id;

  if (!datos.temaId) {
    const error = new Error('El campo temaId es obligatorio');
    error.estado = 400;
    throw error;
  }

  // Rechaza duplicados (usuarioId + temaId)
  const registros = await almacen.leer('progreso-temas');
  const esDuplicado = registros.some(p =>
    p.usuarioId === datos.usuarioId &&
    p.temaId === datos.temaId &&
    (!anterior || p.id !== anterior.id)
  );

  if (esDuplicado) {
    const error = new Error('Ya existe un registro de progreso para este tema y usuario');
    error.estado = 400;
    throw error;
  }

  return datos;
}

export default {
  filtrarLista,
  antesDeGuardar
};
