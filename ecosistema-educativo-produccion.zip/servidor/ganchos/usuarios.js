import bcrypt from 'bcryptjs';

/**
 * Gancho para la colección "usuarios" (servidor/ganchos/usuarios.js)
 */

export async function filtrarLista(lista, usuario) {
  if (!Array.isArray(lista)) return lista;
  // Nunca exponer claveHash al cliente
  return lista.map(item => {
    const { claveHash, ...limpio } = item;
    return limpio;
  });
}

export async function antesDeGuardar(datos, usuario, anterior) {
  const procesado = { ...datos };

  // Si se proporciona una clave en texto plano, hashearla con bcrypt
  if (procesado.clave && typeof procesado.clave === 'string') {
    procesado.claveHash = await bcrypt.hash(procesado.clave, 10);
    delete procesado.clave;
  }

  // Asegurar formato de correo en minúsculas
  if (procesado.correo && typeof procesado.correo === 'string') {
    procesado.correo = procesado.correo.trim().toLowerCase();
  }

  return procesado;
}

export async function despuesDeGuardar(reg, usuario, anterior) {
  return reg;
}

export default {
  filtrarLista,
  antesDeGuardar,
  despuesDeGuardar
};
