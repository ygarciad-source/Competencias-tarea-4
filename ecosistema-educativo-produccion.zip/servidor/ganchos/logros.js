import { estudiantesDe } from '../acceso.js';

/**
 * Gancho para la colección "logros"
 * El docente ve solo los logros de sus estudiantes.
 * El estudiante ve solo sus propios logros.
 */
export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;

  if (usuario.rol === 'docente') {
    const estudiantes = await estudiantesDe(usuario.id);
    const permitidos = new Set(estudiantes.map(e => e.id));
    permitidos.add(usuario.id);
    return lista.filter(l => permitidos.has(l.usuarioId));
  }

  return lista.filter(l => l.usuarioId === usuario.id);
}

export default {
  filtrarLista
};
