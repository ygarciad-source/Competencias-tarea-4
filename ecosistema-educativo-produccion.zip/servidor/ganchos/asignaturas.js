import { asignaturasDe } from '../acceso.js';

/**
 * Gancho para la colección "asignaturas"
 */

export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;

  const misAsignaturas = await asignaturasDe(usuario);
  const permitidas = new Set(misAsignaturas.map(a => a.id));
  return lista.filter(a => permitidas.has(a.id));
}

export default {
  filtrarLista
};
