import { estudiantesDe } from '../acceso.js';

/**
 * Gancho para la colección "intentos"
 * El docente ve solo los intentos de sus estudiantes.
 * El estudiante ve solo sus propios intentos.
 */
export async function filtrarLista(lista, usuario) {
  if (!usuario) return [];
  if (usuario.rol === 'admin') return lista;

  if (usuario.rol === 'docente') {
    const estudiantes = await estudiantesDe(usuario.id);
    const permitidos = new Set(estudiantes.map(e => e.id));
    permitidos.add(usuario.id);
    return lista.filter(i => permitidos.has(i.usuarioId));
  }

  return lista.filter(i => i.usuarioId === usuario.id);
}

export default {
  filtrarLista
};
