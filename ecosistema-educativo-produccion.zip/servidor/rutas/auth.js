import express from 'express';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import * as almacen from '../almacen.js';

const router = express.Router();

/**
 * Obtiene el token del encabezado Authorization: Bearer <token>
 */
function extraerToken(req) {
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) {
    return auth.slice(7).trim();
  }
  return null;
}

/**
 * POST /api/auth/registro
 * Registra un nuevo usuario, crea sesión y responde { token, usuario }
 */
router.post('/auth/registro', async (req, res, next) => {
  try {
    const { nombre, apellido, correo, clave, consentimiento, rol } = req.body || {};

    if (!nombre || typeof nombre !== 'string' || !nombre.trim()) {
      return res.status(400).json({ error: 'El nombre es obligatorio' });
    }
    if (!apellido || typeof apellido !== 'string' || !apellido.trim()) {
      return res.status(400).json({ error: 'El apellido es obligatorio' });
    }
    if (!correo || typeof correo !== 'string' || !correo.includes('@')) {
      return res.status(400).json({ error: 'El correo electrónico no es válido' });
    }
    if (!clave || typeof clave !== 'string' || clave.length < 6) {
      return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
    }
    const aceptaConsentimiento = Boolean(
      consentimiento === true || (consentimiento && consentimiento.aceptado)
    );
    if (!aceptaConsentimiento) {
      return res.status(400).json({ error: 'Debe aceptar el aviso de privacidad' });
    }

    const correoNorm = correo.trim().toLowerCase();
    const usuarios = await almacen.leer('usuarios');
    const existente = usuarios.find(u => u.correo === correoNorm);
    if (existente) {
      return res.status(400).json({ error: 'El correo electrónico ya está registrado' });
    }

    const claveHash = await bcrypt.hash(clave, 10);
    const nuevoUsuario = {
      nombre: nombre.trim(),
      apellido: apellido.trim(),
      correo: correoNorm,
      claveHash,
      rol: (rol && ['estudiante', 'docente', 'admin'].includes(rol)) ? rol : 'estudiante',
      activo: true,
      foto: null,
      consentimiento: {
        aceptado: true,
        fecha: new Date().toISOString()
      }
    };

    const guardado = await almacen.agregar('usuarios', nuevoUsuario);

    const token = crypto.randomUUID().replace(/-/g, '') + crypto.randomBytes(16).toString('hex');
    const expira = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    await almacen.agregar('sesiones', {
      token,
      usuarioId: guardado.id,
      expira
    });

    const usuarioPublico = {
      id: guardado.id,
      nombre: guardado.nombre,
      apellido: guardado.apellido,
      correo: guardado.correo,
      rol: guardado.rol
    };

    res.status(201).json({ token, usuario: usuarioPublico });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/auth/login
 * Inicia sesión verificando credenciales y responde { token, usuario }
 */
router.post('/auth/login', async (req, res, next) => {
  try {
    const { correo, clave } = req.body || {};

    if (!correo || !clave) {
      return res.status(400).json({ error: 'Correo y contraseña requeridos' });
    }

    const correoNorm = String(correo).trim().toLowerCase();
    const usuarios = await almacen.leer('usuarios');
    const usuario = usuarios.find(u => u.correo === correoNorm);

    if (!usuario) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    if (usuario.activo === false) {
      return res.status(403).json({ error: 'La cuenta se encuentra inactiva' });
    }

    const coincide = await bcrypt.compare(String(clave), usuario.claveHash);
    if (!coincide) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const token = crypto.randomUUID().replace(/-/g, '') + crypto.randomBytes(16).toString('hex');
    const expira = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    await almacen.agregar('sesiones', {
      token,
      usuarioId: usuario.id,
      expira
    });

    const usuarioPublico = {
      id: usuario.id,
      nombre: usuario.nombre,
      apellido: usuario.apellido,
      correo: usuario.correo,
      rol: usuario.rol
    };

    res.json({ token, usuario: usuarioPublico });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/auth/logout
 * Cierra la sesión eliminando el token de la colección de sesiones
 */
router.post('/auth/logout', async (req, res, next) => {
  try {
    const token = extraerToken(req);
    if (token) {
      const sesiones = await almacen.leer('sesiones');
      const sesion = sesiones.find(s => s.token === token);
      if (sesion) {
        await almacen.eliminar('sesiones', sesion.id);
      }
    }
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/auth/yo
 * Devuelve el usuario de la sesión actual
 */
router.get('/auth/yo', async (req, res, next) => {
  try {
    const token = extraerToken(req);
    if (!token) {
      return res.status(401).json({ error: 'Sesión no autorizada' });
    }

    const sesiones = await almacen.leer('sesiones');
    const sesion = sesiones.find(s => s.token === token);
    if (!sesion || new Date(sesion.expira) < new Date()) {
      return res.status(401).json({ error: 'Sesión expirada' });
    }

    const usuarios = await almacen.leer('usuarios');
    const usuario = usuarios.find(u => u.id === sesion.usuarioId);
    if (!usuario || usuario.activo === false) {
      return res.status(401).json({ error: 'Usuario no disponible' });
    }

    res.json({
      id: usuario.id,
      nombre: usuario.nombre,
      apellido: usuario.apellido,
      correo: usuario.correo,
      rol: usuario.rol,
      foto: usuario.foto || null
    });
  } catch (err) {
    next(err);
  }
});

/**
 * PUT /api/auth/perfil
 * Actualiza los datos del perfil del usuario en sesión
 */
router.put('/auth/perfil', async (req, res, next) => {
  try {
    const usuarioSesion = req.usuario;
    if (!usuarioSesion) {
      return res.status(401).json({ error: 'Sesión no autorizada' });
    }

    const { nombre, apellido, foto } = req.body || {};
    const cambios = {};
    if (nombre && typeof nombre === 'string' && nombre.trim()) {
      cambios.nombre = nombre.trim();
    }
    if (apellido && typeof apellido === 'string' && apellido.trim()) {
      cambios.apellido = apellido.trim();
    }
    if (foto !== undefined) {
      cambios.foto = foto;
    }

    const actualizado = await almacen.actualizar('usuarios', usuarioSesion.id, cambios);

    res.json({
      id: actualizado.id,
      nombre: actualizado.nombre,
      apellido: actualizado.apellido,
      correo: actualizado.correo,
      rol: actualizado.rol,
      foto: actualizado.foto || null
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/auth/clave
 * Cambia la contraseña del usuario en sesión tras verificar la actual
 */
router.post('/auth/clave', async (req, res, next) => {
  try {
    const usuarioSesion = req.usuario;
    if (!usuarioSesion) {
      return res.status(401).json({ error: 'Sesión no autorizada' });
    }

    const { claveActual, claveNueva } = req.body || {};
    if (!claveActual || !claveNueva) {
      return res.status(400).json({ error: 'Debe ingresar la contraseña actual y la nueva' });
    }
    if (typeof claveNueva !== 'string' || claveNueva.length < 6) {
      return res.status(400).json({ error: 'La nueva contraseña debe tener al menos 6 caracteres' });
    }

    const usuarios = await almacen.leer('usuarios');
    const usuario = usuarios.find(u => u.id === usuarioSesion.id);
    if (!usuario) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    const coincide = await bcrypt.compare(String(claveActual), usuario.claveHash);
    if (!coincide) {
      return res.status(400).json({ error: 'La contraseña actual no es correcta' });
    }

    const claveHash = await bcrypt.hash(claveNueva, 10);
    await almacen.actualizar('usuarios', usuario.id, { claveHash });

    res.json({ ok: true, mensaje: 'Contraseña actualizada correctamente' });
  } catch (err) {
    next(err);
  }
});

export default router;
