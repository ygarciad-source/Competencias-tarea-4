import express from 'express';
import * as almacen from '../almacen.js';

const router = express.Router();

/**
 * Obtiene el id del usuario desde el token en Authorization: Bearer <token>
 */
async function obtenerUsuarioIdDeToken(req) {
  const auth = req.headers.authorization || '';
  if (!auth.startsWith('Bearer ')) return null;
  const token = auth.slice(7).trim();
  if (!token) return null;

  try {
    const sesiones = await almacen.leer('sesiones');
    const sesion = sesiones.find(s => s.token === token);
    if (sesion && (!sesion.expira || new Date(sesion.expira) > new Date())) {
      return sesion.usuarioId;
    }
  } catch {
    // Silencioso
  }
  return null;
}

/**
 * POST /api/eventos
 * Registra un evento en bitacora.jsonl
 */
router.post('/eventos', async (req, res, next) => {
  try {
    const usuarioId = await obtenerUsuarioIdDeToken(req);
    const tipo = req.body?.tipo || 'pagina';
    const recurso = req.body?.recurso || '';

    const entrada = {
      usuarioId: usuarioId || null,
      tipo: String(tipo),
      recurso: String(recurso),
      fecha: new Date().toISOString()
    };

    await almacen.anexarLinea('bitacora.jsonl', entrada);
    res.status(201).json({ ok: true });
  } catch (err) {
    next(err);
  }
});

export default router;
