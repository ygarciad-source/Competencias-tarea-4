/**
 * Módulo quiz.js (servidor)
 * Motor del quiz formativo para estudiantes según contrato §B, §C, §D y §E.
 */

import express from 'express';
import * as almacen from '../almacen.js';
import * as acceso from '../acceso.js';
import * as gamificacion from '../gamificacion.js';
import { notificar } from '../notificar.js';

const router = express.Router();

const NOMBRES_NIVELES = {
  1: 'Recordar',
  2: 'Comprender',
  3: 'Aplicar',
  4: 'Analizar',
  5: 'Evaluar'
};

/**
 * Normaliza un texto: mayúsculas, sin tildes/diéresis, conserva la Ñ y recorta espacios
 * @param {string} texto
 * @returns {string}
 */
function normalizar(texto) {
  if (texto === null || texto === undefined) return '';
  let s = String(texto).trim();
  if (!s) return '';
  s = s.normalize('NFC').toUpperCase();
  s = s.replace(/Ñ/g, '\u0001');
  s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  s = s.replace(/\u0001/g, 'Ñ');
  return s;
}

/**
 * Baraja aleatoriamente un arreglo (Fisher-Yates)
 * @param {Array} lista
 * @returns {Array}
 */
function barajar(lista) {
  const copia = [...lista];
  for (let i = copia.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

/**
 * Middleware para asegurar que el usuario sea estudiante y tenga acceso al tema solicitado
 */
async function verificarEstudianteConAcceso(req, temaId) {
  if (!req.usuario) {
    const err = new Error('Autenticación requerida');
    err.estado = 401;
    throw err;
  }

  if (req.usuario.rol !== 'estudiante') {
    const err = new Error('Acceso reservado exclusivamente para estudiantes');
    err.estado = 403;
    throw err;
  }

  if (!temaId) {
    const err = new Error('Se requiere temaId');
    err.estado = 400;
    throw err;
  }

  const asignatura = await acceso.asignaturaDeTema(temaId);
  if (!asignatura) {
    const err = new Error('Tema no encontrado');
    err.estado = 404;
    throw err;
  }

  const misAsignaturas = await acceso.asignaturasDe(req.usuario);
  const tieneAcceso = misAsignaturas.some(a => a.id === asignatura.id);
  if (!tieneAcceso) {
    const err = new Error('No tienes acceso a los contenidos de este tema');
    err.estado = 403;
    throw err;
  }

  return { asignatura };
}

/**
 * 1. GET /api/quiz/estado?temaId=
 * Devuelve el estado de los 5 niveles de Bloom para el tema.
 */
router.get('/quiz/estado', async (req, res, next) => {
  try {
    const { temaId } = req.query;
    await verificarEstudianteConAcceso(req, temaId);

    // Cargar logros del usuario para conocer su nivelQuiz en este tema
    const todosLogros = await almacen.leer('logros');
    const miLogro = todosLogros.find(l => l.usuarioId === req.usuario.id);
    const nivelAprobado = Number(miLogro?.nivelQuiz?.[temaId]) || 0;

    // Cargar intentos previos del estudiante en este tema
    const todosIntentos = await almacen.leer('intentos');
    const intentosQuizTema = todosIntentos.filter(i =>
      i.usuarioId === req.usuario.id &&
      i.actividad === 'quiz' &&
      i.temaId === temaId
    );

    const niveles = [];
    for (let n = 1; n <= 5; n++) {
      // Estado del nivel
      let estado = 'bloqueado';
      if (n <= nivelAprobado) {
        estado = 'aprobado';
      } else if (n === 1 || (n - 1) <= nivelAprobado) {
        estado = 'disponible';
      }

      // Mejor porcentaje obtenido en este nivel
      const intentosNivel = intentosQuizTema.filter(i => Number(i.nivel) === n);
      let mejorPorcentaje = 0;
      for (const intento of intentosNivel) {
        const total = Number(intento.maximo) || 0;
        const puntaje = Number(intento.puntaje) || 0;
        if (total > 0) {
          const pct = Math.round((puntaje / total) * 100);
          if (pct > mejorPorcentaje) mejorPorcentaje = pct;
        }
      }

      niveles.push({
        nivel: n,
        nombre: NOMBRES_NIVELES[n] || `Nivel ${n}`,
        estado,
        mejorPorcentaje
      });
    }

    res.json({ niveles });
  } catch (err) {
    if (err.estado) return res.status(err.estado).json({ error: err.message });
    next(err);
  }
});

/**
 * 2. POST /api/quiz/iniciar { temaId, nivel }
 * Inicia una sesión de quiz con preguntas aprobadas y no vistas recientemente.
 */
router.post('/quiz/iniciar', async (req, res, next) => {
  try {
    const { temaId, nivel } = req.body || {};
    const nivelNum = Number(nivel);

    if (!nivelNum || nivelNum < 1 || nivelNum > 5) {
      return res.status(400).json({ error: 'Nivel de quiz inválido (debe ser del 1 al 5)' });
    }

    const { asignatura } = await verificarEstudianteConAcceso(req, temaId);

    // Verificar que el nivel esté disponible o aprobado
    const todosLogros = await almacen.leer('logros');
    const miLogro = todosLogros.find(l => l.usuarioId === req.usuario.id);
    const nivelAprobado = Number(miLogro?.nivelQuiz?.[temaId]) || 0;

    const estaDisponible = nivelNum === 1 || (nivelNum - 1) <= nivelAprobado;
    if (!estaDisponible) {
      return res.status(400).json({ error: 'El nivel solicitado se encuentra bloqueado. Debes aprobar el nivel anterior primero.' });
    }

    // Reglas de gamificación (cantidad de preguntas por nivel)
    const reglas = await almacen.leerConfig('reglas-gamificacion');
    const preguntasPorNivel = reglas.quiz?.preguntasPorNivel || 10;

    // Cargar preguntas aprobadas de este tema y nivel
    const todasPreguntas = await almacen.leer('preguntas');
    const candidatas = todasPreguntas.filter(p =>
      p.temaId === temaId &&
      Number(p.nivel) === nivelNum &&
      p.estado === 'aprobado'
    );

    if (candidatas.length === 0) {
      return res.status(400).json({ error: `No hay preguntas aprobadas registradas para el Nivel ${nivelNum} en este tema.` });
    }

    // Historial de preguntas vistas por el estudiante
    const todasSesiones = await almacen.leer('quiz-sesiones');
    const misSesiones = todasSesiones.filter(s => s.usuarioId === req.usuario.id);

    // Mapear la última vez que el estudiante vio cada pregunta
    const ultimaVistaMap = new Map();
    misSesiones.sort((a, b) => new Date(a.inicio || 0) - new Date(b.inicio || 0));
    for (const sesion of misSesiones) {
      const tiempoInicio = new Date(sesion.inicio || 0).getTime();
      for (const pid of (sesion.preguntasIds || [])) {
        ultimaVistaMap.set(pid, tiempoInicio);
      }
    }

    // Separar no vistas y vistas
    const noVistas = candidatas.filter(p => !ultimaVistaMap.has(p.id));
    const vistas = candidatas.filter(p => ultimaVistaMap.has(p.id));

    let seleccionadas = [];
    let faltaronPreguntasNuevas = false;

    if (noVistas.length >= preguntasPorNivel) {
      seleccionadas = barajar(noVistas).slice(0, preguntasPorNivel);
    } else {
      faltaronPreguntasNuevas = true;
      seleccionadas = [...barajar(noVistas)];
      const faltantes = preguntasPorNivel - seleccionadas.length;

      // Ordenar las vistas por las vistas hace más tiempo (menor timestamp)
      vistas.sort((a, b) => ultimaVistaMap.get(a.id) - ultimaVistaMap.get(b.id));
      seleccionadas.push(...vistas.slice(0, faltantes));
    }

    // Si no alcanzaron las preguntas nuevas, notificar al docente del grupo (máx 1 vez al día)
    if (faltaronPreguntasNuevas) {
      try {
        const grupos = await acceso.gruposDe(req.usuario);
        const grupoTema = grupos.find(g => g.asignaturaId === asignatura.id);
        const docenteId = grupoTema?.docenteId;

        if (docenteId) {
          const hoyIso = new Date().toISOString().slice(0, 10);
          const notificaciones = await almacen.leer('notificaciones');
          const yaNotificadoHoy = notificaciones.some(n =>
            n.usuarioId === docenteId &&
            n.tipo === 'banco-preguntas' &&
            (n.fecha || '').slice(0, 10) === hoyIso &&
            n.mensaje?.includes(`Nivel ${nivelNum}`) &&
            n.enlace?.includes(temaId)
          );

          if (!yaNotificadoHoy) {
            const temas = await almacen.leer('temas');
            const temaObj = temas.find(t => t.id === temaId);
            await notificar(docenteId, {
              tipo: 'banco-preguntas',
              mensaje: `El banco de preguntas para el tema "${temaObj?.titulo || temaId}" (Nivel ${nivelNum}) se ha agotado para algunos estudiantes. Se recomienda generar o agregar más preguntas.`,
              enlace: `/paginas/editor-tema.html?id=${encodeURIComponent(temaId)}`
            });
          }
        }
      } catch (errNotif) {
        console.error('Error al emitir notificación a docente:', errNotif);
      }
    }

    // Crear la quiz-sesión en la colección "quiz-sesiones"
    const nuevaSesion = {
      usuarioId: req.usuario.id,
      temaId,
      nivel: nivelNum,
      preguntasIds: seleccionadas.map(p => p.id),
      respuestas: {},
      inicio: new Date().toISOString(),
      finalizada: false
    };

    const sesionCreada = await almacen.agregar('quiz-sesiones', nuevaSesion);

    // Devolver preguntas SIN respuestas ni retroalimentación
    const preguntasParaEstudiante = seleccionadas.map(p => ({
      id: p.id,
      tipo: p.tipo || 'opcion',
      enunciado: p.enunciado,
      opciones: Array.isArray(p.opciones) ? p.opciones : []
    }));

    res.status(201).json({
      sesionId: sesionCreada.id,
      preguntas: preguntasParaEstudiante
    });
  } catch (err) {
    if (err.estado) return res.status(err.estado).json({ error: err.message });
    next(err);
  }
});

/**
 * 3. POST /api/quiz/responder { sesionId, preguntaId, respuesta }
 * Guarda una sola vez la respuesta a una pregunta y evalúa su corrección.
 */
router.post('/quiz/responder', async (req, res, next) => {
  try {
    if (!req.usuario) {
      return res.status(401).json({ error: 'Autenticación requerida' });
    }

    const { sesionId, preguntaId, respuesta } = req.body || {};

    if (!sesionId || !preguntaId || respuesta === undefined || respuesta === null) {
      return res.status(400).json({ error: 'Faltan parámetros requeridos (sesionId, preguntaId, respuesta)' });
    }

    const sesiones = await almacen.leer('quiz-sesiones');
    const sesion = sesiones.find(s => s.id === sesionId);

    if (!sesion) {
      return res.status(404).json({ error: 'Sesión de quiz no encontrada' });
    }

    if (sesion.usuarioId !== req.usuario.id) {
      return res.status(403).json({ error: 'No autorizado para responder en esta sesión' });
    }

    if (sesion.finalizada) {
      return res.status(400).json({ error: 'La sesión de quiz ya ha sido finalizada' });
    }

    if (!Array.isArray(sesion.preguntasIds) || !sesion.preguntasIds.includes(preguntaId)) {
      return res.status(400).json({ error: 'La pregunta no forma parte de esta sesión de quiz' });
    }

    sesion.respuestas = sesion.respuestas && typeof sesion.respuestas === 'object' ? sesion.respuestas : {};

    // Guarda una sola vez por pregunta
    if (sesion.respuestas[preguntaId] !== undefined) {
      return res.status(400).json({ error: 'Esta pregunta ya fue respondida anteriormente en esta sesión' });
    }

    // Cargar la pregunta original
    const todasPreguntas = await almacen.leer('preguntas');
    const pregunta = todasPreguntas.find(p => p.id === preguntaId);
    if (!pregunta) {
      return res.status(404).json({ error: 'Pregunta no encontrada' });
    }

    // Evaluar corrección
    let correcto = false;
    let textoCorrecta = '';

    const tipo = pregunta.tipo || 'opcion';

    if (tipo === 'opcion') {
      const idxCorrecto = typeof pregunta.correcta === 'number' ? pregunta.correcta : parseInt(pregunta.correcta, 10);
      textoCorrecta = Array.isArray(pregunta.opciones) && idxCorrecto >= 0 && idxCorrecto < pregunta.opciones.length
        ? pregunta.opciones[idxCorrecto]
        : String(pregunta.correcta);

      if (typeof respuesta === 'number') {
        correcto = respuesta === idxCorrecto;
      } else {
        // Puede responder con el índice numérico en string o con el texto exacto
        correcto = respuesta === String(idxCorrecto) || respuesta === textoCorrecta;
      }
    } else if (tipo === 'vf') {
      const valorEsperado = pregunta.correcta === true || String(pregunta.correcta).toLowerCase() === 'verdadero' || String(pregunta.correcta).toLowerCase() === 'true';
      const valorDado = respuesta === true || String(respuesta).toLowerCase() === 'verdadero' || String(respuesta).toLowerCase() === 'true';
      correcto = valorEsperado === valorDado;
      textoCorrecta = valorEsperado ? 'Verdadero' : 'Falso';
    } else if (tipo === 'completar') {
      // En "completar" compara con normalizar()
      correcto = normalizar(respuesta) === normalizar(pregunta.correcta);
      textoCorrecta = String(pregunta.correcta);
    } else {
      correcto = String(respuesta).trim().toLowerCase() === String(pregunta.correcta).trim().toLowerCase();
      textoCorrecta = String(pregunta.correcta);
    }

    // Registrar respuesta en la sesión
    sesion.respuestas[preguntaId] = {
      respuesta,
      correcto,
      fecha: new Date().toISOString()
    };

    await almacen.actualizar('quiz-sesiones', sesion.id, { respuestas: sesion.respuestas });

    res.json({
      correcto,
      retroalimentacion: pregunta.retroalimentacion || '',
      correcta: textoCorrecta
    });
  } catch (err) {
    if (err.estado) return res.status(err.estado).json({ error: err.message });
    next(err);
  }
});

/**
 * 4. POST /api/quiz/finalizar { sesionId }
 * Finaliza la sesión, calcula porcentaje y evalúa aprobación.
 */
router.post('/quiz/finalizar', async (req, res, next) => {
  try {
    if (!req.usuario) {
      return res.status(401).json({ error: 'Autenticación requerida' });
    }

    const { sesionId } = req.body || {};
    if (!sesionId) {
      return res.status(400).json({ error: 'Se requiere sesionId' });
    }

    const sesiones = await almacen.leer('quiz-sesiones');
    const sesion = sesiones.find(s => s.id === sesionId);

    if (!sesion) {
      return res.status(404).json({ error: 'Sesión de quiz no encontrada' });
    }

    if (sesion.usuarioId !== req.usuario.id) {
      return res.status(403).json({ error: 'No autorizado para finalizar esta sesión' });
    }

    if (sesion.finalizada) {
      return res.status(400).json({ error: 'La sesión de quiz ya fue finalizada' });
    }

    // Cargar preguntas para verificar
    const todasPreguntas = await almacen.leer('preguntas');
    const preguntasSesion = (sesion.preguntasIds || []).map(pid => todasPreguntas.find(p => p.id === pid)).filter(Boolean);

    const total = sesion.preguntasIds.length;
    const respuestas = sesion.respuestas || {};

    let aciertos = 0;
    const repasar = [];

    for (const preg of preguntasSesion) {
      const resp = respuestas[preg.id];
      if (resp && resp.correcto === true) {
        aciertos++;
      } else {
        repasar.push({
          preguntaId: preg.id,
          enunciado: preg.enunciado,
          retroalimentacion: preg.retroalimentacion || 'Repasa los conceptos clave del tema.'
        });
      }
    }

    const errores = total - aciertos;
    const porcentaje = total > 0 ? Math.round((aciertos / total) * 100) : 0;

    // Reglas de gamificación (porcentaje de aprobación)
    const reglas = await almacen.leerConfig('reglas-gamificacion');
    const porcentajeAprobacion = reglas.quiz?.porcentajeAprobacion || 70;
    const aprobado = porcentaje >= porcentajeAprobacion;

    // Si aprueba, primero actualiza logros.nivelQuiz[temaId] al máximo
    if (aprobado) {
      const todosLogros = await almacen.leer('logros');
      let logro = todosLogros.find(l => l.usuarioId === req.usuario.id);
      if (!logro) {
        logro = {
          usuarioId: req.usuario.id,
          puntos: 0,
          insignias: [],
          nivelQuiz: {}
        };
      }

      logro.nivelQuiz = logro.nivelQuiz && typeof logro.nivelQuiz === 'object' ? logro.nivelQuiz : {};
      const nivelActual = Number(logro.nivelQuiz[sesion.temaId]) || 0;
      logro.nivelQuiz[sesion.temaId] = Math.max(nivelActual, Number(sesion.nivel));

      if (logro.id) {
        await almacen.actualizar('logros', logro.id, { nivelQuiz: logro.nivelQuiz });
      } else {
        await almacen.agregar('logros', logro);
      }
    }

    // Duración en segundos
    const inicioMs = new Date(sesion.inicio || 0).getTime();
    const duracionSeg = inicioMs > 0 ? Math.max(0, Math.round((Date.now() - inicioMs) / 1000)) : 0;

    // En todos los casos llama a procesarIntento
    const resultadoIntento = await gamificacion.procesarIntento(req.usuario, {
      actividad: 'quiz',
      temaId: sesion.temaId,
      nivel: sesion.nivel,
      puntaje: aciertos,
      maximo: total,
      errores,
      duracionSeg,
      detalle: { aprobado }
    });

    // Marcar sesión como finalizada
    await almacen.actualizar('quiz-sesiones', sesion.id, {
      finalizada: true,
      fin: new Date().toISOString()
    });

    res.json({
      porcentaje,
      aprobado,
      aciertos,
      total,
      repasar,
      puntosGanados: resultadoIntento.puntosGanados,
      insigniasNuevas: resultadoIntento.insigniasNuevas
    });
  } catch (err) {
    if (err.estado) return res.status(err.estado).json({ error: err.message });
    next(err);
  }
});

export default router;
