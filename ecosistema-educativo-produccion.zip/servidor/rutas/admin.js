import express from 'express';
import bcrypt from 'bcryptjs';
import * as almacen from '../almacen.js';
import { exigirRol } from '../auth.js';

const router = express.Router();

/**
 * POST /api/admin/usuarios/:id/restablecer
 * Restablece la contraseña de un usuario (solo para rol admin)
 */
router.post('/admin/usuarios/:id/restablecer', exigirRol('admin'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { clave } = req.body || {};

    const usuarios = await almacen.leer('usuarios');
    const usuario = usuarios.find(u => u.id === id);
    if (!usuario) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    const nuevaClave = clave || 'Temporal123!';
    const claveHash = await bcrypt.hash(nuevaClave, 10);

    await almacen.actualizar('usuarios', id, { claveHash });

    res.json({
      ok: true,
      mensaje: 'Contraseña restablecida exitosamente',
      claveTemporal: clave ? undefined : nuevaClave
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/admin/ajustes
 * Obtiene la configuración general del sistema y de la IA
 */
router.get('/admin/ajustes', exigirRol('admin'), async (req, res, next) => {
  try {
    const ajustes = await almacen.leerConfig('ajustes');
    res.json(ajustes);
  } catch (err) {
    next(err);
  }
});

/**
 * PUT /api/admin/ajustes
 * Actualiza la configuración de la plataforma y parámetros de IA (clave, modelo, límites)
 */
router.put('/admin/ajustes', exigirRol('admin'), async (req, res, next) => {
  try {
    const actuales = await almacen.leerConfig('ajustes');
    const nuevosAjustes = {
      ...actuales,
      ...(req.body || {})
    };

    // Actualizar archivo ajustes.json
    await almacen.escribirConfig('ajustes', nuevosAjustes);

    // Sincronizar variables de proceso en caliente
    if (nuevosAjustes.iaClave) process.env.IA_CLAVE = nuevosAjustes.iaClave;
    if (nuevosAjustes.iaModelo) process.env.IA_MODELO = nuevosAjustes.iaModelo;
    if (nuevosAjustes.iaProveedor) process.env.IA_PROVEEDOR = nuevosAjustes.iaProveedor;

    res.json({
      ok: true,
      mensaje: 'Ajustes guardados correctamente',
      ajustes: nuevosAjustes
    });
  } catch (err) {
    next(err);
  }
});

export default router;

