import express from 'express';
import multer from 'multer';
import crypto from 'node:crypto';
import path from 'node:path';
import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import * as almacen from '../almacen.js';

const router = express.Router();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIR_SUBIDAS = path.resolve(__dirname, '../../publico/recursos/subidas');

// Asegurar que exista la carpeta publico/recursos/subidas/
try {
  await fs.mkdir(DIR_SUBIDAS, { recursive: true });
} catch {
  // Ignorar si ya existe
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR_SUBIDAS);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const aleatorio = `${crypto.randomUUID().replace(/-/g, '')}${ext}`;
    cb(null, aleatorio);
  }
});

const manejarSubida = async (req, res) => {
  const usuario = req.usuario;
  const esDocenteOAdmin = Boolean(usuario && (usuario.rol === 'docente' || usuario.rol === 'admin'));

  const ajustes = await almacen.leerConfig('ajustes');
  const maxDocenteAdminMB = Number(ajustes?.maxSubidaMB) || 10;
  const maxBytes = esDocenteOAdmin ? maxDocenteAdminMB * 1024 * 1024 : 2 * 1024 * 1024;

  const extensionesPermitidas = esDocenteOAdmin
    ? new Set(['.jpg', '.jpeg', '.png', '.webp', '.pdf', '.mp3'])
    : new Set(['.jpg', '.jpeg', '.png', '.webp']);

  const mimetypesPermitidos = esDocenteOAdmin
    ? new Set(['image/jpeg', 'image/png', 'image/webp', 'application/pdf', 'audio/mpeg', 'audio/mp3'])
    : new Set(['image/jpeg', 'image/png', 'image/webp']);

  const uploadInstance = multer({
    storage,
    limits: {
      fileSize: maxBytes
    },
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      if (!extensionesPermitidas.has(ext) || !mimetypesPermitidos.has(file.mimetype)) {
        const mensaje = esDocenteOAdmin
          ? 'Solo se permiten imágenes (JPG, PNG, WEBP), documentos PDF o audios MP3'
          : 'Solo se permiten imágenes JPG, PNG o WEBP';
        const err = new Error(mensaje);
        err.estado = 400;
        return cb(err);
      }
      cb(null, true);
    }
  });

  uploadInstance.single('archivo')(req, res, (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        const limiteMB = esDocenteOAdmin ? maxDocenteAdminMB : 2;
        return res.status(400).json({ error: `El archivo excede el límite máximo permitido de ${limiteMB} MB` });
      }
      return res.status(err.estado || 400).json({ error: err.message || 'Error al procesar la subida' });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'No se envió ningún archivo en el campo "archivo"' });
    }

    const url = `/recursos/subidas/${req.file.filename}`;
    res.json({ url });
  });
};

router.post('/subidas', manejarSubida);
router.post('/api/subidas', manejarSubida);

export default router;
