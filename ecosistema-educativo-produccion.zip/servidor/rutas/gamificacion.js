import express from 'express';
import * as almacen from '../almacen.js';
import { estudiantesDe } from '../acceso.js';
import { procesarIntento } from '../gamificacion.js';

const router = express.Router();

/**
 * POST /api/intentos
 * Registra un intento de actividad y calcula sus puntos e insignias ganadas.
 */
router.post('/intentos', async (req, res, next) => {
  try {
    if (!req.usuario) {
      return res.status(401).json({ error: 'Autenticación requerida' });
    }

    const resultado = await procesarIntento(req.usuario, req.body);
    res.status(201).json(resultado);
  } catch (err) {
    if (err.estado) {
      return res.status(err.estado).json({ error: err.message });
    }
    next(err);
  }
});

/**
 * GET /api/logros/:usuarioId
 * Obtiene el registro de logros (puntos, insignias, nivelQuiz) de un usuario.
 * ":usuarioId" puede ser "yo" para el usuario autenticado.
 * Permitido al propio estudiante, a un docente de sus grupos o al admin.
 */
router.get('/logros/:usuarioId', async (req, res, next) => {
  try {
    if (!req.usuario) {
      return res.status(401).json({ error: 'Autenticación requerida' });
    }

    const { usuarioId } = req.params;
    const targetId = usuarioId === 'yo' ? req.usuario.id : usuarioId;

    // Control de permisos
    let permitido = false;

    if (req.usuario.id === targetId) {
      permitido = true;
    } else if (req.usuario.rol === 'admin') {
      permitido = true;
    } else if (req.usuario.rol === 'docente') {
      const estudiantes = await estudiantesDe(req.usuario.id);
      permitido = estudiantes.some(e => e.id === targetId);
    }

    if (!permitido) {
      return res.status(403).json({ error: 'Acceso no autorizado a los logros de este usuario' });
    }

    const todosLogros = await almacen.leer('logros');
    const logro = todosLogros.find(l => l.usuarioId === targetId);

    if (!logro) {
      return res.json({
        usuarioId: targetId,
        puntos: 0,
        insignias: [],
        nivelQuiz: {}
      });
    }

    res.json(logro);
  } catch (err) {
    next(err);
  }
});

export default router;
