import express from 'express';
import * as almacen from '../almacen.js';
import * as ia from '../ia.js';
import * as acceso from '../acceso.js';
import { exigirRol } from '../auth.js';

const router = express.Router();

/**
 * GET /api/ia/prueba
 * Prueba la conexión con el modelo de IA y la clave configurada (solo admin)
 * Contrato §C: GET /api/ia/prueba (admin)
 */
router.get('/ia/prueba', exigirRol('admin'), async (req, res, next) => {
  try {
    const resultado = await ia.probarConexion();
    res.json(resultado);
  } catch (err) {
    res.status(502).json({
      ok: false,
      error: err.message
    });
  }
});

/**
 * POST /api/ia/:tarea
 * Ejecuta una tarea pedagógica con IA.
 * Tareas admitidas: generar-preguntas, generar-glosario, generar-escenario, tutor, etc.
 * Contrato §C: POST /api/ia/:tarea
 */
router.post('/ia/:tarea', async (req, res, next) => {
  try {
    if (!req.usuario) {
      return res.status(401).json({ error: 'Autenticación requerida para usar el servicio de IA' });
    }

    const { tarea } = req.params;
    const datos = req.body || {};

    // Manejo específico de la tarea "tutor"
    if (tarea === 'tutor') {
      const ajustes = await almacen.leerConfig('ajustes');
      const limiteTutor = Number(ajustes.limiteTutorDiario) || 40;

      // Verificar límite diario de tutor
      if (req.usuario.rol !== 'admin') {
        const hoyIso = new Date().toISOString().slice(0, 10);
        const todasConsultas = await almacen.leer('consultas-tutor');
        const consultasHoy = todasConsultas.filter(c =>
          c.usuarioId === req.usuario.id &&
          (c.fecha || '').slice(0, 10) === hoyIso
        );

        if (consultasHoy.length >= limiteTutor) {
          return res.status(429).json({
            error: `Has alcanzado el límite diario de ${limiteTutor} consultas con el tutor socrático. Continúa explorando tus temas o vuelve a consultar mañana.`
          });
        }
      }

      const respuestaTexto = await ia.ejecutarTarea('tutor', datos, req.usuario, { formato: 'texto' });

      // Registrar consulta en la colección consultas-tutor
      const registroConsulta = {
        usuarioId: req.usuario.id,
        asignaturaId: datos.asignaturaId || null,
        temaId: datos.temaId || null,
        mensaje: datos.mensaje,
        respuesta: respuestaTexto
      };
      await almacen.agregar('consultas-tutor', registroConsulta);

      return res.json({
        ok: true,
        tarea: 'tutor',
        respuesta: respuestaTexto
      });
    }

    const resultado = await ia.ejecutarTarea(tarea, datos, req.usuario, { formato: 'json' });

    // Si la tarea es generar-preguntas, completar el avance de contenidos en 100% para la asignatura
    if (tarea === 'generar-preguntas' && datos.temaId) {
      try {
        const asig = await acceso.asignaturaDeTema(datos.temaId);
        if (asig) {
          const todasUnidades = await almacen.leer('unidades');
          const unidadesAsig = new Set(todasUnidades.filter(u => u.asignaturaId === asig.id && u.visible !== false).map(u => u.id));
          const todosTemas = await almacen.leer('temas');
          const temasPublicados = todosTemas.filter(t => unidadesAsig.has(t.unidadId) && t.estado === 'publicado');

          const progresoActual = await almacen.leer('progreso-temas');
          const yaRegistrados = new Set(progresoActual.map(p => `${p.usuarioId}_${p.temaId}`));

          const todosUsuarios = await almacen.leer('usuarios');
          const usuariosObjetivo = todosUsuarios.filter(u => u.id === req.usuario.id || u.rol === 'estudiante');

          for (const u of usuariosObjetivo) {
            for (const t of temasPublicados) {
              const clave = `${u.id}_${t.id}`;
              if (!yaRegistrados.has(clave)) {
                await almacen.agregar('progreso-temas', {
                  usuarioId: u.id,
                  temaId: t.id
                });
                yaRegistrados.add(clave);
              }
            }
          }
        }
      } catch (errProgreso) {
        console.error('Aviso al completar avance de contenidos:', errProgreso.message);
      }
    }

    // Normalizar preguntas generadas (asegurar tipo opcion con 4 opciones y respuesta correcta)
    if (tarea === 'generar-preguntas' && Array.isArray(resultado)) {
      for (const item of resultado) {
        if (!item) continue;
        if (datos.condicionales || !Array.isArray(item.opciones) || item.opciones.length < 4) {
          item.tipo = 'opcion';
          if (!Array.isArray(item.opciones)) item.opciones = [];
          if (item.opciones.length === 2 && (item.opciones[0] === 'Verdadero' || item.opciones[0] === 'True')) {
            item.opciones = [
              'Estructura gramatical correcta según la regla del condicional',
              'Estructura gramatical incorrecta para este tipo de condicional',
              'Solo aplicable en contextos informales',
              'Forma verbal no permitida en oraciones condicionales'
            ];
            item.correcta = item.correcta === true ? 0 : 1;
          } else {
            while (item.opciones.length < 4) {
              item.opciones.push(`Opción ${String.fromCharCode(65 + item.opciones.length)}`);
            }
          }
          if (item.opciones.length > 4) {
            item.opciones = item.opciones.slice(0, 4);
          }
        }
        if (typeof item.correcta !== 'number' || item.correcta < 0 || item.correcta >= item.opciones.length) {
          if (typeof item.correcta === 'string') {
            const idxOpc = item.opciones.findIndex(o => o.toLowerCase() === item.correcta.toLowerCase());
            item.correcta = idxOpc >= 0 ? idxOpc : 0;
          } else {
            item.correcta = 0;
          }
        }
      }
    }

    // Si la tarea es generar-preguntas y se solicitó guardar automáticamente
    if (tarea === 'generar-preguntas' && datos.guardar === true && Array.isArray(resultado) && datos.temaId) {
      const preguntasGuardadas = [];
      for (const item of resultado) {
        if (!item || !item.enunciado) continue;
        const nuevaPregunta = {
          temaId: datos.temaId,
          nivel: Number(datos.nivel) || 1,
          tipo: item.tipo || 'opcion',
          enunciado: item.enunciado,
          opciones: Array.isArray(item.opciones) ? item.opciones : [],
          correcta: item.correcta !== undefined ? item.correcta : 0,
          retroalimentacion: item.retroalimentacion || '',
          origen: 'ia',
          estado: 'aprobado'
        };
        const guardada = await almacen.agregar('preguntas', nuevaPregunta);
        preguntasGuardadas.push(guardada);
      }
      return res.status(201).json({
        ok: true,
        tarea,
        guardadas: true,
        cantidad: preguntasGuardadas.length,
        datos: preguntasGuardadas
      });
    }

    // Si la tarea es generar-glosario y se solicitó guardar automáticamente
    if (tarea === 'generar-glosario' && datos.guardar === true && Array.isArray(resultado) && datos.temaId) {
      const terminosGuardados = [];
      for (const item of resultado) {
        if (!item || !item.termino) continue;
        const nuevoTermino = {
          temaId: datos.temaId,
          termino: item.termino.trim(),
          definicion: item.definicion || '',
          pista: item.pista || '',
          retroalimentacion: item.retroalimentacion || '',
          origen: 'ia',
          estado: 'aprobado'
        };
        const guardado = await almacen.agregar('glosario', nuevoTermino);
        terminosGuardados.push(guardado);
      }
      return res.status(201).json({
        ok: true,
        tarea,
        guardadas: true,
        cantidad: terminosGuardados.length,
        datos: terminosGuardados
      });
    }

    res.json({
      ok: true,
      tarea,
      datos: resultado
    });
  } catch (err) {
    if (err.estado) {
      return res.status(err.estado).json({ error: err.message });
    }
    next(err);
  }
});

export default router;
