import fs from 'node:fs/promises';
import path from 'node:path';
import readline from 'node:readline/promises';
import { fileURLToPath } from 'node:url';
import bcrypt from 'bcryptjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIR_RAIZ = path.resolve(__dirname, '..');
const DIR_DATOS = path.join(DIR_RAIZ, 'datos');
const DIR_SEMILLA = path.join(DIR_DATOS, 'semilla');

const CLAVE_PREDETERMINADA = 'Demo12345';

async function ejecutarSemilla() {
  const forzar = process.argv.includes('--forzar');

  if (forzar) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    try {
      const respuesta = await rl.question('¿Estás seguro de que deseas reemplazar las colecciones con los datos semilla? (s/n): ');
      const confirmacion = respuesta.trim().toLowerCase();
      if (confirmacion !== 's' && confirmacion !== 'si' && confirmacion !== 'y' && confirmacion !== 'yes') {
        console.log('Operación cancelada por el usuario.');
        return;
      }
    } finally {
      rl.close();
    }
  }

  // Asegurar existencia de directorios
  await fs.mkdir(DIR_DATOS, { recursive: true });
  await fs.mkdir(DIR_SEMILLA, { recursive: true });

  const archivos = await fs.readdir(DIR_SEMILLA);
  const archivosJson = archivos.filter(f => f.endsWith('.json')).sort();

  if (archivosJson.length === 0) {
    console.log('No se encontraron archivos en datos/semilla/.');
    return;
  }

  console.log(`Iniciando proceso de semilla${forzar ? ' con reemplazo forzado' : ''}...`);

  for (const archivo of archivosJson) {
    const rutaOrigen = path.join(DIR_SEMILLA, archivo);
    const rutaDestino = path.join(DIR_DATOS, archivo);

    let existeDestino = false;
    try {
      await fs.access(rutaDestino);
      existeDestino = true;
    } catch {
      existeDestino = false;
    }

    if (existeDestino && !forzar) {
      console.log(`ℹ Colección "${archivo}" ya existe en datos/, omitiendo.`);
      continue;
    }

    const contenidoRaw = await fs.readFile(rutaOrigen, 'utf-8');
    let datos = JSON.parse(contenidoRaw);

    // Si es usuarios.json, generar claveHash con la clave "Demo12345" para todos
    if (archivo === 'usuarios.json' && Array.isArray(datos)) {
      const claveHashComun = await bcrypt.hash(CLAVE_PREDETERMINADA, 10);
      datos = datos.map(usuario => ({
        ...usuario,
        claveHash: claveHashComun
      }));
    }

    // Guardar archivo en formato JSON compacto / limpio
    await fs.writeFile(rutaDestino, JSON.stringify(datos, null, 2), 'utf-8');
    console.log(`✔ Colección "${archivo}" ${existeDestino ? 'reemplazada' : 'creada'} exitosamente en datos/.`);
  }

  console.log('Proceso de semilla completado con éxito.');
}

ejecutarSemilla().catch(err => {
  console.error('Error durante la ejecución de semilla:', err);
  process.exit(1);
});
