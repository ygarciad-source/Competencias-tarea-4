import * as almacen from '../almacen.js';
import * as acceso from '../acceso.js';

/**
 * Preparador de datos para la plantilla del tutor socrático (tutor.txt)
 * Contrato §B: preparadores/<tarea>.js
 * @param {object} cuerpo - { asignaturaId, temaId, mensaje, historial }
 * @param {object} usuario
 * @returns {Promise<object>} Variables para sustitución en prompt
 */
export default async function prepararTutor(cuerpo = {}, usuario = null) {
  const { asignaturaId, temaId, mensaje, historial = [] } = cuerpo;

  if (!mensaje || !String(mensaje).trim()) {
    const error = new Error('Se requiere un mensaje para consultar al tutor');
    error.estado = 400;
    throw error;
  }

  // Resolver la asignatura
  let asignatura = null;
  if (asignaturaId) {
    const todasAsig = await almacen.leer('asignaturas');
    asignatura = todasAsig.find(a => a.id === asignaturaId);
  } else if (temaId) {
    asignatura = await acceso.asignaturaDeTema(temaId);
  }

  if (!asignatura) {
    const todasAsig = await almacen.leer('asignaturas');
    asignatura = todasAsig[0] || { id: 'asig_000001', nombre: 'Competencias Digitales y Estrategias Tecnológicas', nivel: 'Educación Superior' };
  }

  // Cargar unidades visibles y temas publicados de la asignatura
  const todasUnidades = await almacen.leer('unidades');
  const unidadesAsig = todasUnidades.filter(u => u.asignaturaId === asignatura.id && u.visible !== false);
  const idsUnidades = new Set(unidadesAsig.map(u => u.id));

  const todosTemas = await almacen.leer('temas');
  const temasAsig = todosTemas.filter(t => idsUnidades.has(t.unidadId) && t.estado === 'publicado');

  const todosGlosario = await almacen.leer('glosario');

  // Compilar contenidos curriculares detallados
  const bloquesContenido = [];

  for (const tema of temasAsig) {
    const glosarioTema = todosGlosario
      .filter(g => g.temaId === tema.id)
      .map(g => `  • ${g.termino}: ${g.definicion}`)
      .slice(0, 10);

    const textoTema = [
      `### Tema: ${tema.titulo}`,
      tema.resumen ? `Resumen conceptual:\n${tema.resumen}` : '',
      Array.isArray(tema.objetivos) && tema.objetivos.length > 0
        ? `Objetivos pedagógicos:\n- ${tema.objetivos.join('\n- ')}`
        : '',
      Array.isArray(tema.ejemplos) && tema.ejemplos.length > 0
        ? `Ejemplos de aplicación:\n- ${tema.ejemplos.join('\n- ')}`
        : '',
      glosarioTema.length > 0 ? `Vocabulario clave:\n${glosarioTema.join('\n')}` : ''
    ].filter(Boolean).join('\n\n');

    bloquesContenido.push(textoTema);
  }

  const temasYContenidos = bloquesContenido.join('\n\n--------------------\n\n') ||
    'Contenidos pedagógicos generales de competencias digitales (DigCompEdu y UNESCO TIC).';

  // Formatear historial reciente (últimos 6 mensajes)
  let historialTexto = 'Inicio de la conversación.';
  if (Array.isArray(historial) && historial.length > 0) {
    const ultimos = historial.slice(-6);
    historialTexto = ultimos.map(m => {
      const remitente = m.rol === 'usuario' || m.rol === 'estudiante' ? '[Estudiante]' : '[Tutor Socrático]';
      return `${remitente}: ${m.texto}`;
    }).join('\n');
  }

  return {
    asignatura: asignatura.nombre,
    nivel: asignatura.nivel || 'Educación Superior',
    temasYContenidos,
    historial: historialTexto,
    mensaje: String(mensaje).trim()
  };
}
