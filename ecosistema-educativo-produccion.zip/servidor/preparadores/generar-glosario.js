import * as almacen from '../almacen.js';
import * as acceso from '../acceso.js';

/**
 * Preparador de datos para la plantilla de prompt generar-glosario.txt
 * Contrato §B: preparadores/<tarea>.js
 * @param {object} cuerpo - { temaId, cantidad, minimoSeisLetras }
 * @param {object} usuario
 * @returns {Promise<object>} Variables para sustitución en prompt
 */
export default async function prepararGenerarGlosario(cuerpo = {}, usuario = null) {
  const { temaId, cantidad = 5, minimoSeisLetras = 2 } = cuerpo;

  if (!temaId) {
    const error = new Error('Se requiere temaId para generar glosario');
    error.estado = 400;
    throw error;
  }

  const temas = await almacen.leer('temas');
  const tema = temas.find(t => t.id === temaId);
  if (!tema) {
    const error = new Error(`Tema "${temaId}" no encontrado`);
    error.estado = 404;
    throw error;
  }

  // Asignatura
  const asig = await acceso.asignaturaDeTema(temaId);

  // Términos existentes
  const todosGlosario = await almacen.leer('glosario');
  const terminosExistentes = todosGlosario
    .filter(g => g.temaId === temaId)
    .map(g => g.termino);
  const existentesTexto = terminosExistentes.length > 0
    ? terminosExistentes.join(', ')
    : 'Ninguno registrado aún';

  // Contenido
  const contenido = [
    tema.resumen ? `Resumen:\n${tema.resumen}` : '',
    Array.isArray(tema.objetivos) ? `Objetivos:\n${tema.objetivos.join('; ')}` : '',
    Array.isArray(tema.palabrasClave) ? `Palabras clave sugeridas:\n${tema.palabrasClave.join(', ')}` : ''
  ].filter(Boolean).join('\n\n') || 'Contenido del tema.';

  return {
    asignatura: asig?.nombre || 'Competencias Digitales',
    nivel: asig?.nivel || 'Educación Superior',
    tema: tema.titulo,
    contenido,
    existentes: existentesTexto,
    cantidad: Math.min(Math.max(Number(cantidad) || 5, 1), 15),
    minimoSeisLetras: Number(minimoSeisLetras) || 2
  };
}
