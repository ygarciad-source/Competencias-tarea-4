import * as almacen from '../almacen.js';
import * as acceso from '../acceso.js';

/**
 * Preparador de datos para la plantilla de prompt generar-preguntas.txt
 * Contrato §B: preparadores/<tarea>.js
 * @param {object} cuerpo - { temaId, cantidad, nivelBloom, nivel }
 * @param {object} usuario
 * @returns {Promise<object>} Variables para sustitución en prompt
 */
export default async function prepararGenerarPreguntas(cuerpo = {}, usuario = null) {
  const { temaId, cantidad = 5, nivelBloom = 'Recordar y Comprender' } = cuerpo;

  if (!temaId) {
    const error = new Error('Se requiere temaId para generar preguntas');
    error.estado = 400;
    throw error;
  }

  const temas = await almacen.leer('temas');
  const tema = temas.find(t => t.id === temaId);
  if (!tema) {
    const error = new Error(`Tema "${temaId}" no encontrado`);
    error.estado = 404;
    throw error;
  }

  // Asignatura
  const asig = await acceso.asignaturaDeTema(temaId);

  // Glosario del tema
  const todosGlosario = await almacen.leer('glosario');
  const glosarioTema = todosGlosario.filter(g => g.temaId === temaId);
  const glosarioTexto = glosarioTema.length > 0
    ? glosarioTema.map(g => `• ${g.termino}: ${g.definicion}`).join('\n')
    : 'No hay términos de glosario previos registrados.';

  // Preguntas existentes
  const todasPreguntas = await almacen.leer('preguntas');
  const preguntasExistentes = todasPreguntas.filter(p => p.temaId === temaId);
  const existentesTexto = preguntasExistentes.length > 0
    ? preguntasExistentes.map(p => `• ${p.enunciado}`).join('\n')
    : 'Ninguna pregunta registrada previamente.';

  // Contenido pedagógico del tema
  const partesContenido = [];
  if (tema.resumen) partesContenido.push(`Resumen:\n${tema.resumen}`);
  if (Array.isArray(tema.objetivos) && tema.objetivos.length > 0) {
    partesContenido.push(`Objetivos de aprendizaje:\n- ${tema.objetivos.join('\n- ')}`);
  }
  if (Array.isArray(tema.ejemplos) && tema.ejemplos.length > 0) {
    partesContenido.push(`Ejemplos:\n- ${tema.ejemplos.join('\n- ')}`);
  }
  if (Array.isArray(tema.preguntasGuia) && tema.preguntasGuia.length > 0) {
    partesContenido.push(`Preguntas guía:\n- ${tema.preguntasGuia.join('\n- ')}`);
  }

  const contenido = partesContenido.join('\n\n') || 'Contenido general del tema.';

  // Detectar si el tema trata de oraciones condicionales en inglés
  const tituloMinus = (tema.titulo || '').toLowerCase();
  const resumenMinus = (tema.resumen || '').toLowerCase();
  const esCondicionales = (
    tituloMinus.includes('condicional') ||
    tituloMinus.includes('ingles') ||
    tituloMinus.includes('english') ||
    resumenMinus.includes('conditional') ||
    resumenMinus.includes('condicional') ||
    Boolean(cuerpo.condicionales)
  );

  let directricesEspeciales = '';
  if (esCondicionales) {
    directricesEspeciales = `
DIRECTRICES EXCLUSIVAS OBLIGATORIAS PARA ESTE TEMA:
1. Las preguntas deben estar relacionadas EXCLUSIVAMENTE con el tema de las oraciones condicionales en inglés ("Conditional Sentences").
2. Debes cubrir los tipos de condicionales:
   - Condicional Cero (Zero Conditional): verdades universales, hechos científicos y rutinas (If + present simple, present simple).
   - Primer Condicional (First Conditional): situaciones reales o probables en el futuro (If + present simple, will + verb / imperative).
   - Segundo Condicional (Second Conditional): situaciones hipotéticas o poco probables en presente/futuro (If + past simple, would + verb).
   - Tercer Condicional (Third Conditional): situaciones hipotéticas pasadas y sus consecuencias no ocurridas (If + past perfect, would have + past participle).
   - Condicionales Mixtos (Mixed Conditionals): combinación de causa pasada y consecuencia presente, o condición permanente y consecuencia pasada.
3. Formato estricto de cada pregunta:
   - "tipo": "opcion" (todas las preguntas deben ser de opción múltiple).
   - "opciones": exactamente 4 opciones de respuesta gramaticales (ni más ni menos).
   - "correcta": índice de 0 a 3 que señala la opción correcta.
   - "retroalimentacion": explicación clara de la regla gramatical del condicional evaluado y por qué es la respuesta correcta.`;
  }

  const instruccionTipos = esCondicionales
    ? `Genera exactamente ${Math.min(Math.max(Number(cantidad) || 5, 1), 10)} preguntas de ese nivel cognitivo.
REQUISITO ESTRICTO DE OPCIONES:
- TODAS las preguntas DEBEN ser obligatoriamente de tipo "opcion" con exactamente 4 opciones de respuesta y una sola correcta ("correcta" = índice de 0 a 3).
- NO generes preguntas de tipo "vf" ni "completar". Todas deben tener 4 opciones.
- Cada pregunta debe evaluar oraciones condicionales en inglés (Zero, First, Second, Third o Mixed Conditionals).`
    : `Genera ${Math.min(Math.max(Number(cantidad) || 5, 1), 10)} preguntas de ese nivel cognitivo, combinando tipos:
- "opcion": 4 opciones y una sola correcta; "correcta" = índice de 0 a 3.
- "vf": "opciones" = ["Verdadero", "Falso"]; "correcta" = true o false.
- "completar": enunciado con "____"; "correcta" = palabra o frase corta.`;

  return {
    asignatura: asig?.nombre || 'Competencias Digitales y Estrategias Tecnológicas',
    nivel: asig?.nivel || 'Educación Superior',
    tema: tema.titulo,
    contenido,
    glosario: glosarioTexto,
    nivelBloom,
    existentes: existentesTexto,
    directricesEspeciales,
    instruccionTipos,
    cantidad: Math.min(Math.max(Number(cantidad) || 5, 1), 10)
  };
}


