import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIR_RAIZ = path.resolve(__dirname, '..');
const DIR_DATOS = path.join(DIR_RAIZ, 'datos');
const DIR_CONFIG = path.join(DIR_DATOS, 'config');
const DIR_RESPALDOS = path.join(DIR_DATOS, 'respaldos');

// Expresión regular: solo minúsculas, números y guiones, con subcarpeta opcional
const REGEX_COL = /^[a-z0-9-]+(\/[a-z0-9_-]+)?$/;

function validarColeccion(col) {
  if (typeof col !== 'string' || !REGEX_COL.test(col)) {
    const error = new Error(`Nombre de colección no válido: "${col}". Solo se admiten minúsculas, números, guiones y una subcarpeta opcional.`);
    error.estado = 400;
    throw error;
  }
}

function rutaColeccion(col) {
  return path.join(DIR_DATOS, `${col}.json`);
}

// Colas de escritura por archivo para evitar condiciones de carrera
const colas = new Map();

function encolar(ruta, tarea) {
  const colaPrevia = colas.get(ruta) || Promise.resolve();
  const ejecucion = colaPrevia
    .catch(() => {})
    .then(() => tarea());
  colas.set(ruta, ejecucion);
  return ejecucion;
}

// Respaldo diario en la primera escritura de cada día
let respaldoHoyHecho = false;
let fechaUltimoRespaldo = '';

async function asegurarRespaldoDiario() {
  const hoy = new Date().toISOString().slice(0, 10);
  if (respaldoHoyHecho && fechaUltimoRespaldo === hoy) {
    return;
  }

  const destinoHoy = path.join(DIR_RESPALDOS, hoy);

  try {
    await fs.access(destinoHoy);
    respaldoHoyHecho = true;
    fechaUltimoRespaldo = hoy;
    return;
  } catch {
    // Aún no existe el respaldo del día
  }

  try {
    await fs.mkdir(DIR_DATOS, { recursive: true });
    await fs.mkdir(destinoHoy, { recursive: true });

    const entradas = await fs.readdir(DIR_DATOS, { withFileTypes: true });
    for (const entrada of entradas) {
      if (entrada.name === 'respaldos' || entrada.name.endsWith('.tmp')) continue;
      const origen = path.join(DIR_DATOS, entrada.name);
      const destino = path.join(destinoHoy, entrada.name);
      await fs.cp(origen, destino, { recursive: true });
    }

    // Conservar solo los 14 más recientes
    await fs.mkdir(DIR_RESPALDOS, { recursive: true });
    const existentes = await fs.readdir(DIR_RESPALDOS, { withFileTypes: true });
    const carpetasFecha = existentes
      .filter(e => e.isDirectory() && /^\d{4}-\d{2}-\d{2}$/.test(e.name))
      .map(e => e.name)
      .sort();

    if (carpetasFecha.length > 14) {
      const aEliminar = carpetasFecha.slice(0, carpetasFecha.length - 14);
      for (const carpeta of aEliminar) {
        await fs.rm(path.join(DIR_RESPALDOS, carpeta), { recursive: true, force: true });
      }
    }

    respaldoHoyHecho = true;
    fechaUltimoRespaldo = hoy;
  } catch (err) {
    console.error('Error al realizar respaldo diario:', err);
  }
}

async function escribirAtomico(ruta, datos) {
  await fs.mkdir(path.dirname(ruta), { recursive: true });
  const rutaTmp = `${ruta}.${Date.now()}_${Math.random().toString(36).slice(2, 8)}.tmp`;
  const contenido = typeof datos === 'string' ? datos : JSON.stringify(datos, null, 2);
  await fs.writeFile(rutaTmp, contenido, 'utf-8');
  await fs.rename(rutaTmp, ruta);
}

async function leerInterno(ruta) {
  try {
    const contenido = await fs.readFile(ruta, 'utf-8');
    const trim = contenido.trim();
    if (!trim) return [];
    return JSON.parse(trim);
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
}

function generarId(col, lista) {
  const base = col.split('/')[0];
  const letras = base.replace(/[^a-z]/g, '');
  const prefijo = letras.slice(0, 3).padEnd(3, 'x');

  let mayor = 0;
  for (const item of lista) {
    if (item && typeof item.id === 'string') {
      const match = item.id.match(/_(\d+)$/);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > mayor) mayor = num;
      }
    }
  }

  const siguiente = mayor + 1;
  return `${prefijo}_${String(siguiente).padStart(6, '0')}`;
}

export async function leer(col) {
  validarColeccion(col);
  const ruta = rutaColeccion(col);
  return leerInterno(ruta);
}

export async function escribir(col, lista) {
  validarColeccion(col);
  const ruta = rutaColeccion(col);
  return encolar(ruta, async () => {
    await asegurarRespaldoDiario();
    await escribirAtomico(ruta, lista);
    return lista;
  });
}

export async function agregar(col, reg) {
  validarColeccion(col);
  const ruta = rutaColeccion(col);
  return encolar(ruta, async () => {
    await asegurarRespaldoDiario();
    const lista = await leerInterno(ruta);
    const id = reg.id || generarId(col, lista);
    const fecha = reg.fecha || new Date().toISOString();
    const nuevo = { ...reg, id, fecha };
    lista.push(nuevo);
    await escribirAtomico(ruta, lista);
    return nuevo;
  });
}

export async function actualizar(col, id, cambios) {
  validarColeccion(col);
  const ruta = rutaColeccion(col);
  return encolar(ruta, async () => {
    await asegurarRespaldoDiario();
    const lista = await leerInterno(ruta);
    const indice = lista.findIndex(r => r.id === id);
    if (indice === -1) return null;
    lista[indice] = { ...lista[indice], ...cambios, id, fecha: lista[indice].fecha };
    await escribirAtomico(ruta, lista);
    return lista[indice];
  });
}

export async function eliminar(col, id) {
  validarColeccion(col);
  const ruta = rutaColeccion(col);
  return encolar(ruta, async () => {
    await asegurarRespaldoDiario();
    const lista = await leerInterno(ruta);
    const indice = lista.findIndex(r => r.id === id);
    if (indice === -1) return false;
    lista.splice(indice, 1);
    await escribirAtomico(ruta, lista);
    return true;
  });
}

export async function buscar(col, filtro = {}) {
  const lista = await leer(col);
  const entradas = Object.entries(filtro);
  if (entradas.length === 0) return lista;
  return lista.filter(item => {
    return entradas.every(([clave, valor]) => {
      return String(item[clave]) === String(valor);
    });
  });
}

export async function anexarLinea(archivo, obj) {
  const nombre = archivo.endsWith('.jsonl') ? archivo : `${archivo}.jsonl`;
  const sinExt = nombre.replace(/\.jsonl$/, '');
  validarColeccion(sinExt);
  const ruta = path.join(DIR_DATOS, nombre);
  return encolar(ruta, async () => {
    await asegurarRespaldoDiario();
    await fs.mkdir(path.dirname(ruta), { recursive: true });
    const linea = JSON.stringify(obj) + '\n';
    await fs.appendFile(ruta, linea, 'utf-8');
    return obj;
  });
}

export async function leerLineas(archivo) {
  const nombre = archivo.endsWith('.jsonl') ? archivo : `${archivo}.jsonl`;
  const sinExt = nombre.replace(/\.jsonl$/, '');
  validarColeccion(sinExt);
  const ruta = path.join(DIR_DATOS, nombre);
  try {
    const contenido = await fs.readFile(ruta, 'utf-8');
    return contenido
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean)
      .map(l => JSON.parse(l));
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
}

export async function leerConfig(nombre) {
  const archivo = nombre.endsWith('.json') ? nombre : `${nombre}.json`;
  const ruta = path.join(DIR_CONFIG, archivo);
  try {
    const contenido = await fs.readFile(ruta, 'utf-8');
    const trim = contenido.trim();
    if (!trim) return {};
    return JSON.parse(trim);
  } catch (err) {
    if (err.code === 'ENOENT') return {};
    throw err;
  }
}

export async function escribirConfig(nombre, obj) {
  const archivo = nombre.endsWith('.json') ? nombre : `${nombre}.json`;
  const ruta = path.join(DIR_CONFIG, archivo);
  return encolar(ruta, async () => {
    await fs.mkdir(DIR_CONFIG, { recursive: true });
    await fs.writeFile(ruta, JSON.stringify(obj, null, 2), 'utf-8');
    return obj;
  });
}

