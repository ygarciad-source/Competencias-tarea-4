import bcrypt from 'bcryptjs';
import * as almacen from './almacen.js';

async function main() {
  const correo = (process.argv[2] || 'admin@unemi.edu.ec').trim().toLowerCase();
  const clave = process.argv[3] || 'admin123';

  console.log(`Verificando usuario administrador para: ${correo}...`);

  const usuarios = await almacen.leer('usuarios');
  const existente = usuarios.find(u => u.correo === correo);

  const claveHash = await bcrypt.hash(clave, 10);

  if (existente) {
    await almacen.actualizar('usuarios', existente.id, {
      rol: 'admin',
      activo: true,
      claveHash
    });
    console.log(`✔ Administrador existente "${correo}" actualizado correctamente con rol "admin".`);
  } else {
    const nuevoAdmin = {
      nombre: 'Administrador',
      apellido: 'Sistema',
      correo,
      claveHash,
      rol: 'admin',
      activo: true,
      foto: null,
      consentimiento: {
        aceptado: true,
        fecha: new Date().toISOString()
      }
    };
    const creado = await almacen.agregar('usuarios', nuevoAdmin);
    console.log(`✔ Nuevo administrador creado exitosamente con ID ${creado.id} (${correo}).`);
  }
}

main().catch(err => {
  console.error('Error al crear administrador:', err);
  process.exit(1);
});
