import * as almacen from './almacen.js';

/**
 * Middleware que extrae el token del encabezado Authorization: Bearer <token>,
 * valida la sesión activa y asigna el usuario autenticado a req.usuario.
 */
export async function cargarUsuario(req, res, next) {
  req.usuario = null;
  const auth = req.headers.authorization || '';

  if (auth.startsWith('Bearer ')) {
    const token = auth.slice(7).trim();
    if (token) {
      try {
        const sesiones = await almacen.leer('sesiones');
        const sesion = sesiones.find(s => s.token === token);
        if (sesion && (!sesion.expira || new Date(sesion.expira) > new Date())) {
          const usuarios = await almacen.leer('usuarios');
          const usuario = usuarios.find(u => u.id === sesion.usuarioId);
          if (usuario && usuario.activo !== false) {
            req.usuario = {
              id: usuario.id,
              nombre: usuario.nombre,
              apellido: usuario.apellido,
              correo: usuario.correo,
              rol: usuario.rol
            };
          }
        }
      } catch (err) {
        console.error('Error en middleware cargarUsuario:', err);
      }
    }
  }

  next();
}

/**
 * Middleware que restringe el acceso a uno o varios roles específicos.
 * @param  {...string} roles - Roles permitidos ('sesion', 'estudiante', 'docente', 'admin')
 */
export function exigirRol(...roles) {
  return (req, res, next) => {
    if (!req.usuario) {
      return res.status(401).json({ error: 'Autenticación requerida (401)' });
    }

    if (roles.length === 0 || roles.includes('sesion')) {
      return next();
    }

    if (req.usuario.rol === 'admin' || roles.includes(req.usuario.rol)) {
      return next();
    }

    return res.status(403).json({ error: 'Acceso no autorizado para este rol (403)' });
  };
}

export default {
  cargarUsuario,
  exigirRol
};
