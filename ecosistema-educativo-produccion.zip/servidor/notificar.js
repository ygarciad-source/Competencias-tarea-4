import * as almacen from './almacen.js';

/**
 * Módulo notificar.js - Emisión de notificaciones en el sistema
 * Contrato §B: notificar(usuarioId, { tipo, mensaje, enlace })
 * @param {string} usuarioId - Destinatario
 * @param {object} datos - { tipo, mensaje, enlace }
 * @returns {Promise<object>} Registro creado en la colección "notificaciones"
 */
export async function notificar(usuarioId, { tipo = 'sistema', mensaje, enlace = null } = {}) {
  if (!usuarioId || !mensaje) return null;

  const notificacion = {
    usuarioId,
    tipo,
    mensaje,
    enlace,
    leida: false
  };

  return almacen.agregar('notificaciones', notificacion);
}

export default {
  notificar
};
