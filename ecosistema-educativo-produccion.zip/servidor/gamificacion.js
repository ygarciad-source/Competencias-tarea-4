/**
 * Módulo gamificacion.js (servidor)
 * Motor central de gamificación: procesa intentos, calcula puntos, asigna insignias y actualiza logros.
 * Contrato §B: procesarIntento(usuario, datos)
 */

import * as almacen from './almacen.js';
import * as acceso from './acceso.js';
import * as alertas from './alertas.js';

// Historial en memoria para control de tasa (máximo intentos por hora)
// usuarioId -> Array<timestamp>
const intentosPorHoraMemoria = new Map();

/**
 * Obtiene el valor de una propiedad simple o anidada (ej: "detalle.simulacionId")
 * @param {object} obj
 * @param {string} ruta
 * @returns {any}
 */
function obtenerCampo(obj, ruta) {
  if (!obj || !ruta) return undefined;
  if (!ruta.includes('.')) return obj[ruta];
  const partes = ruta.split('.');
  let actual = obj;
  for (const p of partes) {
    if (actual === null || actual === undefined) return undefined;
    actual = actual[p];
  }
  return actual;
}

/**
 * Procesa un intento de actividad, calcula sus puntos y actualiza logros e insignias.
 * @param {object} usuario - Usuario autenticado
 * @param {object} datos - { actividad, temaId, nivel, puntaje, maximo, errores, duracionSeg, detalle }
 * @returns {Promise<{ puntosGanados: number, puntosTotales: number, insigniasNuevas: Array }>}
 */
export async function procesarIntento(usuario, datos = {}) {
  if (!usuario || !usuario.id) {
    const error = new Error('Autenticación requerida para registrar intentos');
    error.estado = 401;
    throw error;
  }

  // Cargar configuración de reglas
  const reglas = await almacen.leerConfig('reglas-gamificacion');
  const puntosReglas = reglas.puntos || {};

  const actividad = datos.actividad;

  // 1. Validar actividad existente en reglas.puntos
  if (!actividad || puntosReglas[actividad] === undefined) {
    const error = new Error(`Actividad "${actividad}" inválida o no configurada en reglas de puntos`);
    error.estado = 400;
    throw error;
  }

  // 2. Validar puntaje y máximo: 0 <= puntaje <= maximo y maximo > 0
  const puntaje = Number(datos.puntaje);
  const maximo = Number(datos.maximo);
  if (isNaN(puntaje) || isNaN(maximo) || maximo <= 0 || puntaje < 0 || puntaje > maximo) {
    const error = new Error('Puntaje o valor máximo inválido (debe cumplir 0 <= puntaje <= maximo y maximo > 0)');
    error.estado = 400;
    throw error;
  }

  const errores = Number(datos.errores) >= 0 ? Number(datos.errores) : 0;
  const duracionSeg = Number(datos.duracionSeg) >= 0 ? Number(datos.duracionSeg) : 0;
  const detalle = datos.detalle && typeof datos.detalle === 'object' ? datos.detalle : {};

  // 3. Validar acceso al tema si viene temaId
  if (datos.temaId) {
    if (usuario.rol !== 'admin') {
      const asignatura = await acceso.asignaturaDeTema(datos.temaId);
      if (!asignatura) {
        const error = new Error('Tema no encontrado');
        error.estado = 404;
        throw error;
      }
      const misAsignaturas = await acceso.asignaturasDe(usuario);
      const tieneAcceso = misAsignaturas.some(a => a.id === asignatura.id);
      if (!tieneAcceso) {
        const error = new Error('No tienes acceso a los contenidos de este tema');
        error.estado = 403;
        throw error;
      }
    }
  }

  // 4. Límite de intentos por hora (en memoria) -> 429
  const limiteHora = reglas.limiteIntentosHora || 60;
  const ahora = Date.now();
  const unaHoraAtras = ahora - 3600 * 1000;
  const historial = (intentosPorHoraMemoria.get(usuario.id) || []).filter(ts => ts > unaHoraAtras);

  if (historial.length >= limiteHora) {
    const error = new Error(`Has alcanzado el límite máximo de ${limiteHora} intentos por hora. Intenta más tarde.`);
    error.estado = 429;
    throw error;
  }
  historial.push(ahora);
  intentosPorHoraMemoria.set(usuario.id, historial);

  // 5. Cálculo base de puntos: redondeo(puntos[actividad] * puntaje / maximo) + bonoSinErrores
  let puntosCalculados = Math.round((puntosReglas[actividad] * puntaje) / maximo);
  if (errores === 0 && puntaje === maximo) {
    puntosCalculados += Number(reglas.bonoSinErrores || 0);
  }

  // 6. Cargar historial de intentos del usuario para evaluar restricciones de puntos
  const todosIntentos = await almacen.leer('intentos');
  const misIntentosPrevios = todosIntentos.filter(i => i.usuarioId === usuario.id);

  let puntosFinales = puntosCalculados;

  // Condición A: Actividad única (ya hay un intento con puntos con la misma clave)
  const camposUnicos = reglas.unicas ? reglas.unicas[actividad] : null;
  if (Array.isArray(camposUnicos) && camposUnicos.length > 0) {
    const yaTieneConPuntos = misIntentosPrevios.some(previo => {
      if (previo.actividad !== actividad || (previo.puntos || 0) <= 0) return false;
      return camposUnicos.every(campo => {
        const valPrevio = obtenerCampo(previo, campo);
        const valNuevo = obtenerCampo({ ...datos, detalle }, campo);
        return valPrevio !== undefined && valPrevio === valNuevo;
      });
    });

    if (yaTieneConPuntos) {
      puntosFinales = 0;
    }
  }

  // Condición B: Requiere aprobado y detalle.aprobado !== true
  const listaRequiereAprobado = Array.isArray(reglas.requiereAprobado) ? reglas.requiereAprobado : [];
  if (listaRequiereAprobado.includes(actividad)) {
    if (detalle.aprobado !== true) {
      puntosFinales = 0;
    }
  }

  // Condición C: Máximo diario de intentos con puntos
  const maxDiarioActividad = reglas.maxDiario ? reglas.maxDiario[actividad] : undefined;
  if (typeof maxDiarioActividad === 'number' && maxDiarioActividad > 0) {
    const hoyIso = new Date().toISOString().slice(0, 10);
    const intentosHoyConPuntos = misIntentosPrevios.filter(previo => {
      if (previo.actividad !== actividad || (previo.puntos || 0) <= 0) return false;
      const fechaPrevio = (previo.fecha || '').slice(0, 10);
      return fechaPrevio === hoyIso;
    });

    if (intentosHoyConPuntos.length >= maxDiarioActividad) {
      puntosFinales = 0;
    }
  }

  puntosFinales = Math.max(0, puntosFinales);

  // 7. Guardar intento en la colección "intentos"
  const nuevoIntento = {
    usuarioId: usuario.id,
    actividad,
    temaId: datos.temaId || null,
    nivel: datos.nivel !== undefined && datos.nivel !== null ? Number(datos.nivel) : null,
    puntaje,
    maximo,
    errores,
    duracionSeg,
    detalle,
    puntos: puntosFinales
  };

  const intentoGuardado = await almacen.agregar('intentos', nuevoIntento);

  // Agregar el nuevo intento a la lista local para evaluación de insignias
  const todosMisIntentos = [...misIntentosPrevios, intentoGuardado];

  // 8. Cargar o crear el registro de "logros" del usuario
  const todosLogros = await almacen.leer('logros');
  let logro = todosLogros.find(l => l.usuarioId === usuario.id);

  if (!logro) {
    logro = {
      usuarioId: usuario.id,
      puntos: 0,
      insignias: [],
      nivelQuiz: {}
    };
  }

  logro.puntos = (Number(logro.puntos) || 0) + puntosFinales;
  logro.insignias = Array.isArray(logro.insignias) ? logro.insignias : [];
  logro.nivelQuiz = logro.nivelQuiz && typeof logro.nivelQuiz === 'object' ? logro.nivelQuiz : {};

  // Actualizar nivelQuiz si corresponde (quiz aprobado)
  if (actividad === 'quiz' && datos.temaId && datos.nivel !== undefined && detalle.aprobado === true) {
    const lvlNum = Number(datos.nivel);
    const actualLvl = logro.nivelQuiz[datos.temaId] || 0;
    logro.nivelQuiz[datos.temaId] = Math.max(actualLvl, lvlNum);
  }

  // 9. Evaluar insignias no obtenidas
  const insigniasObtenidasIds = new Set(logro.insignias.map(ins => ins.id));
  const todasInsignias = await almacen.leer('insignias');
  const insigniasNuevas = [];

  for (const ins of todasInsignias) {
    if (insigniasObtenidasIds.has(ins.id)) continue;
    const cond = ins.condicion || {};

    let cumple = false;

    switch (cond.tipo) {
      case 'conteo': {
        // En actividades únicas, cuenta claves distintas; de lo contrario cuenta intentos
        const act = cond.actividad;
        const intentosAct = todosMisIntentos.filter(i => i.actividad === act);

        if (reglas.unicas && Array.isArray(reglas.unicas[act])) {
          const clavesUnicas = new Set();
          const campos = reglas.unicas[act];
          for (const i of intentosAct) {
            const claveCompuesta = campos.map(c => obtenerCampo(i, c)).join('::');
            clavesUnicas.add(claveCompuesta);
          }
          cumple = clavesUnicas.size >= (cond.minimo || 1);
        } else {
          cumple = intentosAct.length >= (cond.minimo || 1);
        }
        break;
      }

      case 'sinErrores': {
        // Gana la actividad sin errores
        const act = cond.actividad;
        cumple = todosMisIntentos.some(i =>
          i.actividad === act &&
          i.errores === 0 &&
          (i.puntaje === i.maximo || i.detalle?.ganado === true || i.detalle?.completado === true)
        );
        break;
      }

      case 'puntos': {
        cumple = logro.puntos >= (cond.minimo || 0);
        break;
      }

      case 'nivelQuiz': {
        // Aprueba el nivel en cualquier tema
        const reqLvl = Number(cond.nivel);
        const enNivelQuiz = Object.values(logro.nivelQuiz).some(lvl => Number(lvl) >= reqLvl);
        const enIntentos = todosMisIntentos.some(i =>
          i.actividad === 'quiz' &&
          Number(i.nivel) >= reqLvl &&
          i.detalle?.aprobado === true
        );
        cumple = enNivelQuiz || enIntentos;
        break;
      }

      case 'racha': {
        // Días consecutivos con intentos hasta hoy
        const diasReq = Number(cond.dias) || 1;
        const diasRegistrados = new Set(
          todosMisIntentos
            .map(i => (i.fecha || '').slice(0, 10))
            .filter(Boolean)
        );

        let racha = 0;
        const hoy = new Date();
        for (let d = 0; d < 365; d++) {
          const fechaRef = new Date(hoy);
          fechaRef.setDate(hoy.getDate() - d);
          const fechaIso = fechaRef.toISOString().slice(0, 10);
          if (diasRegistrados.has(fechaIso)) {
            racha++;
          } else {
            break;
          }
        }
        cumple = racha >= diasReq;
        break;
      }

      default:
        cumple = false;
    }

    if (cumple) {
      const fechaObtencion = new Date().toISOString();
      logro.insignias.push({ id: ins.id, fecha: fechaObtencion });
      insigniasNuevas.push({
        id: ins.id,
        nombre: ins.nombre,
        icono: ins.icono
      });
      insigniasObtenidasIds.add(ins.id);
    }
  }

  // 10. Persistir registro de logros
  if (logro.id) {
    await almacen.actualizar('logros', logro.id, logro);
  } else {
    logro = await almacen.agregar('logros', logro);
  }

  // 11. Llamar a evaluarAlertas(intento, usuario) dentro de try/catch
  try {
    await alertas.evaluarAlertas(intentoGuardado, usuario);
  } catch (errAlertas) {
    console.error('Error al evaluar alertas:', errAlertas);
  }

  // 12. Devolver resumen del intento
  return {
    puntosGanados: puntosFinales,
    puntosTotales: logro.puntos,
    insigniasNuevas
  };
}

export default {
  procesarIntento
};
