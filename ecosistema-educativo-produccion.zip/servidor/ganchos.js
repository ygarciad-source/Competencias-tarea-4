import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIR_GANCHOS = path.join(__dirname, 'ganchos');

const ganchos = new Map();

/**
 * Carga todos los ganchos definidos en servidor/ganchos/<col>.js.
 */
export async function cargarGanchos() {
  ganchos.clear();
  try {
    const archivos = await fs.readdir(DIR_GANCHOS);
    for (const archivo of archivos) {
      if (archivo.endsWith('.js')) {
        const col = archivo.slice(0, -3);
        const rutaCompleta = path.join(DIR_GANCHOS, archivo);
        const modulo = await import(pathToFileURL(rutaCompleta).href);
        ganchos.set(col, modulo.default || modulo);
      }
    }
  } catch (err) {
    if (err.code !== 'ENOENT') {
      console.error('Error al cargar ganchos:', err);
    }
  }
}

// Cargar ganchos al iniciar el módulo
await cargarGanchos();

/**
 * Aplica un gancho sobre una colección si existe.
 * Si el gancho o método no existe, devuelve el primer argumento.
 * Si el gancho lanza un Error con la propiedad estado, se propaga para ser manejado por la API.
 * @param {string} col - Nombre de la colección.
 * @param {'filtrarLista'|'antesDeGuardar'|'despuesDeGuardar'} nombre - Nombre de la función del gancho.
 * @param {...any} args - Argumentos para el gancho.
 * @returns {Promise<any>}
 */
export async function aplicar(col, nombre, ...args) {
  const baseCol = col.includes('/') ? col.split('/')[0] : col;
  let gancho = ganchos.get(col) || ganchos.get(baseCol);

  if (!gancho) {
    try {
      const rutaCompleta = path.join(DIR_GANCHOS, `${baseCol}.js`);
      const modulo = await import(pathToFileURL(rutaCompleta).href);
      gancho = modulo.default || modulo;
      ganchos.set(baseCol, gancho);
    } catch {
      // El gancho para esta colección no existe
    }
  }

  if (!gancho || typeof gancho[nombre] !== 'function') {
    return args[0];
  }

  const resultado = await gancho[nombre](...args);
  return resultado !== undefined ? resultado : args[0];
}

