/**
 * Módulo ia.js (servidor)
 * Motor de Inteligencia Artificial para el Ecosistema Educativo.
 * Integra Google Gemini (gemini-3.5-flash) según contrato §B.
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as almacen from './almacen.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIR_PROMPTS = path.join(__dirname, 'prompts');
const DIR_PREPARADORES = path.join(__dirname, 'preparadores');

/**
 * Obtiene la configuración activa de IA desde ajustes.json o variables de entorno.
 * @returns {Promise<{ clave: string, modelo: string, proveedor: string, limiteDiario: number }>}
 */
export async function obtenerConfiguracion() {
  const ajustes = await almacen.leerConfig('ajustes');

  const clave = (ajustes.iaClave || process.env.IA_CLAVE || '').trim();
  const modelo = (ajustes.iaModelo || process.env.IA_MODELO || 'gemini-3.5-flash').trim();
  const proveedor = (ajustes.iaProveedor || process.env.IA_PROVEEDOR || 'gemini').trim();
  const limiteDiario = Number(ajustes.limiteIADiario) || 30;

  return {
    clave,
    modelo,
    proveedor,
    limiteDiario
  };
}

/**
 * Verifica si el usuario ha superado su límite diario de consultas de IA.
 * @param {string} usuarioId
 * @param {number} limite
 */
async function verificarLimiteDiario(usuarioId, limite) {
  if (!usuarioId) return;

  try {
    const lineas = await almacen.leerLineas('consumo-ia.jsonl');
    const hoyIso = new Date().toISOString().slice(0, 10);

    const consultasHoy = lineas.filter(l =>
      l &&
      l.usuarioId === usuarioId &&
      l.ok === true &&
      (l.fecha || '').slice(0, 10) === hoyIso
    );

    if (consultasHoy.length >= limite) {
      const err = new Error(`Límite diario de consultas a la IA alcanzado (${limite} por día). Intenta mañana.`);
      err.estado = 429;
      throw err;
    }
  } catch (err) {
    if (err.estado === 429) throw err;
    // Si el archivo no existe aún, se permite continuar
  }
}

/**
 * Ejecuta una tarea pedagógica con IA.
 * @param {string} tarea - Nombre de la tarea (ej: "generar-preguntas", "generar-glosario")
 * @param {object} datos - Parámetros de entrada para el preparador
 * @param {object} [usuario] - Usuario autenticado
 * @param {object} [opciones] - { formato: 'json' | 'texto' }
 * @returns {Promise<any>}
 */
export async function ejecutarTarea(tarea, datos = {}, usuario = null, { formato = 'json' } = {}) {
  const config = await obtenerConfiguracion();

  if (!config.clave) {
    const err = new Error('La clave de API de IA no está configurada. Contacte al administrador.');
    err.estado = 503;
    throw err;
  }

  // 1. Verificar límite diario
  if (usuario && usuario.rol !== 'admin') {
    await verificarLimiteDiario(usuario.id, config.limiteDiario);
  }

  // 2. Preparar variables para la plantilla de prompt
  let variables = { ...datos };
  const rutaPreparador = path.join(DIR_PREPARADORES, `${tarea}.js`);

  try {
    await fs.access(rutaPreparador);
    const moduloPreparador = await import(pathToFileURL(rutaPreparador).href);
    const prepararFn = moduloPreparador.default || moduloPreparador;
    if (typeof prepararFn === 'function') {
      const resultadoPreparador = await prepararFn(datos, usuario);
      variables = { ...variables, ...resultadoPreparador };
    }
  } catch (err) {
    if (err.code !== 'ENOENT' && err.estado) {
      throw err;
    }
  }

  // 3. Cargar plantilla de prompt
  const rutaPrompt = path.join(DIR_PROMPTS, `${tarea}.txt`);
  let plantilla = '';
  try {
    plantilla = await fs.readFile(rutaPrompt, 'utf-8');
  } catch (err) {
    const errorPrompt = new Error(`Plantilla de prompt no encontrada para la tarea "${tarea}"`);
    errorPrompt.estado = 404;
    throw errorPrompt;
  }

  // 4. Sustituir variables {{clave}}
  let textoFinal = plantilla;
  for (const [k, v] of Object.entries(variables)) {
    const regex = new RegExp(`\\{\\{${k}\\}\\}`, 'g');
    textoFinal = textoFinal.replace(regex, v !== undefined && v !== null ? String(v) : '');
  }

  // 5. Separar instrucciones de sistema y mensaje de usuario con ### USUARIO
  let systemText = '';
  let userText = textoFinal;

  if (textoFinal.includes('### USUARIO')) {
    const partes = textoFinal.split('### USUARIO');
    systemText = partes[0].trim();
    userText = partes[1].trim();
  }

  // 6. Invocar Google Gemini API
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(config.modelo)}:generateContent?key=${encodeURIComponent(config.clave)}`;

  const cuerpoPeticion = {
    contents: [
      {
        parts: [{ text: userText }]
      }
    ],
    generationConfig: {
      temperature: 0.2,
      ...(formato === 'json' ? { responseMimeType: 'application/json' } : {})
    }
  };

  if (systemText) {
    cuerpoPeticion.systemInstruction = {
      parts: [{ text: systemText }]
    };
  }

  let respuestaJson = null;
  let salidaTexto = '';

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cuerpoPeticion)
    });

    const datosRespuesta = await res.json();

    if (!res.ok) {
      const mensajeError = datosRespuesta?.error?.message || `Error del proveedor de IA (HTTP ${res.status})`;
      const errIA = new Error(mensajeError);
      errIA.estado = 502;
      throw errIA;
    }

    salidaTexto = datosRespuesta?.candidates?.[0]?.content?.parts?.[0]?.text || '';

    if (!salidaTexto) {
      throw new Error('La IA no devolvió contenido.');
    }

    if (formato === 'json') {
      // Limpiar posibles bloques ```json ... ```
      let limpio = salidaTexto.trim();
      if (limpio.startsWith('```json')) {
        limpio = limpio.replace(/^```json\s*/i, '').replace(/```\s*$/i, '');
      } else if (limpio.startsWith('```')) {
        limpio = limpio.replace(/^```\s*/, '').replace(/```\s*$/i, '');
      }
      respuestaJson = JSON.parse(limpio);
    } else {
      respuestaJson = salidaTexto;
    }

    // 7. Registrar bitácora de consumo exitoso en consumo-ia.jsonl
    await almacen.anexarLinea('consumo-ia.jsonl', {
      usuarioId: usuario?.id || null,
      tarea,
      entrada: { tarea, temaId: datos.temaId },
      salida: typeof respuestaJson === 'object' ? 'JSON generado con éxito' : salidaTexto.slice(0, 200),
      ok: true,
      fecha: new Date().toISOString()
    });

    return respuestaJson;
  } catch (err) {
    // Registrar fallo en consumo-ia.jsonl
    try {
      await almacen.anexarLinea('consumo-ia.jsonl', {
        usuarioId: usuario?.id || null,
        tarea,
        entrada: { tarea, temaId: datos.temaId },
        salida: err.message,
        ok: false,
        fecha: new Date().toISOString()
      });
    } catch {
      // Silencioso
    }
    throw err;
  }
}

/**
 * Prueba la conexión con el modelo y clave configurados en el sistema.
 * @returns {Promise<{ ok: boolean, modelo: string, respuesta: string, latenciaMs: number }>}
 */
export async function probarConexion() {
  const config = await obtenerConfiguracion();

  if (!config.clave) {
    throw new Error('No hay clave de API configurada.');
  }

  const inicio = Date.now();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(config.modelo)}:generateContent?key=${encodeURIComponent(config.clave)}`;

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: 'Responde únicamente con la palabra: CONEXION_OK' }] }]
    })
  });

  const latenciaMs = Date.now() - inicio;
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data?.error?.message || `Fallo al conectar con Gemini (${res.status})`);
  }

  const respuesta = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || 'OK';

  return {
    ok: true,
    modelo: config.modelo,
    proveedor: config.proveedor,
    respuesta,
    latenciaMs
  };
}

export default {
  obtenerConfiguracion,
  ejecutarTarea,
  probarConexion
};
