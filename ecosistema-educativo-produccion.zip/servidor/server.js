import 'dotenv/config';
import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as almacen from './almacen.js';
import { puede } from './permisos.js';
import * as ganchos from './ganchos.js';

import { cargarUsuario } from './auth.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIR_RAIZ = path.resolve(__dirname, '..');
const DIR_PUBLICO = path.join(DIR_RAIZ, 'publico');
const DIR_RUTAS = path.join(__dirname, 'rutas');

const app = express();
const PUERTO = Number(process.env.PORT) || Number(process.env.PUERTO) || 3000;
// Rutas actualizadas con quiz.js


// Servir archivos estáticos desde publico/ (con soporte para extensiones .html)
app.use(express.static(DIR_PUBLICO, { extensions: ['html'] }));

// Endpoint de comprobación de estado para Render (Health Check)
app.get('/healthz', (req, res) => {
  res.status(200).send('OK');
});

// Ruta principal explícita que entrega index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(DIR_PUBLICO, 'index.html'));
});

// Analizador JSON con límite de 1 MB
app.use(express.json({ limit: '1mb' }));

// Middleware para cargar usuario autenticado desde el token Bearer
app.use(cargarUsuario);

// Cargar y montar rutas especializadas de servidor/rutas/*.js en orden alfabético
async function montarRutas() {
  try {
    const archivos = await fs.readdir(DIR_RUTAS);
    const rutasJs = archivos.filter(f => f.endsWith('.js')).sort();
    for (const archivo of rutasJs) {
      const rutaCompleta = path.join(DIR_RUTAS, archivo);
      const modulo = await import(pathToFileURL(rutaCompleta).href);
      const router = modulo.default || modulo;
      if (router) {
        app.use('/api', router);
      }
    }
  } catch (err) {
    if (err.code !== 'ENOENT') {
      console.error('Error al montar rutas:', err);
    }
  }
}

await montarRutas();

// --- API GENÉRICA (/api/:col y /api/:col/:id) ---

// GET /api/:col (listar con filtros exactos por query)
app.get('/api/:col', async (req, res, next) => {
  try {
    const { col } = req.params;

    const permitido = await puede(req.usuario, 'leer', col);
    if (!permitido) {
      return res.status(403).json({ error: 'Acceso no autorizado' });
    }

    let lista = await almacen.leer(col);
    lista = await ganchos.aplicar(col, 'filtrarLista', lista, req.usuario);

    // Si el permiso depende únicamente de "propio", restringir a los del usuario actual
    const config = await almacen.leerConfig('permisos');
    const baseCol = col.includes('/') ? col.split('/')[0] : col;
    const reglasCol = config[col] || config[baseCol];
    const permitidos = reglasCol?.leer || [];
    const soloPropio = permitidos.includes('propio') &&
      !permitidos.includes('publico') &&
      !permitidos.includes('sesion') &&
      !(req.usuario && permitidos.includes(req.usuario.rol));

    if (soloPropio && req.usuario) {
      lista = lista.filter(item => item.usuarioId === req.usuario.id);
    }

    const filtros = req.query;
    const clavesFiltro = Object.keys(filtros);
    if (clavesFiltro.length > 0) {
      lista = lista.filter(item => {
        return clavesFiltro.every(k => String(item[k]) === String(filtros[k]));
      });
    }

    res.json(lista);
  } catch (err) {
    next(err);
  }
});

// GET /api/:col/:id (obtener por id)
app.get('/api/:col/:id', async (req, res, next) => {
  try {
    const { col, id } = req.params;
    const lista = await almacen.leer(col);
    const reg = lista.find(item => item.id === id);

    if (!reg) {
      return res.status(404).json({ error: 'Registro no encontrado' });
    }

    const permitido = await puede(req.usuario, 'leer', col, reg);
    if (!permitido) {
      return res.status(403).json({ error: 'Acceso no autorizado' });
    }

    res.json(reg);
  } catch (err) {
    next(err);
  }
});

// POST /api/:col (crear)
app.post('/api/:col', async (req, res, next) => {
  try {
    const { col } = req.params;
    const datos = { ...(req.body || {}) };

    if (req.usuario && req.usuario.id && !datos.usuarioId) {
      datos.usuarioId = req.usuario.id;
    }

    const permitido = await puede(req.usuario, 'escribir', col, datos);
    if (!permitido) {
      return res.status(403).json({ error: 'Acceso no autorizado' });
    }

    const datosProcesados = await ganchos.aplicar(col, 'antesDeGuardar', datos, req.usuario, null);
    const nuevo = await almacen.agregar(col, datosProcesados);
    await ganchos.aplicar(col, 'despuesDeGuardar', nuevo, req.usuario, null);

    res.status(201).json(nuevo);
  } catch (err) {
    next(err);
  }
});

// PUT /api/:col/:id (actualizar fusionando campos)
app.put('/api/:col/:id', async (req, res, next) => {
  try {
    const { col, id } = req.params;
    const lista = await almacen.leer(col);
    const anterior = lista.find(item => item.id === id);

    if (!anterior) {
      return res.status(404).json({ error: 'Registro no encontrado' });
    }

    const permitido = await puede(req.usuario, 'escribir', col, anterior);
    if (!permitido) {
      return res.status(403).json({ error: 'Acceso no autorizado' });
    }

    const cambios = req.body || {};
    const fusion = { ...anterior, ...cambios, id: anterior.id, fecha: anterior.fecha };

    const datosProcesados = await ganchos.aplicar(col, 'antesDeGuardar', fusion, req.usuario, anterior);
    const actualizado = await almacen.actualizar(col, id, datosProcesados);
    await ganchos.aplicar(col, 'despuesDeGuardar', actualizado, req.usuario, anterior);

    res.json(actualizado);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/:col/:id (eliminar)
app.delete('/api/:col/:id', async (req, res, next) => {
  try {
    const { col, id } = req.params;
    const lista = await almacen.leer(col);
    const anterior = lista.find(item => item.id === id);

    if (!anterior) {
      return res.status(404).json({ error: 'Registro no encontrado' });
    }

    const permitido = await puede(req.usuario, 'escribir', col, anterior);
    if (!permitido) {
      return res.status(403).json({ error: 'Acceso no autorizado' });
    }

    await almacen.eliminar(col, id);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

// Middleware de manejo de errores uniforme: siempre responde { error }
app.use((err, req, res, next) => {
  const estado = typeof err.estado === 'number'
    ? err.estado
    : (typeof err.status === 'number' ? err.status : 500);

  res.status(estado).json({ error: err.message || 'Error interno del servidor' });
});

// Iniciar servidor solo si se ejecuta directamente
if (process.env.NODE_ENV !== 'test') {
  app.listen(PUERTO, '0.0.0.0', () => {
    console.log(`Servidor iniciado en http://0.0.0.0:${PUERTO}`);
  });
}

export default app;
