import { leerConfig } from './almacen.js';

/**
 * Evalúa si un usuario tiene permiso para leer o escribir en una colección.
 * @param {Object|null} usuario - Usuario actual ({ id, rol, ... }) o null si no hay sesión.
 * @param {'leer'|'escribir'} accion - Acción solicitada.
 * @param {string} col - Nombre de la colección.
 * @param {Object|null} [registro] - Registro específico a evaluar.
 * @returns {Promise<boolean>}
 */
export async function puede(usuario, accion, col, registro = null) {
  const config = await leerConfig('permisos');
  
  // Buscar permisos por nombre exacto o por la colección base si hay subcarpeta
  const baseCol = col.includes('/') ? col.split('/')[0] : col;
  const reglasCol = config[col] || config[baseCol];

  // Colección no listada -> false
  if (!reglasCol) {
    return false;
  }

  const permitidos = reglasCol[accion];
  if (!Array.isArray(permitidos)) {
    return false;
  }

  for (const regla of permitidos) {
    // "servidor" nunca se permite desde la API
    if (regla === 'servidor') {
      continue;
    }

    if (regla === 'publico') {
      return true;
    }

    if (regla === 'sesion' && usuario) {
      return true;
    }

    if (usuario && usuario.rol && regla === usuario.rol) {
      return true;
    }

    if (regla === 'propio') {
      if (registro) {
        if (usuario && usuario.id && registro.usuarioId === usuario.id) {
          return true;
        }
      } else if (usuario && usuario.id) {
        // Para consultas de listado general, permitir si hay sesión
        return true;
      }
    }
  }

  return false;
}
